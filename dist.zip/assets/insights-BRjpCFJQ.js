import"./vendor-lucide-CAa9N5Zm.js";import{S as o,U as r,P as l,A as u}from"./debug-CmSjtLR0.js";import{B as m}from"./bankLoader-BvyOcO3i.js";const h={state:{page:"",banks:[],stats:null,history:[],questionActivity:[]},async init(e){l.init("数据洞察"),this.state.page=e||document.body.dataset.page||"trend",this.applySettings(),l.mark("加载题库"),await this.loadBuiltinBanks(),l.mark("题库加载完成"),l.mark("云同步"),u.autoSync().catch(s=>console.warn("[Insights] 静默云同步失败:",s.message)),l.mark("云同步已启动"),l.mark("加载数据"),this.loadData(),l.mark("数据加载完成"),l.mark("渲染页面"),this.state.page==="analysis"?this.renderAnalysisPage():this.renderTrendPage(),l.mark("渲染完成"),l.done({page:this.state.page,bankCount:this.state.banks.length})},applySettings(){const e=o.getSettings();e.fontSize&&r.applyFontSize(e.fontSize),e.theme&&e.theme!=="auto"&&document.documentElement.setAttribute("data-theme",e.theme)},async loadBuiltinBanks(){if(window.localBanksCache&&window.localBanksCache.length>0){this.state.banks=window.localBanksCache;return}await m.loadAllBanks();const e=o.getBanks().filter(s=>s.enabled!==!1);this.state.banks=e,window.localBanksCache=e},loadData(){this.state.banks=o.getBanks(),this.state.stats=o.getGlobalStats(),this.state.history=o.getHistory(),this.state.questionActivity=this.getQuestionActivity()},renderTrendPage(){this.renderTrendSummary(),this.renderDailyTrend(),this.renderBankTrend(),this.renderRecentHistory()},renderAnalysisPage(){this.renderAnalysisSummary(),this.renderWeakCategories(),this.renderTypeAnalysis(),this.renderBankAnalysis()},renderTrendSummary(){const e=document.getElementById("trend-summary");if(!e)return;const s=this.state.stats,t=this.getDailySeries(1)[0],a=this.getStudyStreak(),n=this.state.history.reduce((i,c)=>i+(c.duration||0),0);e.innerHTML=`
            ${this.renderStatCard("总答题",r.formatNumber(s.totalAnswered),`${s.bankCount} 个题库`,"primary")}
            ${this.renderStatCard("正确率",`${s.accuracy}%`,`${r.formatNumber(s.totalCorrect)} / ${r.formatNumber(s.totalAnswered||0)}`,this.getAccuracyTone(s.accuracy))}
            ${this.renderStatCard("今日答题",r.formatNumber(t.total),t.total>0?`${t.accuracy}% 正确率`:"暂无记录",t.total>0?"success":"")}
            ${this.renderStatCard("连续天数",`${a} 天`,`累计 ${this.formatDuration(n)}`,a>0?"warning":"")}
        `},renderDailyTrend(){const e=document.getElementById("daily-trend"),s=document.getElementById("trend-range");if(!e)return;const t=this.getDailySeries(14),a=t.filter(i=>i.total>0);if(s&&t.length>0&&(s.textContent=`${t[0].label} - ${t[t.length-1].label}`),a.length===0){e.innerHTML=this.renderEmpty("暂无答题记录");return}const n=Math.max(1,...t.map(i=>i.total));e.innerHTML=`
            <div class="daily-chart">
                ${t.map(i=>{const c=i.total>0?Math.max(8,Math.round(i.total/n*100)):0,d=i.total===0?"empty":this.getAccuracyTone(i.accuracy);return`
                        <div class="daily-item" title="${i.fullLabel} ${i.total}题 ${i.accuracy}%">
                            <div class="daily-value">${i.total>0?i.accuracy+"%":""}</div>
                            <div class="daily-track">
                                <div class="daily-fill ${d}" style="height:${c}%"></div>
                            </div>
                            <div class="daily-label">${i.shortLabel}</div>
                        </div>
                    `}).join("")}
            </div>
        `},renderBankTrend(){const e=document.getElementById("bank-trend");if(!e)return;const s=this.state.banks.map(t=>{const a=o.getBankStats(t.id),n=this.getHistoryForBank(t.id);return{bank:t,stats:a,historyCount:n.length}}).sort((t,a)=>a.stats.answered-t.stats.answered);if(s.length===0){e.innerHTML=this.renderEmpty("暂无题库");return}e.innerHTML=`
            <div class="insight-list">
                ${s.map(t=>`
                    <div class="insight-row">
                        <div class="insight-row-main">
                            <div class="insight-row-title">${r.escapeHtml(t.bank.name)}</div>
                            <div class="insight-row-meta">${t.stats.answered}/${t.stats.totalQuestions} 已答 · ${t.historyCount} 次练习</div>
                            <div class="mini-progress">
                                <div class="mini-progress-fill ${this.getAccuracyTone(t.stats.accuracy)}" style="width:${t.stats.progress}%"></div>
                            </div>
                        </div>
                        <div class="insight-row-value">${t.stats.accuracy}%</div>
                    </div>
                `).join("")}
            </div>
        `},renderRecentHistory(){const e=document.getElementById("recent-history");if(!e)return;const s=this.state.history.slice(0,8);if(s.length===0){e.innerHTML=this.renderEmpty("暂无历史记录");return}e.innerHTML=`
            <div class="insight-list">
                ${s.map(t=>{const a=t.total>0?Math.round((t.correct||0)/t.total*100):0;return`
                        <div class="history-line">
                            <div>
                                <div class="history-title">${r.escapeHtml(t.bankName||"未知题库")}</div>
                                <div class="history-meta">${this.getModeLabel(t.mode)} · ${this.formatDateTime(t.timestamp)} · ${this.formatDuration(t.duration||0)}</div>
                            </div>
                            <div class="history-score">${a}%</div>
                        </div>
                    `}).join("")}
            </div>
        `},renderAnalysisSummary(){const e=document.getElementById("analysis-summary");if(!e)return;const s=this.state.stats,t=o.getGlobalWrongStats(),a=o.getTodayDueCount(),n=this.getAllCategoryRows().filter(i=>i.answered>0&&i.accuracy<70).length;e.innerHTML=`
            ${this.renderStatCard("待复习",r.formatNumber(a),"今日到期",a>0?"warning":"success")}
            ${this.renderStatCard("错题",r.formatNumber(t.totalWrong),`${t.details.length} 个题库`,t.totalWrong>0?"danger":"success")}
            ${this.renderStatCard("薄弱点",r.formatNumber(n),"正确率低于 70%",n>0?"warning":"success")}
            ${this.renderStatCard("整体正确率",`${s.accuracy}%`,`${r.formatNumber(s.totalCorrect)} / ${r.formatNumber(s.totalAnswered||0)}`,this.getAccuracyTone(s.accuracy))}
        `},renderWeakCategories(){const e=document.getElementById("weak-categories");if(!e)return;const s=this.getAllCategoryRows().filter(t=>t.answered>0).sort((t,a)=>t.accuracy-a.accuracy||a.answered-t.answered).slice(0,12);if(s.length===0){e.innerHTML=this.renderEmpty("暂无可分析记录");return}e.innerHTML=`
            <div class="insight-list">
                ${s.map(t=>`
                    <div class="insight-row">
                        <div class="insight-row-main">
                            <div class="insight-row-title">${r.escapeHtml(t.name)}</div>
                            <div class="insight-row-meta">${r.escapeHtml(t.bankName)} · ${t.correct}/${t.answered} 正确</div>
                            <div class="mini-progress">
                                <div class="mini-progress-fill ${this.getAccuracyTone(t.accuracy)}" style="width:${t.accuracy}%"></div>
                            </div>
                        </div>
                        <div class="insight-row-value">${t.accuracy}%</div>
                    </div>
                `).join("")}
            </div>
        `},renderTypeAnalysis(){const e=document.getElementById("type-analysis");if(!e)return;const s=this.getTypeRows();if(s.length===0){e.innerHTML=this.renderEmpty("暂无题型数据");return}e.innerHTML=`
            <div class="insight-list">
                ${s.map(t=>{const a=t.answered>0?Math.round(t.correct/t.answered*100):0,n=t.total>0?Math.round(t.answered/t.total*100):0;return`
                        <div class="insight-row">
                            <div class="insight-row-main">
                                <div class="insight-row-title">${this.getTypeLabel(t.type)}</div>
                                <div class="insight-row-meta">${t.answered}/${t.total} 已答 · ${t.correct} 正确</div>
                                <div class="mini-progress">
                                    <div class="mini-progress-fill ${this.getAccuracyTone(a)}" style="width:${n}%"></div>
                                </div>
                            </div>
                            <div class="insight-row-value">${t.answered>0?a+"%":"-"}</div>
                        </div>
                    `}).join("")}
            </div>
        `},renderBankAnalysis(){const e=document.getElementById("bank-analysis");if(e){if(this.state.banks.length===0){e.innerHTML=this.renderEmpty("暂无题库");return}e.innerHTML=`
            <div class="bank-analysis-grid">
                ${this.state.banks.map(s=>{const t=o.getBankStats(s.id),a=o.getWrongQuestions(s.id).length,n=o.getDueQuestions(s.id).length,i=Object.entries(o.getCategoryStats(s.id)).filter(([c,d])=>d.answered>0).sort((c,d)=>c[1].accuracy-d[1].accuracy).slice(0,4);return`
                        <div class="bank-analysis-card">
                            <div class="bank-analysis-head">
                                <div>
                                    <div class="bank-analysis-title">${r.escapeHtml(s.name)}</div>
                                    <div class="bank-analysis-desc">${t.answered}/${t.totalQuestions} 已答 · ${t.accuracy}% 正确率</div>
                                </div>
                                <span class="tag ${t.progress===100?"tag-success":"tag-primary"}">${t.progress}%</span>
                            </div>
                            <div class="mini-progress">
                                <div class="mini-progress-fill ${this.getAccuracyTone(t.accuracy)}" style="width:${t.progress}%"></div>
                            </div>
                            <div class="category-stack">
                                ${i.length>0?i.map(([c,d])=>`
                                    <div class="category-line">
                                        <div class="category-name">${r.escapeHtml(c)}</div>
                                        <div class="category-accuracy">${d.accuracy}%</div>
                                    </div>
                                `).join(""):'<div class="insight-subtle">暂无分类记录</div>'}
                            </div>
                            <div class="bank-analysis-actions">
                                <a class="btn btn-primary btn-sm" href="quiz.html?bank=${encodeURIComponent(s.id)}&mode=all">顺序刷题</a>
                                ${a>0?`<a class="btn btn-secondary btn-sm" href="quiz.html?bank=${encodeURIComponent(s.id)}&mode=wrong">错题 ${a}</a>`:""}
                                ${n>0?`<a class="btn btn-secondary btn-sm" href="quiz.html?bank=${encodeURIComponent(s.id)}&mode=spaced">复习 ${n}</a>`:""}
                            </div>
                        </div>
                    `}).join("")}
            </div>
        `}},renderStatCard(e,s,t,a=""){return`
            <div class="insight-stat">
                <div class="insight-stat-label">${e}</div>
                <div class="insight-stat-value ${a}">${s}</div>
                <div class="insight-stat-meta">${t}</div>
            </div>
        `},renderEmpty(e){return`<div class="empty-state">${r.escapeHtml(e)}</div>`},getDailySeries(e){const s=new Map,t=new Date;for(let a=e-1;a>=0;a--){const n=new Date(t);n.setHours(0,0,0,0),n.setDate(n.getDate()-a);const i=this.getDateKey(n);s.set(i,{key:i,date:n,label:`${n.getMonth()+1}/${n.getDate()}`,shortLabel:e>7?`${n.getDate()}`:`${n.getMonth()+1}/${n.getDate()}`,fullLabel:`${n.getFullYear()}-${n.getMonth()+1}-${n.getDate()}`,total:0,correct:0,accuracy:0})}return this.state.questionActivity.forEach(a=>{const n=this.getDateKey(new Date(a.timestamp)),i=s.get(n);i&&(i.total++,a.correct&&i.correct++)}),[...s.values()].map(a=>({...a,accuracy:a.total>0?Math.round(a.correct/a.total*100):0}))},getStudyStreak(){const e=new Set(this.state.questionActivity.map(a=>this.getDateKey(new Date(a.timestamp))));let s=0;const t=new Date;for(t.setHours(0,0,0,0);e.has(this.getDateKey(t));)s++,t.setDate(t.getDate()-1);return s},getDateKey(e){const s=e.getFullYear(),t=String(e.getMonth()+1).padStart(2,"0"),a=String(e.getDate()).padStart(2,"0");return`${s}-${t}-${a}`},getHistoryForBank(e){return this.state.history.filter(s=>s.bankId===e)},getQuestionActivity(){const e=[];return this.state.banks.forEach(s=>{const t=o.getBankProgress(s.id);Object.entries(t.questions||{}).forEach(([a,n])=>{n.answeredAt&&e.push({bankId:s.id,bankName:s.name,questionId:a,timestamp:n.answeredAt,correct:n.correct===!0})})}),e.sort((s,t)=>new Date(t.timestamp)-new Date(s.timestamp))},getAllCategoryRows(){const e=[];return this.state.banks.forEach(s=>{const t=o.getCategoryStats(s.id);Object.entries(t).forEach(([a,n])=>{e.push({bankId:s.id,bankName:s.name,name:a,...n})})}),e},getTypeRows(){const e=new Map;return this.state.banks.forEach(s=>{const t=o.getBankProgress(s.id);(s.questions||[]).forEach(a=>{const n=a.type||"unknown";e.has(n)||e.set(n,{type:n,total:0,answered:0,correct:0});const i=e.get(n);i.total++;const c=t.questions[a.id];c&&(i.answered++,c.correct&&i.correct++)})}),[...e.values()].sort((s,t)=>t.total-s.total)},getAccuracyTone(e){return e>=85?"success":e>=60?"warning":e>0?"danger":""},getModeLabel(e){return{all:"顺序",random:"随机",shuffle_options:"选项乱序",wrong:"错题",review:"背题",spaced:"复习",bookmark:"收藏",exam:"考试",search:"搜索"}[e]||e||"练习"},getTypeLabel(e){return{single:"单选题",multiple:"多选题",judge:"判断题",fill:"填空题",code:"编程题",essay:"简答题"}[e]||e},formatDuration(e){const s=Math.max(0,Number(e)||0),t=Math.floor(s/60),a=s%60;if(t>=60){const n=Math.floor(t/60),i=t%60;return i>0?`${n}小时${i}分`:`${n}小时`}return t>0?`${t}分${a}秒`:`${a}秒`},formatDateTime(e){if(!e)return"";const s=new Date(e);return`${s.getMonth()+1}/${s.getDate()} ${String(s.getHours()).padStart(2,"0")}:${String(s.getMinutes()).padStart(2,"0")}`}};window.Insights=h;const g=window.location.pathname.split("/").pop()||"index.html",y=g.includes("analysis.html")||g.includes("trend.html"),v=window.location.hash.includes("analysis")||window.location.hash.includes("trend");(y||v)&&(document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>h.init()):h.init());
