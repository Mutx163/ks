import{A as B,U as o,P as _}from"./debug-CmSjtLR0.js";import"./vendor-lucide-CAa9N5Zm.js";function L(i){i.userPage=1,i.userPageSize=20,i.selectedUsers=new Set,i.renderUsers=function(){var m,v,$,h,w;const s=document.getElementById("sec-users"),a=(((m=document.getElementById("search-input"))==null?void 0:m.value)||"").toUpperCase(),e=((v=document.getElementById("user-status-filter"))==null?void 0:v.value)||this.userStatusFilter||"all";this.userStatusFilter=e;let t=this.users.filter(f=>!a||f.id.includes(a)||f.initials.toUpperCase().includes(a));e==="normal"?t=t.filter(f=>!f.banned&&!f.is_admin):e==="banned"?t=t.filter(f=>f.banned):e==="admin"&&(t=t.filter(f=>f.is_admin)),this.sort==="answered"?t.sort((f,b)=>b.total_answered-f.total_answered):this.sort==="duration"?t.sort((f,b)=>b.total_duration-f.total_duration):t.sort((f,b)=>new Date(b.created_at||0)-new Date(f.created_at||0));const n=t.length,c=this.userPageSize||20,l=Math.max(1,Math.ceil(n/c));this.userPage>l&&(this.userPage=l),this.userPage<1&&(this.userPage=1);const p=(this.userPage-1)*c,d=t.slice(p,p+c),r=d.filter(f=>this.selectedUsers.has(f.id)),u=d.length>0&&r.length===d.length,g=B.getSyncCode();s.innerHTML=`
            ${this.pageHeader({title:"用户管理",description:"管理同步码、设备绑定、学习数据、封禁状态与管理员权限。",crumbs:["管理后台","用户管理"],actions:'<button class="abtn primary" onclick="Admin.exportCSV()">导出 CSV</button><button class="abtn" onclick="Admin.loadAll().then(()=>Admin.renderUsers())">刷新</button>'})}
            <div class="toolbar">
                <div class="toolbar-group" style="flex:1">
                    <div class="search-box"><span class="ic">${o.icon("search")}</span><input type="text" id="search-input" placeholder="搜索同步码或姓名..." value="${o.escapeHtml(a||"")}"></div>
                    <select id="user-status-filter" class="admin-select" style="width:auto" onchange="Admin.setUserStatus(this.value)">
                        <option value="all" ${e==="all"?"selected":""}>全部状态</option>
                        <option value="normal" ${e==="normal"?"selected":""}>正常用户</option>
                        <option value="banned" ${e==="banned"?"selected":""}>封禁用户</option>
                        <option value="admin" ${e==="admin"?"selected":""}>管理员</option>
                    </select>
                </div>
                <div class="toolbar-group">
                    <button class="fbtn ${this.sort==="time"?"active":""}" onclick="Admin.setSort('time')">注册时间</button>
                    <button class="fbtn ${this.sort==="answered"?"active":""}" onclick="Admin.setSort('answered')">答题数</button>
                    <button class="fbtn ${this.sort==="duration"?"active":""}" onclick="Admin.setSort('duration')">学习时长</button>
                </div>
            </div>
            <div class="card">
                <div class="card-header">
                    <div style="display:flex;align-items:center;gap:8px">
                        <h3>用户列表</h3>
                        <span class="status-pill info">${t.length}/${this.users.length} 用户</span>
                    </div>
                </div>
                <div class="table-wrap">
                    <table>
                        <thead><tr>
<th><input type="checkbox" ${u?"checked":""} onchange="Admin.toggleUsersOnPage(this.checked)" title="全选/取消本页"></th>
<th>同步码</th><th>姓名</th><th>角色</th><th>设备</th><th>答题</th><th>正确率</th><th>时长</th><th>注册</th><th>状态</th><th>操作</th>
</tr></thead>
                        <tbody>${d.length?d.map(f=>this._userRow(f,g,this.selectedUsers.has(f.id))).join(""):`<tr><td colspan="11">${this.emptyState({title:"没有匹配用户",desc:"请调整搜索词或筛选条件。"})}</td></tr>`}</tbody>
                    </table>
                </div>
            </div>
            ${this.selectedUsers.size>0?`
            <div class="toolbar" style="margin-top:8px;background:var(--admin-primary-weak);border:1px solid var(--admin-primary-border);border-radius:8px;padding:10px 14px">
                <div class="toolbar-group" style="flex:1">
                    <span class="status-pill info">已选 ${this.selectedUsers.size} 人</span>
                </div>
                <div class="toolbar-group">
                    <button class="abtn warn" onclick="Admin.bulkBanUsers(true)">批量封禁</button>
                    <button class="abtn success" onclick="Admin.bulkBanUsers(false)">批量解封</button>
                    <button class="abtn" onclick="Admin.clearUserSelection()">清空选择</button>
                </div>
            </div>`:""}
            ${this.pager({page:this.userPage,pageSize:this.userPageSize,total:n,onPage:"Admin.setUserPage",onPageSize:"Admin.setUserPageSize"})}
        `,($=document.getElementById("search-input"))==null||$.addEventListener("input",()=>this.renderUsers()),(w=(h=o).initIcons)==null||w.call(h)},i._userRow=function(s,a,e=!1){const t=s.total_answered>0?Math.round(s.total_correct/s.total_answered*100):0,n=t>=80?"#15803d":t>=60?"#b45309":"#b91c1c",c=o.escapeHtml(s.initials),l=o.jsSafe(s.initials),p=o.jsSafe(s.id),d=`${s.is_admin?'<span class="badge b-admin">管理员</span>':'<span class="badge">普通用户</span>'}${s.id===a?' <span class="badge b-me">当前设备</span>':""}`;return`<tr style="cursor:pointer" onclick="Admin.showUserDetail('${p}')">
            <td onclick="event.stopPropagation()"><input type="checkbox" ${e?"checked":""} onchange="Admin.toggleUserSelection('${p}')"></td>
            <td><span class="code">${s.id}</span></td>
            <td><strong>${c}</strong></td>
            <td>${d}</td>
            <td>${s.device_count}</td>
            <td><b>${s.total_answered}</b></td>
            <td><div class="acc-bar"><span>${t}%</span><div class="bar"><div class="fill" style="width:${t}%;background:${n}"></div></div></div></td>
            <td>${this.fmtDur(s.total_duration)}</td>
            <td>${i.fmtDate(s.created_at)||"-"}</td>
            <td>${this.statusPill(!s.banned,{enabled:"正常",disabled:"封禁"})}</td>
            <td style="white-space:nowrap" onclick="event.stopPropagation()">
                ${s.id!==a?`<button class="abtn ${s.banned?"":"warn"}" onclick="Admin.banUser('${p}','${l}',${s.banned?0:1})">${s.banned?"解封":"封禁"}</button>`:""}
                ${!s.is_admin&&s.id!==a?`<button class="abtn danger" onclick="Admin.delUser('${p}','${l}')">删除</button>`:""}
            </td>
        </tr>`},i.setSort=function(s){this.sort=s,this.userPage=1,this.renderUsers()},i.setUserStatus=function(s){this.userStatusFilter=s,this.userPage=1,this.renderUsers()},i.setUserPage=function(s){this.userPage=s,this.renderUsers()},i.setUserPageSize=function(s){this.userPageSize=s,this.userPage=1,this.renderUsers()},i.toggleUserSelection=function(s){this.selectedUsers.has(s)?this.selectedUsers.delete(s):this.selectedUsers.add(s),this.renderUsers()},i.toggleUsersOnPage=function(s){var c,l;const a=(((c=document.getElementById("search-input"))==null?void 0:c.value)||"").toUpperCase(),e=((l=document.getElementById("user-status-filter"))==null?void 0:l.value)||this.userStatusFilter||"all";let t=this.users.filter(p=>!a||p.id.includes(a)||p.initials.toUpperCase().includes(a));e==="normal"?t=t.filter(p=>!p.banned&&!p.is_admin):e==="banned"?t=t.filter(p=>p.banned):e==="admin"&&(t=t.filter(p=>p.is_admin)),this.sort==="answered"?t.sort((p,d)=>d.total_answered-p.total_answered):this.sort==="duration"?t.sort((p,d)=>d.total_duration-p.total_duration):t.sort((p,d)=>new Date(d.created_at||0)-new Date(p.created_at||0));const n=(this.userPage-1)*this.userPageSize;t.slice(n,n+this.userPageSize).forEach(p=>{s?this.selectedUsers.add(p.id):this.selectedUsers.delete(p.id)}),this.renderUsers()},i.clearUserSelection=function(){this.selectedUsers.clear(),this.renderUsers()},i.bulkBanUsers=async function(s){const a=[...this.selectedUsers];if(!a.length)return;if(this.logAction("批量操作开始",{operation:s?"批量封禁":"批量解封",userCount:a.length,userIds:a.slice(0,5).join(", ")+(a.length>5?"...":"")}),!await this.confirmDanger({title:s?"批量封禁":"批量解封",message:`将${s?"封禁":"解封"} ${a.length} 个用户`,confirmText:s?"批量封禁":"批量解封",danger:s})){this.logAction("批量操作取消",{operation:s?"批量封禁":"批量解封",userCount:a.length});return}const t=await this.post("/api/admin/batch-ban",{userIds:a,ban:s?1:0});t!=null&&t.ok?(this.logAction("批量操作成功",{operation:s?"批量封禁":"批量解封",affectedCount:t.affected,totalCount:a.length,response:t}),o.showToast(`已${s?"封禁":"解封"} ${t.affected} 人`,"success")):(this.logAction("批量操作失败",{operation:s?"批量封禁":"批量解封",error:(t==null?void 0:t.error)||"未知错误"},"error"),o.showToast((t==null?void 0:t.error)||"操作失败","error")),this.selectedUsers.clear(),await this.loadAll(),this.renderUsers()},i.showUserDetail=async function(s,{pushHash:a=!0}={}){if(a){const t=`#/users/${s}`;if(location.hash!==t){this.navigate(t);return}}const e=document.getElementById("sec-users");e.innerHTML='<div class="loading">加载中...</div>';try{const t=await this.get(`/api/admin/user-detail/${s}`);if(!(t!=null&&t.ok)){e.innerHTML=this.emptyState({title:"加载失败",desc:(t==null?void 0:t.error)||"无法获取用户详情。"});return}const n=t.user,c=t.stats.reduce((m,v)=>m+v.answered,0),l=t.stats.reduce((m,v)=>m+v.correct,0),p=t.stats.reduce((m,v)=>m+v.duration,0),d=o.escapeHtml(n.initials),r=o.jsSafe(n.initials),u=o.jsSafe(n.id),g=B.getSyncCode();e.innerHTML=`
                <div id="user-detail-root">
                ${this.pageHeader({title:`${n.initials} 的用户详情`,description:`同步码 ${n.id} · ${n.banned?"当前已封禁":"当前状态正常"}`,crumbs:["管理后台","用户管理",n.initials||s],actions:'<button class="abtn" onclick="Admin.switchTab(&quot;users&quot;)">返回用户列表</button>'})}
                <div class="card">
                    <div class="card-header">
                        <h3>${d} <span class="code">${n.id}</span></h3>
                        <div class="page-actions">${n.is_admin?' <span class="badge b-admin">管理员</span>':""}${n.banned?this.statusPill(!1,{disabled:"已封禁"}):this.statusPill(!0,{enabled:"正常"})}</div>
                    </div>
                    <div class="card-body" style="padding:16px">
                        <div class="d-grid">
                            <div class="d-item"><div class="dl">注册时间</div><div class="dv">${i.fmtTime(n.created_at)||"-"}</div></div>
                            <div class="d-item"><div class="dl">设备数量</div><div class="dv">${t.devices.length} 台</div></div>
                            <div class="d-item"><div class="dl">总答题</div><div class="dv">${c}</div></div>
                            <div class="d-item"><div class="dl">正确率</div><div class="dv">${c>0?Math.round(l/c*100):0}%</div></div>
                            <div class="d-item"><div class="dl">总时长</div><div class="dv">${this.fmtDur(p)}</div></div>
                            <div class="d-item"><div class="dl">题库数</div><div class="dv">${t.stats.length} 个</div></div>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header"><h3>常用操作</h3><span class="count">用户资料与数据维护</span></div>
                    <div class="card-body" style="padding:16px">
                        <div class="toolbar-group">
                            <button class="abtn primary" onclick="Admin.editUser('${u}','${r}',${n.is_admin?1:0})">编辑信息</button>
                            <button class="abtn primary" onclick="Admin.changeSyncCode('${u}','${r}')">修改同步码</button>
                            <button class="abtn primary" onclick="Admin.adjustStats('${u}','${r}')">调整数据</button>
                            <button class="abtn" onclick="Admin.viewCloudData('${u}')">查看云端数据</button>
                            ${n.id!==g?`<button class="abtn ${n.banned?"":"warn"}" onclick="Admin.banUser('${u}','${r}',${n.banned?0:1})">${n.banned?"解封用户":"封禁用户"}</button>`:""}
                        </div>
                    </div>
                </div>
                ${t.devices.length?`
                <div class="card">
                    <div class="card-header"><h3>设备列表</h3><span class="count">${t.devices.length} 台</span></div>
                    <div class="card-body" style="padding:12px">
                        ${t.devices.map(m=>{const v=o.jsSafe(m.device_id);return`<div class="management-row" style="display:flex;align-items:center;gap:10px;margin-bottom:8px;cursor:default">
                                <code class="code" style="flex:1;overflow:hidden;text-overflow:ellipsis">${o.escapeHtml(m.device_id)}</code>
                                <span style="color:var(--admin-text-tertiary);font-size:12px">${i.fmtDate(m.bound_at)||""}</span>
                                <button class="abtn danger" onclick="Admin.removeDevice('${v}','${u}')">解绑</button>
                            </div>`}).join("")}
                    </div>
                </div>`:""}
                ${t.stats.length?`
                <div class="card">
                    <div class="card-header"><h3>答题统计</h3><span class="count">${t.stats.length} 个题库</span></div>
                    <div class="table-wrap">
                        <table>
                            <thead><tr><th>题库</th><th style="text-align:right">答题</th><th style="text-align:right">正确</th><th style="text-align:right">正确率</th><th style="text-align:right">时长</th></tr></thead>
                            <tbody>${t.stats.map(m=>{const v=m.answered>0?Math.round(m.correct/m.answered*100):0,$=v>=80?"#15803d":v>=60?"#b45309":"#b91c1c";return`<tr>
                                    <td><strong>${o.escapeHtml(m.bank_name||m.bank_id)}</strong></td>
                                    <td style="text-align:right">${m.answered}</td>
                                    <td style="text-align:right">${m.correct}</td>
                                    <td style="text-align:right"><span style="color:${$};font-weight:800">${v}%</span></td>
                                    <td style="text-align:right">${this.fmtDur(m.duration)}</td>
                                </tr>`}).join("")}</tbody>
                        </table>
                    </div>
                </div>`:""}
                ${n.is_admin?"":`
                <div class="danger-zone">
                    <h3>危险操作</h3>
                    <p>这些操作会影响用户数据或账号可用性，请确认对象无误后再执行。</p>
                    <div class="toolbar-group" style="margin-top:12px">
                        <button class="abtn danger" onclick="Admin.resetStats('${u}','${r}')">重置答题数据</button>
                        <button class="abtn danger" onclick="Admin.delUser('${u}','${r}')">删除用户</button>
                    </div>
                </div>`}
                </div>
            `}catch(t){e.innerHTML=`
                ${this.pageHeader({title:"用户详情",description:"用户详情加载失败。",crumbs:["管理后台","用户管理"],actions:'<button class="abtn" onclick="Admin.switchTab(&quot;users&quot;)">返回用户列表</button>'})}
                ${this.emptyState({title:"加载失败",desc:t.message})}
            `}},i.editUser=function(s,a,e){const t=o.escapeHtml(a);document.getElementById("modal-root").innerHTML=`
            <div class="modal-mask" onclick="Admin.onMaskClick(event)">
                <div class="modal-box" style="max-width:400px">
                    <h3>编辑用户</h3>
                    <label>姓名</label><input id="eu-initials" value="${t}" maxlength="4">
                    <label>管理员</label><select id="eu-admin"><option value="0" ${e?"":"selected"}>否</option><option value="1" ${e?"selected":""}>是</option></select>
                    <div class="modal-actions"><button class="ms" onclick="this.closest('.modal-mask').remove()">取消</button><button class="mp" onclick="Admin.saveUser('${o.jsSafe(s)}')">保存</button></div>
                </div>
            </div>`},i.saveUser=async function(s){var n;const a=document.getElementById("eu-initials").value.trim(),e=parseInt(document.getElementById("eu-admin").value);this.logAction("保存用户信息开始",{userId:s,newInitials:a,newIsAdmin:!!e});const t=await this.post("/api/admin/update-user",{targetUserId:s,initials:a,isAdmin:e});t!=null&&t.ok?(this.logAction("保存用户信息成功",{userId:s,updatedFields:{initials:a,isAdmin:!!e},response:t}),o.showToast("已保存","success"),(n=document.querySelector(".modal-mask"))==null||n.remove(),await this.loadAll(),this.showUserDetail(s)):(this.logAction("保存用户信息失败",{userId:s,error:(t==null?void 0:t.error)||"未知错误"},"error"),o.showToast((t==null?void 0:t.error)||"失败","error"))},i.changeSyncCode=function(s,a){document.getElementById("modal-root").innerHTML=`
            <div class="modal-mask" onclick="Admin.onMaskClick(event)">
                <div class="modal-box" style="max-width:400px">
                    <h3>修改同步码</h3>
                    <p style="font-size:13px;color:var(--admin-text-secondary);margin-bottom:12px">用户：${o.escapeHtml(a)} (${s})</p>
                    <label>新同步码</label><input id="new-sync-code" value="${s}" maxlength="6" style="text-transform:uppercase">
                    <div class="modal-actions"><button class="ms" onclick="this.closest('.modal-mask').remove()">取消</button><button class="mp" onclick="Admin.doChangeSyncCode('${o.jsSafe(s)}')">确认修改</button></div>
                </div>
            </div>`},i.doChangeSyncCode=async function(s){var t;const a=document.getElementById("new-sync-code").value.trim().toUpperCase();if(!a||a.length<4){this.logAction("修改同步码失败",{reason:"同步码无效",oldUid:s,newCode:a.slice(0,2)+"***"}),o.showToast("请输入有效同步码","error");return}this.logAction("修改同步码开始",{oldUserId:s,newUserId:a.slice(0,2)+"***"});const e=await this.post("/api/admin/change-sync-code",{oldUserId:s,newUserId:a});e!=null&&e.ok?(this.logAction("修改同步码成功",{oldUserId:s,newUserId:a.slice(0,2)+"***",response:e}),o.showToast("已修改","success"),(t=document.querySelector(".modal-mask"))==null||t.remove(),await this.loadAll(),this.renderUsers()):(this.logAction("修改同步码失败",{oldUserId:s,error:(e==null?void 0:e.error)||"未知错误"},"error"),o.showToast((e==null?void 0:e.error)||"失败","error"))},i.adjustStats=function(s,a){document.getElementById("modal-root").innerHTML=`
            <div class="modal-mask" onclick="Admin.onMaskClick(event)">
                <div class="modal-box" style="max-width:400px">
                    <h3>调整数据</h3>
                    <p style="font-size:13px;color:var(--admin-text-secondary);margin-bottom:12px">用户：${o.escapeHtml(a)} (${s})</p>
                    <label>题库 ID</label><input id="adj-bank-id" placeholder="题库ID">
                    <label>题库名称</label><input id="adj-bank-name" placeholder="题库名称（可选）">
                    <label>添加答题数</label><input id="adj-answered" type="number" value="0">
                    <label>添加正确数</label><input id="adj-correct" type="number" value="0">
                    <label>添加时长（秒）</label><input id="adj-duration" type="number" value="0">
                    <div class="modal-actions"><button class="ms" onclick="this.closest('.modal-mask').remove()">取消</button><button class="mp" onclick="Admin.doAdjustStats('${o.jsSafe(s)}')">确认</button></div>
                </div>
            </div>`},i.doAdjustStats=async function(s){var p;const a=document.getElementById("adj-bank-id").value.trim(),e=document.getElementById("adj-bank-name").value.trim(),t=parseInt(document.getElementById("adj-answered").value)||0,n=parseInt(document.getElementById("adj-correct").value)||0,c=parseInt(document.getElementById("adj-duration").value)||0;this.logAction("调整用户数据开始",{userId:s,bankId:a,bankName:e,adjustment:{answered:t,correct:n,duration:c}});const l=await this.post("/api/admin/adjust-stats",{targetUserId:s,bankId:a,bankName:e,answered:t,correct:n,duration:c});l!=null&&l.ok?(this.logAction("调整用户数据成功",{userId:s,bankId:a,adjustment:{answered:t,correct:n,duration:c},response:l}),o.showToast("已调整","success"),(p=document.querySelector(".modal-mask"))==null||p.remove(),await this.loadAll(),this.showUserDetail(s)):(this.logAction("调整用户数据失败",{userId:s,error:(l==null?void 0:l.error)||"未知错误"},"error"),o.showToast((l==null?void 0:l.error)||"失败","error"))},i.viewCloudData=async function(s){var t,n;const a=await this.get(`/api/admin/user-cloud-data/${s}`);if(!(a!=null&&a.ok)){o.showToast("获取失败","error");return}const e="background:#f8fafc;padding:10px;border-radius:10px;font-size:11px;overflow-x:auto;margin-top:6px;color:#102033;border:1px solid #d9e2ec";document.getElementById("modal-root").innerHTML=`
            <div class="modal-mask" onclick="Admin.onMaskClick(event)">
                <div class="modal-box" style="max-width:560px;max-height:80vh;overflow-y:auto">
                    <h3>云端数据 - ${o.escapeHtml(((t=a.user)==null?void 0:t.initials)||s)}</h3>
                    <p style="font-size:12px;color:var(--admin-text-tertiary);margin-bottom:8px">最后同步：${i.fmtTime((n=a.user)==null?void 0:n.lastSyncAt)||"无"}</p>
                    <div style="margin-bottom:10px">
                        <strong style="font-size:12px">设置</strong>
                        <pre style="${e}">${o.escapeHtml(JSON.stringify(a.settings||{},null,2))}</pre>
                    </div>
                    <div>
                        <strong style="font-size:12px">进度</strong>
                        <pre style="${e}">${o.escapeHtml(JSON.stringify(a.progress||{},null,2))}</pre>
                    </div>
                    <div class="modal-actions"><button class="ms" onclick="this.closest('.modal-mask').remove()">关闭</button></div>
                </div>
            </div>`},i.banUser=async function(s,a,e){if(this.logAction("用户状态切换开始",{userId:s,userName:a,targetState:e?"封禁":"解封"}),!await this.confirmDanger({title:e?"封禁用户":"解封用户",targetLabel:`${a} (${s})`,message:e?"封禁后该用户将无法继续同步数据。":"解封后该用户将恢复正常使用。",confirmText:e?"确认封禁":"确认解封",danger:!!e})){this.logAction("用户状态切换取消",{userId:s,targetState:e?"封禁":"解封"});return}const n=await this.post("/api/admin/ban-user",{targetUserId:s,banned:!!e});if(!(n!=null&&n.ok)){this.logAction("用户状态切换失败",{userId:s,userName:a,targetState:e?"封禁":"解封",error:(n==null?void 0:n.error)||"未知错误"},"error"),o.showToast((n==null?void 0:n.error)||"操作失败","error");return}this.logAction("用户状态切换成功",{userId:s,userName:a,newState:e?"已封禁":"已解封",response:n}),o.showToast(e?"已封禁":"已解封","success"),await this.loadAll(),document.getElementById("user-detail-root")?this.showUserDetail(s):this.renderUsers()},i.resetStats=async function(s,a){if(this.logAction("重置用户数据开始",{userId:s,userName:a,warning:"此操作不可撤销"}),!await this.confirmDanger({title:"重置答题数据",targetLabel:`${a} (${s})`,message:"此操作会清空该用户的答题统计，无法撤销。",requiredText:"RESET",confirmText:"确认重置"})){this.logAction("重置用户数据取消",{userId:s});return}const t=await this.post("/api/admin/reset-stats",{targetUserId:s});t!=null&&t.ok?(this.logAction("重置用户数据成功",{userId:s,userName:a,response:t}),o.showToast("已重置","success"),await this.loadAll(),this.showUserDetail(s)):this.logAction("重置用户数据失败",{userId:s,error:(t==null?void 0:t.error)||"未知错误"},"error")},i.delUser=async function(s,a){if(this.logAction("删除用户开始",{userId:s,userName:a,warning:"此操作不可恢复"}),!await this.confirmDanger({title:"永久删除用户",targetLabel:`${a} (${s})`,message:"用户、设备绑定和相关云端数据将被删除。此操作不可恢复。",requiredText:s,confirmText:"永久删除"})){this.logAction("删除用户取消",{userId:s});return}const t=await this.post("/api/admin/delete-user",{targetUserId:s});t!=null&&t.ok?(this.logAction("删除成功",{userId:s,userName:a,response:t}),o.showToast("已删除","success"),await this.loadAll(),this.renderUsers()):this.logAction("删除用户失败",{userId:s,error:(t==null?void 0:t.error)||"未知错误"},"error")},i.removeDevice=async function(s,a){if(this.logAction("解绑设备开始",{deviceId:s,userId:a}),!await this.confirmDanger({title:"解绑设备",targetLabel:s,message:"解绑后该设备需要重新绑定同步码才能继续同步。",confirmText:"确认解绑"})){this.logAction("解绑设备取消",{deviceId:s,userId:a});return}const t=await this.post("/api/admin/remove-device",{deviceId:s});t!=null&&t.ok?(this.logAction("解绑设备成功",{deviceId:s,userId:a,response:t}),o.showToast("已解绑","success"),this.showUserDetail(a)):this.logAction("解绑设备失败",{deviceId:s,userId:a,error:(t==null?void 0:t.error)||"未知错误"},"error")},i.fmtDate=function(s){if(!s)return"";try{return new Date(s).toLocaleDateString("zh-CN")}catch{return""}},i.fmtTime=function(s){if(!s)return"";try{return new Date(s).toLocaleString("zh-CN")}catch{return""}},i.fmtDur=function(s){if(!s)return"0分";const a=Math.floor(s/3600),e=Math.floor(s%3600/60);return a?`${a}时${e}分`:`${e}分`}}function C(i){i.viewBank=function(e,t){return this.showQuestionList(e,t)};const s=[{key:"all",label:"顺序刷题"},{key:"random",label:"随机"},{key:"shuffle_options",label:"选项乱序"},{key:"wrong",label:"错题"},{key:"review",label:"背题"},{key:"spaced",label:"复习"},{key:"bookmark",label:"收藏"},{key:"exam",label:"考试"}],a={single:"单选",multiple:"多选",judge:"判断",fill:"填空",essay:"简答",multi:"多选",code:"编程",unknown:"未知"};i.renderBanks=async function(){var t,n,c,l,p;const e=document.getElementById("sec-banks");e.innerHTML='<div class="loading">加载中...</div>';try{const d=await this.get("/api/banks?all=true");if(!(d!=null&&d.ok)){e.innerHTML=this.emptyState({title:"题库加载失败",desc:(d==null?void 0:d.error)||"无法获取云端题库列表。"});return}const r=(((t=document.getElementById("bank-admin-search"))==null?void 0:t.value)||this.bankSearch||"").trim().toLowerCase(),u=((n=document.getElementById("bank-status-filter"))==null?void 0:n.value)||this.bankStatusFilter||"all",g=((c=document.getElementById("bank-category-filter"))==null?void 0:c.value)||this.bankCategoryFilter||"all";this.bankSearch=r,this.bankStatusFilter=u,this.bankCategoryFilter=g;const m=[...new Set((d.banks||[]).map(h=>h.category||"未分类"))].sort();let v=d.banks||[];r&&(v=v.filter(h=>`${h.id} ${h.name} ${h.category||""}`.toLowerCase().includes(r))),u==="enabled"?v=v.filter(h=>h.enabled!==!1):u==="disabled"&&(v=v.filter(h=>h.enabled===!1)),g!=="all"&&(v=v.filter(h=>(h.category||"未分类")===g));const $=v.map(h=>{const w=o.jsSafe(h.id),f=h.enabled!==!1;return`
                    <tr style="cursor:pointer" onclick="Admin.showBankDetail('${w}')">
                        <td><strong>${o.escapeHtml(h.name)}</strong><div class="row-sub">${o.escapeHtml(h.id)}</div></td>
                        <td>${o.escapeHtml(h.category||"未分类")}</td>
                        <td>${h.question_count||0}</td>
                        <td>v${h.version||1}</td>
                        <td>${this.statusPill(f,{enabled:"前台可见",disabled:"前台不可见"})}</td>
                        <td>${i.fmtTime(h.updated_at)||"-"}</td>
                        <td style="white-space:nowrap" onclick="event.stopPropagation()">
                            <button class="abtn" onclick="Admin.showBankDetail('${w}')">详情</button>
                            <button class="abtn ${f?"warn":"success"}" onclick="Admin.toggleBank('${w}', ${!f}, 'list')">${f?"禁用":"启用"}</button>
                        </td>
                    </tr>`}).join("");e.innerHTML=`
                ${this.pageHeader({title:"题库管理",description:"管理云端 Worker/D1 题库、前台可见状态、题目内容、做题模式与修改历史。",crumbs:["管理后台","题库管理"],actions:'<button class="abtn" onclick="Admin.clearLocalCache()">清除本地数据</button><button class="abtn primary" onclick="Admin.uploadBank()">上传题库</button><button class="abtn primary" onclick="Admin.createBank()">新建题库</button>'})}
                <div class="toolbar">
                    <div class="toolbar-group" style="flex:1">
                        <div class="search-box"><span class="ic">${o.icon("search")}</span><input id="bank-admin-search" placeholder="搜索题库名称、ID 或分类..." value="${o.escapeHtml(r)}" oninput="Admin.setBankFilters()"></div>
                        <select id="bank-status-filter" class="admin-select" style="width:auto" onchange="Admin.setBankFilters()">
                            <option value="all" ${u==="all"?"selected":""}>全部状态</option>
                            <option value="enabled" ${u==="enabled"?"selected":""}>前台可见</option>
                            <option value="disabled" ${u==="disabled"?"selected":""}>前台不可见</option>
                        </select>
                        <select id="bank-category-filter" class="admin-select" style="width:auto" onchange="Admin.setBankFilters()">
                            <option value="all">全部分类</option>
                            ${m.map(h=>`<option value="${o.escapeHtml(h)}" ${g===h?"selected":""}>${o.escapeHtml(h)}</option>`).join("")}
                        </select>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        <div style="display:flex;align-items:center;gap:8px">
                            <h3>题库列表</h3>
                            <span class="status-pill info">${v.length}/${(d.banks||[]).length} 个题库</span>
                        </div>
                        <span class="count">点击行进入详情</span>
                    </div>
                    <div class="table-wrap">
                        <table>
                            <thead><tr><th>题库</th><th>分类</th><th>题目数</th><th>版本</th><th>前台状态</th><th>更新时间</th><th>操作</th></tr></thead>
                            <tbody>${$||`<tr><td colspan="7">${this.emptyState({title:"没有匹配题库",desc:"请调整搜索词或筛选条件。"})}</td></tr>`}</tbody>
                        </table>
                    </div>
                </div>`,(p=(l=o).initIcons)==null||p.call(l)}catch(d){e.innerHTML=this.emptyState({title:"题库加载失败",desc:d.message})}},i.setBankFilters=function(){var e,t,n;this.bankSearch=(((e=document.getElementById("bank-admin-search"))==null?void 0:e.value)||"").trim().toLowerCase(),this.bankStatusFilter=((t=document.getElementById("bank-status-filter"))==null?void 0:t.value)||"all",this.bankCategoryFilter=((n=document.getElementById("bank-category-filter"))==null?void 0:n.value)||"all",this.renderBanks()},i.showBankDetail=async function(e,{pushHash:t=!0}={}){if(t){const c=`#/banks/${e}`;if(location.hash!==c){this.navigate(c);return}}const n=document.getElementById("sec-banks");n.innerHTML='<div class="loading">加载中...</div>';try{const c=await this.get(`/api/admin/bank/${e}`);if(!(c!=null&&c.ok)){n.innerHTML=this.emptyState({title:"题库详情加载失败",desc:(c==null?void 0:c.error)||"无法读取题库详情。"});return}const l=c.bank,p=l.questions||[],d=l.allowed_modes,r=l.enabled!==!1,u=o.jsSafe(e),g=o.jsSafe(l.name),m=s.map(h=>{const w=!d||d.includes(h.key);return`<label class="tag-pill" style="cursor:pointer;${w?"border-color:var(--admin-primary-border);background:var(--admin-primary-weak);color:var(--admin-primary)":""}">
                    <input type="checkbox" data-mode="${h.key}" ${w?"checked":""} style="margin:0">
                    ${h.label}
                </label>`}).join(""),v={};p.forEach(h=>{const w=h.type||"unknown";v[w]=(v[w]||0)+1});const $=Object.entries(v);n.innerHTML=`
                ${this.pageHeader({title:l.name,description:`${l.description||"管理该题库的基础信息、题目内容、前台可见状态和做题模式。"}`,crumbs:["管理后台","题库管理",l.name],actions:`<button class="abtn" onclick="Admin.renderBanks()">返回题库列表</button><button class="abtn primary" onclick="Admin.editBankInfo('${u}')">编辑信息</button>`})}
                <div class="card">
                    <div class="card-header">
                        <h3>基础信息 <span class="code">${o.escapeHtml(l.id)}</span></h3>
                        <div class="page-actions">${this.statusPill(r,{enabled:"前台可见",disabled:"前台不可见"})}</div>
                    </div>
                    <div class="card-body" style="padding:16px">
                        <div class="d-grid">
                            <div class="d-item"><div class="dl">题目数</div><div class="dv">${p.length}</div></div>
                            <div class="d-item"><div class="dl">版本</div><div class="dv">v${l.version||1}</div></div>
                            <div class="d-item"><div class="dl">分类</div><div class="dv">${o.escapeHtml(l.category||"未分类")}</div></div>
                            <div class="d-item"><div class="dl">更新时间</div><div class="dv">${i.fmtTime(l.updated_at)||"-"}</div></div>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header"><h3>题型分布</h3><span class="count">${p.length} 题</span></div>
                    <div class="card-body" style="padding:16px">
                        <div class="d-grid">
                            ${$.length?$.map(([h,w])=>`
                                <div class="d-item"><div class="dl">${a[h]||h}</div><div class="dv">${w}</div></div>
                            `).join(""):this.emptyState({title:"暂无题目",desc:"可以添加题目或批量导入。"})}
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header"><h3>题目操作</h3><span class="count">内容管理</span></div>
                    <div class="card-body" style="padding:16px">
                        <div class="toolbar-group">
                            <button class="abtn primary" onclick="Admin.showQuestionList('${u}', '${g}')">管理题目 (${p.length})</button>
                            <button class="abtn primary" onclick="Admin.addQuestion('${u}')">添加题目</button>
                            <button class="abtn primary" onclick="Admin.importQuestions('${u}')">批量导入</button>
                            <button class="abtn" onclick="Admin.viewBankHistory('${u}')">修改历史</button>
                            <button class="abtn" onclick="Admin.uploadBank('${u}')">替换题库</button>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        <h3>允许的做题模式</h3>
                        <div class="toolbar-group">
                            <label class="tag-pill" style="cursor:pointer"><input type="checkbox" id="modes-select-all" onchange="Admin.toggleAllModes(this.checked)" ${d?"":"checked"}> 全选</label>
                            <button class="abtn primary" onclick="Admin.saveBankModes('${u}')">保存模式</button>
                        </div>
                    </div>
                    <div class="card-body" style="padding:16px"><div id="bank-modes-list" class="toolbar-group">${m}</div></div>
                </div>
                <div class="danger-zone">
                    <h3>前台状态与危险操作</h3>
                    <p>${r?"当前题库在前台可见。禁用后，首页刷新会立即从云端列表隐藏。":"当前题库在前台不可见。启用后，首页刷新会立即显示。"}</p>
                    <div class="toolbar-group" style="margin-top:12px">
                        <button class="abtn ${r?"warn":"success"}" onclick="Admin.toggleBank('${u}', ${!r}, 'detail')">${r?"禁用题库":"启用题库"}</button>
                        <button class="abtn danger" onclick="Admin.confirmDeleteBank('${u}', '${g}')">删除题库</button>
                    </div>
                </div>`}catch(c){n.innerHTML=`
                ${this.pageHeader({title:"题库详情",description:"题库详情加载失败。",crumbs:["管理后台","题库管理"],actions:'<button class="abtn" onclick="Admin.renderBanks()">返回题库列表</button>'})}
                ${this.emptyState({title:"加载失败",desc:c.message})}`}},i.showQuestionList=async function(e,t="",{pushHash:n=!0}={}){if(n){const l=`#/banks/${e}/questions`;if(location.hash!==l){this.navigate(l);return}}const c=document.getElementById("sec-banks");c.innerHTML='<div class="loading">加载中...</div>';try{const l=await this.get(`/api/admin/bank/${e}`);if(!(l!=null&&l.ok)){c.innerHTML=this.emptyState({title:"题目加载失败",desc:(l==null?void 0:l.error)||"无法获取题目列表。"});return}const p=l.bank.questions||[],d=t||l.bank.name||e;c.innerHTML=`
                ${this.pageHeader({title:"题目管理",description:`${d} · 共 ${p.length} 题。支持搜索、按题型筛选和逐题编辑。`,crumbs:["管理后台","题库管理",d,"题目管理"],actions:`<button class="abtn" onclick="Admin.showBankDetail('${o.jsSafe(e)}')">返回题库详情</button><button class="abtn primary" onclick="Admin.addQuestion('${o.jsSafe(e)}')">添加题目</button>`})}
                <div class="card">
                    <div class="card-header"><h3>${o.escapeHtml(d)} - 题目列表</h3><span class="count">${p.length} 题</span></div>
                    <div class="card-body" style="padding:12px">
                        <div class="toolbar">
                            <div class="toolbar-group" style="flex:1">
                                <input class="admin-input" type="text" id="bank-search" placeholder="搜索题目内容..." oninput="Admin.filterBankQuestions('${o.jsSafe(e)}')">
                                <select class="admin-select" id="bank-type-filter" style="width:auto" onchange="Admin.filterBankQuestions('${o.jsSafe(e)}')">
                                    <option value="">全部题型</option><option value="single">单选</option><option value="multiple">多选</option><option value="judge">判断</option><option value="fill">填空</option><option value="essay">简答</option><option value="code">编程</option>
                                </select>
                            </div>
                        </div>
                        <div id="bank-questions-list">${this._renderQuestionList(e,p)}</div>
                    </div>
                </div>`}catch(l){c.innerHTML=`
                ${this.pageHeader({title:"题目管理",description:"题目列表加载失败。",crumbs:["管理后台","题库管理"],actions:`<button class="abtn" onclick="Admin.showBankDetail('${o.jsSafe(e)}')">返回题库详情</button>`})}
                ${this.emptyState({title:"加载失败",desc:l.message})}`}},i.toggleAllModes=function(e){document.querySelectorAll("#bank-modes-list input[type=checkbox]").forEach(t=>{t.checked=e;const n=t.closest("label");n&&(n.style.background=e?"var(--admin-primary-weak)":"",n.style.borderColor=e?"var(--admin-primary-border)":"",n.style.color=e?"var(--admin-primary)":"")})},i.saveBankModes=async function(e){const t=document.querySelectorAll("#bank-modes-list input[type=checkbox]"),n=Array.from(t).filter(l=>l.checked).map(l=>l.dataset.mode);this.logAction("保存做题模式开始",{bankId:e,selectedModes:n,modeCount:n.length,isAllModes:n.length===s.length});const c=await this.put(`/api/admin/bank/${e}/settings`,{allowed_modes:n.length===s.length?null:n});c!=null&&c.ok?(this.logAction("保存做题模式成功",{bankId:e,savedModes:n.length===s.length?"全部模式":n,response:c}),o.showToast("做题模式已保存","success")):(this.logAction("保存做题模式失败",{bankId:e,error:(c==null?void 0:c.error)||"未知错误"},"error"),o.showToast((c==null?void 0:c.error)||"保存失败","error"))},i._renderQuestionList=function(e,t){return t.length?t.map(n=>`
            <div class="question-item management-row" data-qid="${n.id}" style="margin-bottom:8px" onclick="Admin.editQuestion('${o.jsSafe(e)}',${n.id})">
                <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:10px">
                    <div style="flex:1;min-width:0">
                        <span class="code">#${n.id}</span>
                        <span class="tag-pill">${a[n.type]||n.type||"未知"}</span>
                        ${n.category?`<span class="tag-pill">${o.escapeHtml(n.category)}</span>`:""}
                        <div class="row-title" style="margin-top:8px">${o.escapeHtml((n.question||"").slice(0,110))}${(n.question||"").length>110?"...":""}</div>
                    </div>
                    <div class="toolbar-group" style="flex-shrink:0" onclick="event.stopPropagation()">
                        <button class="abtn" onclick="Admin.editQuestion('${o.jsSafe(e)}',${n.id})">编辑</button>
                        <button class="abtn danger" onclick="Admin.deleteQuestion('${o.jsSafe(e)}',${n.id})">删除</button>
                    </div>
                </div>
            </div>
        `).join(""):this.emptyState({title:"暂无题目",desc:"可以添加题目或批量导入 JSON 题目。"})},i.filterBankQuestions=async function(e){var p,d;const t=(((p=document.getElementById("bank-search"))==null?void 0:p.value)||"").toLowerCase(),n=((d=document.getElementById("bank-type-filter"))==null?void 0:d.value)||"",c=await this.get(`/api/admin/bank/${e}`);if(!(c!=null&&c.ok))return;let l=c.bank.questions||[];n&&(l=l.filter(r=>r.type===n)),t&&(l=l.filter(r=>(r.question||"").toLowerCase().includes(t))),document.getElementById("bank-questions-list").innerHTML=this._renderQuestionList(e,l)},i.uploadBank=function(e){document.getElementById("modal-root").innerHTML=`
            <div class="modal-mask" onclick="Admin.onMaskClick(event)">
                <div class="modal-box" style="max-width:520px">
                    <h3>${e?"替换题库 "+o.escapeHtml(e):"上传题库"}</h3>
                    <p style="font-size:13px;color:${e?"var(--admin-danger)":"var(--admin-text-secondary)"};margin-bottom:12px">${e?"替换会覆盖当前题库内容，请先确认 JSON 文件来源可靠。":"上传 JSON 题库到云端 D1。文件需包含 id、name、questions 字段。"}</p>
                    <input type="file" id="upload-bank-file" accept=".json" style="margin:12px 0">
                    <div class="modal-actions"><button class="ms" onclick="this.closest('.modal-mask').remove()">取消</button><button class="mp" onclick="Admin.doUploadBank('${e||""}')">${e?"确认替换":"上传"}</button></div>
                </div>
            </div>`},i.doUploadBank=async function(e){var n,c,l;const t=document.getElementById("upload-bank-file").files[0];if(!t){this.logAction("题库上传失败",{reason:"未选择文件",existingId:e}),o.showToast("请选择文件","error");return}this.logAction("题库上传开始",{fileName:t.name,fileSize:t.size,fileType:t.type,existingId:e||null,isReplace:!!e});try{const p=await t.text(),d=JSON.parse(p);this.logAction("题库JSON解析成功",{bankId:d.id,bankName:d.name,questionCount:((n=d.questions)==null?void 0:n.length)||0,hasVersion:!!d.version,hasCategory:!!d.category});const r=await this.post("/api/admin/upload-bank",{bank:d,existingId:e||null});r!=null&&r.ok?(this.logAction("题库上传成功",{bankId:d.id,bankName:d.name,questionCount:((c=d.questions)==null?void 0:c.length)||0,isReplace:!!e,response:r}),o.showToast(e?"替换成功":"上传成功","success"),(l=document.querySelector(".modal-mask"))==null||l.remove(),e?this.showBankDetail(e):this.renderBanks()):(this.logAction("题库上传失败",{bankId:d.id,error:(r==null?void 0:r.error)||"未知错误"},"error"),o.showToast((r==null?void 0:r.error)||"失败","error"))}catch(p){this.logAction("题库上传异常",{fileName:t.name,error:p.message,errorName:p.name},"error"),o.showToast("JSON格式错误","error")}},i.createBank=function(){document.getElementById("modal-root").innerHTML=`
            <div class="modal-mask" onclick="Admin.onMaskClick(event)">
                <div class="modal-box" style="max-width:420px">
                    <h3>新建题库</h3>
                    <label>题库 ID</label><input id="new-bank-id" placeholder="英文，如 math-101">
                    <label>题库名称</label><input id="new-bank-name" placeholder="如 高等数学">
                    <label>分类</label><input id="new-bank-category" placeholder="如 数学">
                    <div class="modal-actions"><button class="ms" onclick="this.closest('.modal-mask').remove()">取消</button><button class="mp" onclick="Admin.doCreateBank()">创建</button></div>
                </div>
            </div>`},i.doCreateBank=async function(){var l;const e=document.getElementById("new-bank-id").value.trim(),t=document.getElementById("new-bank-name").value.trim(),n=document.getElementById("new-bank-category").value.trim();if(!e||!t){this.logAction("题库创建失败",{reason:"缺少必填字段",id:e,name:t,category:n}),o.showToast("请填写ID和名称","error");return}this.logAction("题库创建开始",{id:e,name:t,category:n||"未分类"});const c=await this.post("/api/admin/create-bank",{id:e,name:t,category:n});c!=null&&c.ok?(this.logAction("题库创建成功",{bankId:e,bankName:t,category:n||"未分类",response:c}),o.showToast("创建成功","success"),(l=document.querySelector(".modal-mask"))==null||l.remove(),this.renderBanks()):(this.logAction("题库创建失败",{bankId:e,bankName:t,error:(c==null?void 0:c.error)||"未知错误"},"error"),o.showToast((c==null?void 0:c.error)||"失败","error"))},i.toggleBank=async function(e,t,n="list"){if(this.logAction("题库状态切换开始",{bankId:e,targetState:t?"启用":"禁用",refreshMode:n,currentTab:this.tab}),!await this.confirmDanger({title:t?"启用题库":"禁用题库",targetLabel:e,message:t?"启用后题库会重新出现在前台首页。":"禁用后题库会从前台首页隐藏，用户不能再进入该题库。",confirmText:t?"确认启用":"确认禁用",danger:!t})){this.logAction("题库状态切换取消",{bankId:e,targetState:t?"启用":"禁用"});return}const l=await this.put(`/api/admin/bank/${e}/toggle`,{enabled:t});l!=null&&l.ok?(this.logAction("题库状态切换成功",{bankId:e,newState:t?"已启用":"已禁用",refreshMode:n,response:l}),o.showToast(t?"题库已启用，前台刷新后立即可见":"题库已禁用，前台刷新后立即隐藏","success"),n==="detail"?this.showBankDetail(e):this.renderBanks()):(this.logAction("题库状态切换失败",{bankId:e,targetState:t?"启用":"禁用",error:(l==null?void 0:l.error)||"未知错误"},"error"),o.showToast((l==null?void 0:l.error)||"失败","error"))},i.confirmDeleteBank=async function(e,t){await this.confirmDanger({title:"永久删除题库",targetLabel:`${t} (${e})`,message:"此操作不可恢复，题库基础信息、题目和相关设置都会被删除。",requiredText:e,confirmText:"永久删除"})&&this.doDeleteBank(e)},i.doDeleteBank=async function(e){var n;this.logAction("题库删除开始",{bankId:e,currentTab:this.tab,warning:"此操作不可恢复"});const t=await this.delete(`/api/admin/bank/${e}`);t!=null&&t.ok?(this.logAction("题库删除成功",{bankId:e,response:t}),o.showToast("已删除","success"),(n=document.querySelector(".modal-mask"))==null||n.remove(),this.renderBanks()):(this.logAction("题库删除失败",{bankId:e,error:(t==null?void 0:t.error)||"未知错误"},"error"),o.showToast((t==null?void 0:t.error)||"失败","error"))},i.clearLocalCache=async function(){await this.confirmDanger({title:"清除本地数据",targetLabel:"当前浏览器",message:"将清除当前浏览器中的进度、设置、历史和收藏。云端数据不会被删除。",requiredText:"CLEAR",confirmText:"确认清除"})&&this.doClearLocalCache()},i.doClearLocalCache=function(){var e;this.logAction("清除本地缓存开始",{currentTab:this.tab,storageKeys:Object.keys(localStorage).filter(t=>t.startsWith("quiz_")).length});try{Storage.clearAll(),this.logAction("清除本地缓存成功",{clearedKeys:Object.keys(localStorage).filter(t=>t.startsWith("quiz_")).length}),console.log("[Admin] ✅ 本地数据已清除"),o.showToast("本地数据已清除，2秒后刷新页面","success"),(e=document.querySelector(".modal-mask"))==null||e.remove(),setTimeout(()=>location.reload(),2e3)}catch(t){this.logAction("清除本地缓存失败",{error:t.message,errorName:t.name},"error"),console.error("[Admin] 清除数据失败:",t),o.showToast("清除失败: "+t.message,"error")}},i.editBankInfo=async function(e){const t=await this.get(`/api/admin/bank/${e}`);if(!(t!=null&&t.ok)){o.showToast("获取题库信息失败","error");return}const n=t.bank;document.getElementById("modal-root").innerHTML=`
            <div class="modal-mask" onclick="Admin.onMaskClick(event)">
                <div class="modal-box" style="max-width:460px">
                    <h3>编辑题库信息</h3>
                    <p style="font-size:12px;color:var(--admin-text-tertiary);margin-bottom:14px">ID：${o.escapeHtml(n.id)}</p>
                    <label>题库名称 *</label>
                    <input id="edit-bank-name" value="${o.escapeHtml(n.name)}" placeholder="题库名称">
                    <label>题库描述</label>
                    <textarea id="edit-bank-desc" rows="3" placeholder="题库描述（可选）">${o.escapeHtml(n.description||"")}</textarea>
                    <label>分类</label>
                    <input id="edit-bank-category" value="${o.escapeHtml(n.category||"")}" placeholder="如：数学、编程、英语">
                    <div class="modal-actions">
                        <button class="ms" onclick="this.closest('.modal-mask').remove()">取消</button>
                        <button class="mp" onclick="Admin.doEditBankInfo('${o.jsSafe(e)}')">保存</button>
                    </div>
                </div>
            </div>`},i.doEditBankInfo=async function(e){var p;const t=document.getElementById("edit-bank-name").value.trim(),n=document.getElementById("edit-bank-desc").value.trim(),c=document.getElementById("edit-bank-category").value.trim();if(!t){this.logAction("题库信息更新失败",{bankId:e,reason:"名称为空"}),o.showToast("题库名称不能为空","error");return}this.logAction("题库信息更新开始",{bankId:e,newName:t,newDescription:n?n.slice(0,50)+"...":"(空)",newCategory:c||"未分类"});const l=await this.put(`/api/admin/bank/${e}/settings`,{name:t,description:n,category:c});l!=null&&l.ok?(this.logAction("题库信息更新成功",{bankId:e,updatedFields:{name:t,category:c},response:l}),o.showToast("题库信息已更新","success"),(p=document.querySelector(".modal-mask"))==null||p.remove(),this.showBankDetail(e)):(this.logAction("题库信息更新失败",{bankId:e,error:(l==null?void 0:l.error)||"未知错误"},"error"),o.showToast((l==null?void 0:l.error)||"更新失败","error"))},i.viewBankHistory=async function(e){const t=await this.get(`/api/admin/bank/${e}/history`);if(!(t!=null&&t.ok)){o.showToast("获取失败","error");return}const n={};this.users&&this.users.forEach(l=>{n[l.id]=l.initials});const c={add_question:"添加题目",edit_question:"编辑题目",delete_question:"删除题目",batch_import:"批量导入",toggle:"状态变更",update_settings:"更新设置",create:"创建题库",replace:"替换题库"};document.getElementById("modal-root").innerHTML=`
            <div class="modal-mask" onclick="Admin.onMaskClick(event)">
                <div class="modal-box" style="max-width:620px;max-height:80vh;overflow-y:auto">
                    <h3>修改历史</h3>
                    <div style="margin-top:12px">${t.history.length?t.history.map(l=>{const p=n[l.operator]||l.operator||"未知";return`
                        <div class="management-row" style="cursor:default;margin-bottom:8px">
                            <div style="display:flex;justify-content:space-between;align-items:center;gap:12px">
                                <span class="status-pill info">${c[l.action]||l.action}</span>
                                <span style="color:var(--admin-text-tertiary);font-size:12px">${i.fmtTime(l.created_at)}</span>
                            </div>
                            <div style="margin-top:8px;color:var(--admin-text-secondary);font-size:13px">${o.escapeHtml(l.detail)}</div>
                            <div style="margin-top:4px;color:var(--admin-text-tertiary);font-size:12px">操作人：${o.escapeHtml(p)} (${o.escapeHtml(l.operator||"")})</div>
                        </div>`}).join(""):this.emptyState({title:"暂无历史"})}</div>
                    <div class="modal-actions"><button class="ms" onclick="this.closest('.modal-mask').remove()">关闭</button></div>
                </div>
            </div>`},i.importQuestions=function(e){document.getElementById("modal-root").innerHTML=`
            <div class="modal-mask" onclick="Admin.onMaskClick(event)">
                <div class="modal-box" style="max-width:560px">
                    <h3>批量导入题目</h3>
                    <p style="font-size:13px;color:var(--admin-text-secondary);margin-bottom:12px">JSON 数组格式，每题含 question、options、answer 等字段。导入前建议先备份。</p>
                    <textarea id="import-questions-json" rows="10" placeholder='[{"question":"题目","options":["A.","B."],"answer":"A"}]' style="font-family:monospace;font-size:12px"></textarea>
                    <div class="modal-actions"><button class="ms" onclick="this.closest('.modal-mask').remove()">取消</button><button class="mp" onclick="Admin.doImportQuestions('${o.jsSafe(e)}')">导入</button></div>
                </div>
            </div>`},i.doImportQuestions=async function(e){var n;const t=document.getElementById("import-questions-json").value;this.logAction("批量导入题目开始",{bankId:e,jsonLength:t.length});try{const c=JSON.parse(t);if(!Array.isArray(c))throw this.logAction("批量导入题目失败",{bankId:e,reason:"非数组格式"}),new Error("需要数组格式");this.logAction("批量导入JSON解析成功",{bankId:e,questionCount:c.length,types:[...new Set(c.map(p=>p.type||"unknown"))]});const l=await this.post(`/api/admin/bank/${e}/import-questions`,{questions:c});l!=null&&l.ok?(this.logAction("批量导入题目成功",{bankId:e,importedCount:l.added,totalCount:c.length,response:l}),o.showToast(`已导入 ${l.added} 题`,"success"),(n=document.querySelector(".modal-mask"))==null||n.remove(),this.showBankDetail(e)):(this.logAction("批量导入题目失败",{bankId:e,error:(l==null?void 0:l.error)||"未知错误"},"error"),o.showToast((l==null?void 0:l.error)||"失败","error"))}catch(c){this.logAction("批量导入题目异常",{bankId:e,error:c.message,errorName:c.name},"error"),o.showToast("JSON格式错误: "+c.message,"error")}},i.fmtTime=function(e){if(!e)return"";try{return new Date(e).toLocaleString("zh-CN")}catch{return""}}}const H={PROVIDERS:{wwpic:{name:"WwoPic",upload:(i,s)=>new Promise(a=>{const e=new XMLHttpRequest,t=new FormData;t.append("file",i),t.append("storage_id","3"),e.upload.addEventListener("progress",n=>{n.lengthComputable&&s&&s(Math.round(n.loaded/n.total*100))}),e.addEventListener("load",()=>{var n;try{const c=JSON.parse(e.responseText);c.status==="success"&&((n=c.data)!=null&&n.public_url)?a({success:!0,url:c.data.public_url}):a({success:!1,error:c.message||"上传失败"})}catch{a({success:!1,error:"解析响应失败"})}}),e.addEventListener("error",()=>a({success:!1,error:"网络错误"})),e.open("POST","https://img.wwoyun.cn/api/v2/upload"),e.setRequestHeader("Authorization","Bearer 171|ZDEnLUKTwjfvXblPTp7mPsJnB71HZZOcB8fHeiyj401e1955"),e.send(t)})}},getProvider(){return"wwpic"},async upload(i,s){if(!i)return{success:!1,error:"请选择文件"};if(!["image/jpeg","image/png","image/gif","image/webp","image/bmp"].includes(i.type))return{success:!1,error:"仅支持 JPG/PNG/GIF/WebP/BMP 格式"};if(i.size>10*1024*1024)return{success:!1,error:"文件大小不能超过 10MB"};const e=this.getProvider(),t=this.PROVIDERS[e];if(!t)return{success:!1,error:"未知图床"};try{console.log(`[ImageUploader] 📤 上传到 ${t.name}...`);const n=await t.upload(i,s);return n.success&&console.log("[ImageUploader] ✅ 上传成功:",n.url),n}catch(n){return console.error("[ImageUploader] ❌ 上传异常:",n),{success:!1,error:"网络错误: "+n.message}}},showDialog(i){const s=document.createElement("div");s.className="modal-mask",s.innerHTML=`
            <div class="modal-box" style="max-width: 400px;">
                <h3>📤 上传图片</h3>
                <div id="upload-area" style="border: 2px dashed var(--border); border-radius: var(--radius); padding: 30px; text-align: center; cursor: pointer; transition: all 0.2s;">
                    <div style="font-size: 36px; margin-bottom: 8px;">📁</div>
                    <div style="color: var(--text-secondary);">点击选择图片或拖拽到此处</div>
                    <div style="font-size: 11px; color: var(--text-tertiary); margin-top: 4px;">支持 JPG/PNG/GIF/WebP，最大 10MB</div>
                    <input type="file" id="upload-file" accept="image/*" style="display: none;">
                </div>
                <div id="upload-preview" style="display: none; margin-top: 12px;">
                    <img id="preview-img" style="max-width: 100%; max-height: 200px; border-radius: var(--radius);">
                </div>
                <div id="upload-status" style="margin-top: 8px; font-size: 12px; color: var(--text-tertiary);"></div>
                <div class="modal-actions" style="margin-top: 16px;">
                    <button class="ms" onclick="this.closest('.modal-mask').remove()">取消</button>
                    <button class="mp" id="btn-upload" disabled>上传</button>
                </div>
            </div>
        `,document.body.appendChild(s);const a=s.querySelector("#upload-area"),e=s.querySelector("#upload-file"),t=s.querySelector("#upload-preview"),n=s.querySelector("#preview-img"),c=s.querySelector("#upload-status"),l=s.querySelector("#btn-upload");let p=null;a.addEventListener("click",()=>e.click()),a.addEventListener("dragover",r=>{r.preventDefault(),a.style.borderColor="var(--primary)",a.style.background="var(--primary-light)"}),a.addEventListener("dragleave",()=>{a.style.borderColor="var(--border)",a.style.background=""}),a.addEventListener("drop",r=>{r.preventDefault(),a.style.borderColor="var(--border)",a.style.background="",r.dataTransfer.files.length>0&&d(r.dataTransfer.files[0])}),e.addEventListener("change",r=>{r.target.files.length>0&&d(r.target.files[0])});function d(r){p=r,t.style.display="block",n.src=URL.createObjectURL(r),c.textContent=`已选择: ${r.name} (${(r.size/1024).toFixed(1)}KB)`,l.disabled=!1}l.addEventListener("click",async()=>{if(!p)return;l.disabled=!0,l.textContent="上传中...",c.style.color="var(--text-tertiary)",c.innerHTML=`
                <div style="margin-top:8px">
                    <div style="background:var(--bg-hover);border-radius:4px;height:6px;overflow:hidden">
                        <div id="upload-progress-bar" style="background:var(--primary);height:100%;width:0%;transition:width 0.2s"></div>
                    </div>
                    <div id="upload-progress-text" style="font-size:11px;margin-top:4px;text-align:center">准备上传...</div>
                </div>
            `;const r=s.querySelector("#upload-progress-bar"),u=s.querySelector("#upload-progress-text"),g=await H.upload(p,m=>{r.style.width=m+"%",u.textContent=`上传中... ${m}%`});g.success?(r.style.width="100%",r.style.background="var(--success)",u.textContent="✅ 上传成功！",u.style.color="var(--success)",setTimeout(()=>{s.remove(),i&&i(g.url)},500)):(r.style.background="var(--danger)",u.textContent="❌ "+g.error,u.style.color="var(--danger)",l.disabled=!1,l.textContent="重试")}),s.addEventListener("click",r=>{r.target===s&&s.remove()})}};window.ImageUploader=H;function D(i){i.addQuestion=function(s){document.getElementById("modal-root").innerHTML=`
            <div class="modal-mask" onclick="Admin.onMaskClick(event)">
                <div class="qe-modal">
                    <div class="qe-header"><h3>添加题目</h3><button class="close-btn" onclick="this.closest('.modal-mask').remove()">✕</button></div>
                    ${this._editorHTML(s,null,!0)}
                </div>
            </div>`,this._preview()},i.editQuestion=async function(s,a){const e=await this.get(`/api/admin/bank/${s}`);if(!(e!=null&&e.ok))return;const t=(e.bank.questions||[]).find(n=>n.id===a);if(!t){o.showToast("题目不存在","error");return}document.getElementById("modal-root").innerHTML=`
            <div class="modal-mask" onclick="Admin.onMaskClick(event)">
                <div class="qe-modal">
                    <div class="qe-header"><h3>编辑题目 #${a}</h3><button class="close-btn" onclick="this.closest('.modal-mask').remove()">✕</button></div>
                    ${this._editorHTML(s,t,!1)}
                </div>
            </div>`,this._preview()},i._editorHTML=function(s,a,e){const t=(a==null?void 0:a.type)||"single",n=a==null?void 0:a.answer,c=(a==null?void 0:a.options)||[],l=(a==null?void 0:a.difficulty)||1,p=t==="single"||t==="multiple"||t==="multi",d=t==="judge",r=t==="essay"||t==="fill",u=t==="code",g=u||!!(a!=null&&a.code);let m="";t==="judge"?m=n===!0?"true":n===!1?"false":"":Array.isArray(n)?m=n.join(""):m=String(n||"");let v="";if(p){const b="ABCDEFGH",S=c.map(k=>typeof k=="string"?{text:k,img:""}:{text:k.text||"",img:k.img||""});for(;S.length<4;)S.push({text:"",img:""});v=S.map((k,I)=>{const y=b[I],x=m.includes(y),T=k.img?`<img src="${o.escapeHtml(k.img)}" style="max-width:60px;max-height:40px;border-radius:4px;margin-left:4px;vertical-align:middle;border:1px solid var(--border)">`:"",E=k.img?'<button type="button" class="abtn danger" style="padding:1px 4px;font-size:10px" onclick="event.stopPropagation();Admin._removeOptionImage(this)" title="删除选项图片">🗑️</button>':"";return`<div class="qe-opt-item ${x?"selected":""}" data-letter="${y}" onclick="Admin._selectOption('${y}')">
                    <span class="qe-opt-indicator ${t==="multiple"||t==="multi"?"checkbox":"radio"}">${x?t==="multiple"||t==="multi"?"☑":"●":t==="multiple"||t==="multi"?"☐":"○"}</span>
                    <span class="qe-opt-letter">${y}.</span>
                    <input class="qe-opt-input" value="${o.escapeHtml(k.text)}" placeholder="输入选项内容..." oninput="Admin._preview()" onclick="event.stopPropagation()">
                    <input type="hidden" class="qe-opt-img" value="${o.escapeHtml(k.img)}">
                    ${T}
                    <button type="button" class="abtn" style="padding:1px 4px;font-size:10px" onclick="event.stopPropagation();Admin._uploadOptionImage(this)" title="添加选项图片">📷</button>
                    ${E}
                    <button class="qe-opt-del" onclick="event.stopPropagation();Admin._removeOption(this)" title="删除选项">✕</button>
                </div>`}).join("")}let $="";if(r){const b=(a==null?void 0:a.answerImg)||"";$=`<div class="qe-fill-wrap">
                <textarea id="eq-fill-answer" rows="3" placeholder="输入参考答案..." oninput="Admin._preview()">${o.escapeHtml(m)}</textarea>
                <div style="display:flex;gap:8px;margin-top:6px;align-items:center">
                    <button type="button" class="abtn primary" style="padding:4px 10px;font-size:11px" onclick="Admin._uploadAnswerImage()">📷 添加答案图片</button>
                    <input type="text" id="eq-answer-img" value="${o.escapeHtml(b)}" placeholder="或直接输入图片URL" style="flex:1;padding:4px 8px;font-size:11px;border:1px solid var(--border);border-radius:var(--radius);background:var(--bg-card);color:var(--text)">
                </div>
                <div id="eq-answer-img-preview" style="${b?"":"display:none"};margin-top:6px">
                    <img id="eq-answer-img-thumb" src="${o.escapeHtml(b)}" style="max-width:200px;max-height:100px;border-radius:var(--radius);border:1px solid var(--border)">
                    <button type="button" class="abtn danger" style="padding:2px 6px;font-size:10px;margin-left:4px" onclick="Admin._removeAnswerImage()">删除</button>
                </div>
            </div>`}const h=(a==null?void 0:a.codeLanguage)||"c",w=(a==null?void 0:a.code)||u&&(a==null?void 0:a.answer)||"";let f="";return g&&(f=`<div class="qe-fill-wrap">
                <div style="display:flex;gap:8px;margin-bottom:8px;align-items:center">
                    <label style="font-size:12px;font-weight:600;">代码语言：</label>
                    <select id="eq-code-lang" style="padding:4px 8px;border:1px solid var(--border);border-radius:6px;font-size:12px;background:var(--bg-card);color:var(--text)">
                        <option value="c" ${h==="c"?"selected":""}>C</option>
                        <option value="cpp" ${h==="cpp"?"selected":""}>C++</option>
                        <option value="java" ${h==="java"?"selected":""}>Java</option>
                        <option value="python" ${h==="python"?"selected":""}>Python</option>
                        <option value="javascript" ${h==="javascript"?"selected":""}>JavaScript</option>
                        <option value="go" ${h==="go"?"selected":""}>Go</option>
                        <option value="rust" ${h==="rust"?"selected":""}>Rust</option>
                        <option value="sql" ${h==="sql"?"selected":""}>SQL</option>
                    </select>
                </div>
                <textarea id="eq-code" rows="8" placeholder="输入代码..." style="font-family:monospace;font-size:13px;line-height:1.5" oninput="Admin._preview()">${o.escapeHtml(w)}</textarea>
            </div>`),`
        <div class="qe-tabs">
            <button class="qe-tab active" onclick="Admin._switchEditorTab('edit')" id="qe-tab-edit">编辑</button>
            <button class="qe-tab" onclick="Admin._switchEditorTab('preview')" id="qe-tab-preview">预览</button>
        </div>
        <div class="qe-body">
            <div class="qe-panel active" id="qe-panel-edit">
                <div class="qe-row">
                    <div class="qe-field">
                        <label>题型</label>
                        <select id="eq-type" onchange="Admin._onTypeChange()">
                            <option value="single" ${t==="single"?"selected":""}>单选题</option>
                            <option value="multiple" ${t==="multiple"||t==="multi"?"selected":""}>多选题</option>
                            <option value="judge" ${t==="judge"?"selected":""}>判断题</option>
                            <option value="fill" ${t==="fill"?"selected":""}>填空题</option>
                            <option value="essay" ${t==="essay"?"selected":""}>简答题</option>
                            <option value="code" ${t==="code"?"selected":""}>编程题</option>
                        </select>
                    </div>
                    <div class="qe-field">
                        <label>难度</label>
                        <div class="qe-stars" id="eq-diff-stars">
                            ${[1,2,3].map(b=>`<span class="qe-star ${b<=l?"on":""}" onclick="Admin._setDiff(${b})">★</span>`).join("")}
                        </div>
                        <input type="hidden" id="eq-difficulty" value="${l}">
                    </div>
                </div>
                <div class="qe-field">
                    <label>分类</label>
                    <input id="eq-category" value="${o.escapeHtml((a==null?void 0:a.category)||"")}" placeholder="如: 编程指令">
                </div>
                <div class="qe-field">
                    <label>题目内容</label>
                    <textarea id="eq-question" rows="3" placeholder="输入题目内容..." oninput="Admin._preview()">${o.escapeHtml((a==null?void 0:a.question)||"")}</textarea>
                    <div style="display:flex;gap:8px;margin-top:6px;align-items:center">
                        <button type="button" class="abtn primary" style="padding:4px 10px;font-size:11px" onclick="Admin._uploadQuestionImage()">📷 添加题目图片</button>
                        <input type="text" id="eq-img" value="${o.escapeHtml((a==null?void 0:a.img)||(a==null?void 0:a.image)||"")}" placeholder="或直接输入图片URL" style="flex:1;padding:4px 8px;font-size:11px;border:1px solid var(--border);border-radius:var(--radius);background:var(--bg-card);color:var(--text)">
                    </div>
                    <div id="eq-img-preview" style="${a!=null&&a.img||a!=null&&a.image?"":"display:none"};margin-top:6px">
                        <img id="eq-img-thumb" src="${o.escapeHtml((a==null?void 0:a.img)||(a==null?void 0:a.image)||"")}" style="max-width:200px;max-height:100px;border-radius:var(--radius);border:1px solid var(--border)">
                        <button type="button" class="abtn danger" style="padding:2px 6px;font-size:10px;margin-left:4px" onclick="Admin._removeQuestionImage()">删除</button>
                    </div>
                </div>
                <div class="qe-field" id="eq-options-wrap" style="${p?"":"display:none"}">
                    <label>选项 <span class="qe-hint">点击选项设为答案 | 支持选项图片</span></label>
                    <div class="qe-opt-list" id="eq-options-list">${v}</div>
                    <button type="button" class="qe-add-opt" onclick="Admin._addOption()">+ 添加选项</button>
                </div>
                <div class="qe-field" id="eq-judge-wrap" style="${d?"":"display:none"}">
                    <label>答案</label>
                    <div class="qe-judge-btns">
                        <button type="button" class="qe-judge-btn ${m==="true"?"active":""}" onclick="Admin._setJudge(true)" id="eq-judge-true">正确</button>
                        <button type="button" class="qe-judge-btn ${m==="false"?"active":""}" onclick="Admin._setJudge(false)" id="eq-judge-false">错误</button>
                    </div>
                </div>
                <div class="qe-field" id="eq-fill-wrap" style="${r?"":"display:none"}">
                    <label>参考答案</label>
                    ${$}
                </div>
                <div class="qe-field" id="eq-code-wrap" style="${g?"":"display:none"}">
                    <label>代码 <span class="qe-hint">支持代码高亮</span></label>
                    ${f}
                </div>
                <input type="hidden" id="eq-answer" value="${o.escapeHtml(m)}">
                <div class="qe-field">
                    <label>解析 <span class="qe-hint">可选</span></label>
                    <textarea id="eq-explanation" rows="3" placeholder="答案解析..." oninput="Admin._preview()">${o.escapeHtml((a==null?void 0:a.explanation)||"")}</textarea>
                </div>
            </div>
            <div class="qe-panel" id="qe-panel-preview"><div id="eq-preview"></div></div>
        </div>
        <div class="qe-footer">
            <span class="qe-info">${e?"新题目":"ID: "+a.id}</span>
            <div class="qe-actions">
                <button class="ms" onclick="this.closest('.modal-mask').remove()">取消</button>
                <button class="mp" onclick="${e?`Admin.saveNewQuestion('${s}')`:`Admin.saveEditQuestion('${s}',${a.id})`}">${e?"添加":"保存"}</button>
            </div>
        </div>`},i._selectOption=function(s){const a=document.getElementById("eq-type").value,e=document.getElementById("eq-answer");let t=e.value;a==="single"?t=t===s?"":s:t=t.includes(s)?t.replace(s,""):t+s,t=t.split("").sort().join(""),e.value=t,document.querySelectorAll("#eq-options-list .qe-opt-item").forEach(n=>{const c=n.dataset.letter,l=t.includes(c);n.className=`qe-opt-item ${l?"selected":""}`;const p=n.querySelector(".qe-opt-indicator");a==="multiple"||a==="multi"?p.textContent=l?"☑":"☐":p.textContent=l?"●":"○"}),this._preview()},i._addOption=function(){const s=document.getElementById("eq-options-list"),e="ABCDEFGH"[s.children.length]||"?",t=document.getElementById("eq-type").value,n=t==="multiple"||t==="multi",c=document.createElement("div");c.className="qe-opt-item",c.dataset.letter=e,c.onclick=()=>i._selectOption(e),c.innerHTML=`<span class="qe-opt-indicator ${n?"checkbox":"radio"}">${n?"☐":"○"}</span>
            <span class="qe-opt-letter">${e}.</span>
            <input class="qe-opt-input" value="" placeholder="输入选项内容..." oninput="Admin._preview()" onclick="event.stopPropagation()">
            <input type="hidden" class="qe-opt-img" value="">
            <button type="button" class="abtn" style="padding:1px 4px;font-size:10px" onclick="event.stopPropagation();Admin._uploadOptionImage(this)" title="添加选项图片">📷</button>
            <button class="qe-opt-del" onclick="event.stopPropagation();Admin._removeOption(this)" title="删除选项">✕</button>`,s.appendChild(c),this._preview()},i._removeOption=function(s){const a=document.getElementById("eq-options-list");if(a.children.length<=2){o.showToast("至少保留2个选项","error");return}s.closest(".qe-opt-item").remove();const e="ABCDEFGH";Array.from(a.children).forEach((l,p)=>{l.dataset.letter=e[p],l.querySelector(".qe-opt-letter").textContent=e[p]+".",l.onclick=()=>i._selectOption(e[p]),l.querySelector(".qe-opt-del").onclick=d=>{d.stopPropagation(),i._removeOption(l.querySelector(".qe-opt-del"))}});const t=document.getElementById("eq-answer"),n=e[a.children.length-1];let c=t.value.split("").filter(l=>l<=n).join("");t.value=c,this._preview()},i._switchEditorTab=function(s){document.getElementById("qe-tab-edit").className=s==="edit"?"qe-tab active":"qe-tab",document.getElementById("qe-tab-preview").className=s==="preview"?"qe-tab active":"qe-tab",document.getElementById("qe-panel-edit").className=s==="edit"?"qe-panel active":"qe-panel",document.getElementById("qe-panel-preview").className=s==="preview"?"qe-panel active":"qe-panel",s==="preview"&&this._preview()},i._setDiff=function(s){document.getElementById("eq-difficulty").value=s,document.querySelectorAll("#eq-diff-stars .qe-star").forEach((a,e)=>{a.className=e<s?"qe-star on":"qe-star"}),this._preview()},i._onTypeChange=function(){const s=document.getElementById("eq-type").value,a=s==="single"||s==="multiple"||s==="multi",e=s==="judge",t=s==="essay"||s==="fill",n=s==="code";document.getElementById("eq-options-wrap").style.display=a?"":"none",document.getElementById("eq-judge-wrap").style.display=e?"":"none",document.getElementById("eq-fill-wrap").style.display=t?"":"none";const c=document.getElementById("eq-code-wrap");if(n&&(c.style.display=""),document.getElementById("eq-answer").value="",t&&(document.getElementById("eq-fill-answer").value=""),n&&!document.getElementById("eq-code")){const l=document.getElementById("eq-code-wrap");l.innerHTML=`
                <label>代码 <span class="qe-hint">支持代码高亮</span></label>
                <div class="qe-fill-wrap">
                    <div style="display:flex;gap:8px;margin-bottom:8px;align-items:center">
                        <label style="font-size:12px;font-weight:600;">代码语言：</label>
                        <select id="eq-code-lang" style="padding:4px 8px;border:1px solid var(--border);border-radius:6px;font-size:12px;background:var(--bg-card);color:var(--text)">
                            <option value="c">C</option>
                            <option value="cpp">C++</option>
                            <option value="java">Java</option>
                            <option value="python">Python</option>
                            <option value="javascript">JavaScript</option>
                            <option value="go">Go</option>
                            <option value="rust">Rust</option>
                            <option value="sql">SQL</option>
                        </select>
                    </div>
                    <textarea id="eq-code" rows="8" placeholder="输入代码..." style="font-family:monospace;font-size:13px;line-height:1.5" oninput="Admin._preview()"></textarea>
                </div>`}if(a){const l=document.getElementById("eq-options-list"),p=[];l.querySelectorAll(".qe-opt-input").forEach(u=>{u.value.trim()&&p.push(u.value.trim())});const d="ABCDEFGH",r=s==="multiple"||s==="multi";for(l.innerHTML=p.map((u,g)=>`
                <div class="qe-opt-item" data-letter="${d[g]}" onclick="Admin._selectOption('${d[g]}')">
                    <span class="qe-opt-indicator ${r?"checkbox":"radio"}">${r?"☐":"○"}</span>
                    <span class="qe-opt-letter">${d[g]}.</span>
                    <input class="qe-opt-input" value="${o.escapeHtml(u)}" placeholder="输入选项内容..." oninput="Admin._preview()" onclick="event.stopPropagation()">
                    <button class="qe-opt-del" onclick="event.stopPropagation();Admin._removeOption(this)" title="删除选项">✕</button>
                </div>
            `).join("");l.children.length<4;)this._addOption()}this._preview()},i._setJudge=function(s){const a=s===!0||s==="true";document.getElementById("eq-answer").value=a?"true":"false",document.getElementById("eq-judge-true").className=a?"qe-judge-btn active":"qe-judge-btn",document.getElementById("eq-judge-false").className=a?"qe-judge-btn":"qe-judge-btn active",this._preview()},i._collectQuestion=function(){var m,v,$,h,w,f;const s=document.getElementById("eq-type").value,a=s==="single"||s==="multiple"||s==="multi",e=s==="judge",t=s==="essay"||s==="fill",n=s==="code";let c=[];a&&document.querySelectorAll("#eq-options-list .qe-opt-item").forEach(b=>{var I,y;const S=b.querySelector(".qe-opt-input").value.trim(),k=((y=(I=b.querySelector(".qe-opt-img"))==null?void 0:I.value)==null?void 0:y.trim())||"";(S||k)&&c.push({text:S,img:k||""})});let l;e?l=document.getElementById("eq-answer").value==="true":t?l=((v=(m=document.getElementById("eq-fill-answer"))==null?void 0:m.value)==null?void 0:v.trim())||"":l=document.getElementById("eq-answer").value;const p=((h=($=document.getElementById("eq-img"))==null?void 0:$.value)==null?void 0:h.trim())||"",d=t&&((f=(w=document.getElementById("eq-answer-img"))==null?void 0:w.value)==null?void 0:f.trim())||"",r={type:s,category:document.getElementById("eq-category").value.trim(),difficulty:parseInt(document.getElementById("eq-difficulty").value)||1,question:document.getElementById("eq-question").value.trim(),img:p||"",options:c,answer:l,answerImg:d||"",explanation:document.getElementById("eq-explanation").value.trim()},u=document.getElementById("eq-code"),g=document.getElementById("eq-code-lang");if(u){const b=u.value||"";b?(r.code=b,r.codeLanguage=(g==null?void 0:g.value)||"c",n&&(r.answer=b)):n&&(r.code="",r.codeLanguage=(g==null?void 0:g.value)||"c")}return r.question?r:(o.showToast("题目内容不能为空","error"),null)},i._uploadQuestionImage=function(){H.showDialog(s=>{document.getElementById("eq-img").value=s;const a=document.getElementById("eq-img-preview"),e=document.getElementById("eq-img-thumb");e.src=s,a.style.display="block",this._preview()})},i._removeQuestionImage=function(){document.getElementById("eq-img").value="",document.getElementById("eq-img-preview").style.display="none",this._preview()},i._uploadAnswerImage=function(){H.showDialog(s=>{document.getElementById("eq-answer-img").value=s;const a=document.getElementById("eq-answer-img-preview"),e=document.getElementById("eq-answer-img-thumb");e.src=s,a.style.display="block",this._preview()})},i._removeAnswerImage=function(){document.getElementById("eq-answer-img").value="",document.getElementById("eq-answer-img-preview").style.display="none",this._preview()},i._uploadOptionImage=function(s){H.showDialog(a=>{const e=s.closest(".qe-opt-item"),t=e.querySelector(".qe-opt-img");t.value=a;let n=e.querySelector("img");n||(n=document.createElement("img"),n.style.cssText="max-width:60px;max-height:40px;border-radius:4px;margin-left:4px;vertical-align:middle;border:1px solid var(--border)",s.parentNode.insertBefore(n,s)),n.src=a;let c=e.querySelector(".opt-img-delete");c||(c=document.createElement("button"),c.type="button",c.className="abtn danger opt-img-delete",c.style.cssText="padding:1px 4px;font-size:10px",c.textContent="🗑️",c.title="删除选项图片",c.onclick=l=>{l.stopPropagation(),i._removeOptionImage(c)},s.parentNode.insertBefore(c,s.nextSibling)),this._preview()})},i._removeOptionImage=function(s){const a=s.closest(".qe-opt-item"),e=a.querySelector(".qe-opt-img");e.value="";const t=a.querySelector("img");t&&t.remove(),s.remove(),this._preview()},i.saveNewQuestion=async function(s){var n;const a=this._collectQuestion();if(!a)return;const e=document.querySelector(".qe-footer .mp");e&&(e.disabled=!0,e.textContent="保存中...");const t=await this.post(`/api/admin/bank/${s}/question`,{question:a});t!=null&&t.ok?(o.showToast("已添加","success"),(n=document.querySelector(".modal-mask"))==null||n.remove(),this.viewBank(s)):(o.showToast((t==null?void 0:t.error)||"添加失败","error"),e&&(e.disabled=!1,e.textContent="添加"))},i.saveEditQuestion=async function(s,a){var c;const e=this._collectQuestion();if(!e)return;const t=document.querySelector(".qe-footer .mp");t&&(t.disabled=!0,t.textContent="保存中...");const n=await this.put(`/api/admin/bank/${s}/question/${a}`,{question:e});n!=null&&n.ok?(o.showToast("已保存","success"),(c=document.querySelector(".modal-mask"))==null||c.remove(),this._updateQuestionInList(s,a,e)):(o.showToast((n==null?void 0:n.error)||"保存失败","error"),t&&(t.disabled=!1,t.textContent="保存"))},i._updateQuestionInList=function(s,a,e){const t=document.querySelector(`.question-item[data-qid="${a}"]`);if(!t)return;const n=t.querySelector(".question-preview");if(n){const p=e.question||"";n.textContent=p.length>60?p.substring(0,60)+"...":p}const c=t.querySelector(".question-type");if(c){const p={single:"单选",multiple:"多选",multi:"多选",judge:"判断",fill:"填空",essay:"简答",code:"编程"};c.textContent=p[e.type]||e.type}const l=t.querySelector(".question-category");l&&e.category&&(l.textContent=e.category),t.style.background="var(--success-light)",setTimeout(()=>{t.style.background=""},1500)},i.deleteQuestion=async function(s,a){if(!await this.confirmDanger({title:"删除题目",targetLabel:`题目 #${a}`,message:"删除后该题目会从题库中移除，此操作不可恢复。",confirmText:"确认删除"}))return;const t=await this.post(`/api/admin/bank/${s}/question/${a}`,{});if(t!=null&&t.ok){o.showToast("已删除","success");const n=document.querySelector(`.question-item[data-qid="${a}"]`);n?(n.style.opacity="0",n.style.transform="translateX(20px)",setTimeout(()=>n.remove(),300)):this.viewBank(s)}},i._preview=function(){var k,I,y;const s=document.getElementById("eq-preview");if(!s)return;const a=document.getElementById("eq-type").value,e=document.getElementById("eq-question").value,t=document.getElementById("eq-answer").value,n=document.getElementById("eq-explanation").value,c=parseInt(document.getElementById("eq-difficulty").value)||1,l=document.getElementById("eq-category").value,p={single:"单选",multiple:"多选",multi:"多选",judge:"判断",fill:"填空",essay:"简答",code:"编程"}[a]||a,d=a==="single"||a==="multiple"||a==="multi",r=a==="judge",u=a==="essay"||a==="fill",g=a==="code";let m=[];d&&document.querySelectorAll("#eq-options-list .qe-opt-input").forEach(x=>{const T=x.value.trim();T&&m.push(T)});let v="";u&&(v=((k=document.getElementById("eq-fill-answer"))==null?void 0:k.value)||"");let $="",h="c";const w=document.getElementById("eq-code"),f=document.getElementById("eq-code-lang");w&&($=w.value||"",h=(f==null?void 0:f.value)||"c");let b='<div class="qe-preview-card">';b+='<div class="qe-preview-meta">',l&&(b+=`<span class="qe-preview-tag">${o.escapeHtml(l)}</span>`),b+=`<span class="qe-preview-tag type">${p}</span>`;const S=Math.max(1,Math.min(3,c));if(b+=`<span class="qe-preview-tag">${"★".repeat(S)}${"☆".repeat(3-S)}</span>`,b+="</div>",b+=`<div class="qe-preview-question">${o.escapeHtml(e)||'<span style="color:var(--text-tertiary)">题目内容...</span>'}</div>`,r)b+='<div class="qe-preview-opts">',b+=`<div class="qe-preview-opt ${t==="true"?"selected":""}">正确</div>`,b+=`<div class="qe-preview-opt ${t==="false"?"selected":""}">错误</div>`,b+="</div>";else if(d)b+='<div class="qe-preview-opts">',m.forEach((x,T)=>{const E=String.fromCharCode(65+T),q=(t||"").includes(E);b+=`<div class="qe-preview-opt ${q?"selected":""}"><b>${E}.</b> ${o.escapeHtml(x)}</div>`}),b+="</div>";else if(u&&v){b+=`<div class="qe-preview-answer"><b>参考答案：</b>${o.escapeHtml(v)}</div>`;const x=((y=(I=document.getElementById("eq-answer-img"))==null?void 0:I.value)==null?void 0:y.trim())||"";x&&(b+=`<div style="margin-top:8px"><img src="${o.escapeHtml(x)}" style="max-width:300px;max-height:200px;border-radius:var(--radius);border:1px solid var(--border)"></div>`)}$&&(b+=`<div class="qe-preview-answer" style="margin-top:8px">
                <div style="font-size:11px;color:var(--text-tertiary);margin-bottom:4px">代码 (${o.escapeHtml(h)})</div>
                <pre style="background:var(--bg-hover);padding:12px;border-radius:var(--radius);font-family:monospace;font-size:13px;line-height:1.5;overflow-x:auto;white-space:pre-wrap;margin:0">${o.escapeHtml($)}</pre>
            </div>`),t&&!r&&!u&&!g&&(b+=`<div class="qe-preview-answer">答案: <b>${o.escapeHtml(String(t))}</b></div>`),n&&(b+=`<div class="qe-preview-explain"><div class="qe-preview-explain-label">解析</div><div class="qe-preview-explain-text">${o.escapeHtml(n)}</div></div>`),b+="</div>",s.innerHTML=b}}function j(i){i.renderAnnounce=async function(){document.getElementById("sec-announce").innerHTML=`
            ${this.pageHeader({title:"公告管理",description:"发布、编辑和下线首页滚动公告。建议公告内容短、明确，并在发布前核对影响范围。",crumbs:["管理后台","公告管理"],actions:'<button class="abtn" onclick="Admin.loadAnnouncements()">刷新历史</button>'})}
            <div class="card">
                <div class="card-header"><h3>发布公告</h3><span class="count">前台滚动展示</span></div>
                <div class="card-body" style="padding:16px">
                    <div class="inline-notice" style="margin-bottom:12px"><span class="notice-dot"></span><div>公告发布后会影响所有访问用户。请避免过长文本，重要通知建议写明时间、范围和操作指引。</div></div>
                    <div class="announce-input"><textarea id="announce-content" placeholder="输入公告内容，例如：6月8日 22:00-22:30 将进行题库维护，期间部分题库可能短暂不可用。"></textarea></div>
                    <div class="modal-actions" style="justify-content:flex-start">
                        <button class="mp" onclick="Admin.publishAnnounce()">发布公告</button>
                    </div>
                </div>
            </div>
            <div class="card" id="announce-list-card">
                <div class="card-header" style="display:flex;justify-content:space-between;align-items:center">
                    <h3>历史公告</h3>
                    <select id="announce-sort" class="admin-select" style="width:auto" onchange="Admin.loadAnnouncements()">
                        <option value="newest">最新优先</option><option value="oldest">最早优先</option>
                    </select>
                </div>
                <div class="loading">加载中...</div>
            </div>`,await this.loadAnnouncements()},i.loadAnnouncements=async function(){var s,a;try{const e=await this.get("/api/admin/announcements"),t=document.getElementById("announce-list-card"),n=((s=document.getElementById("announce-sort"))==null?void 0:s.value)||"newest",c=`<div class="card-header" style="display:flex;justify-content:space-between;align-items:center"><h3>历史公告</h3><select id="announce-sort" class="admin-select" style="width:auto" onchange="Admin.loadAnnouncements()"><option value="newest" ${n==="newest"?"selected":""}>最新优先</option><option value="oldest" ${n==="oldest"?"selected":""}>最早优先</option></select></div>`;if(!e||!e.ok||!((a=e.announcements)!=null&&a.length)){t.innerHTML=c+this.emptyState({title:"暂无公告",desc:"发布公告后会在这里显示历史记录。"});return}const l=[...e.announcements];n==="oldest"&&l.reverse(),t.innerHTML=c+l.map(p=>`
                <div class="announcement-item">
                    <div style="flex:1;min-width:0">
                        <div class="announcement-content">${o.escapeHtml(p.content)}</div>
                        <div class="announcement-meta">${i.fmtTime(p.created_at)||""} · ID: ${p.id}</div>
                    </div>
                    <div class="toolbar-group" style="flex-shrink:0">
                        <button class="abtn" onclick="Admin.editAnnounce(${p.id},'${o.jsSafe(p.content)}')">编辑</button>
                        <button class="abtn danger" onclick="Admin.deleteAnnounce(${p.id})">删除</button>
                    </div>
                </div>
            `).join("")}catch(e){console.error(e);const t=document.getElementById("announce-list-card");t&&(t.innerHTML=this.emptyState({title:"公告加载失败",desc:e.message}))}},i.publishAnnounce=async function(){const s=document.getElementById("announce-content").value.trim();if(!s){o.showToast("请输入内容","error");return}if(!await this.confirmDanger({title:"发布公告",message:"公告发布后会立即展示给所有访问用户。请确认内容无误。",targetLabel:s.length>60?s.slice(0,60)+"...":s,confirmText:"确认发布",danger:!1}))return;const e=await this.post("/api/admin/announce",{content:s});e!=null&&e.ok?(o.showToast("已发布","success"),document.getElementById("announce-content").value="",await this.loadAnnouncements()):o.showToast((e==null?void 0:e.error)||"发布失败","error")},i.deleteAnnounce=async function(s){if(!await this.confirmDanger({title:"删除公告",targetLabel:`公告 #${s}`,message:"删除后该公告将不再出现在历史列表中。",confirmText:"确认删除"}))return;const e=await this.post("/api/admin/delete-announcement",{id:s});e!=null&&e.ok?(o.showToast("已删除","success"),await this.loadAnnouncements()):o.showToast((e==null?void 0:e.error)||"删除失败","error")},i.editAnnounce=function(s,a){document.getElementById("modal-root").innerHTML=`
            <div class="modal-mask" onclick="Admin.onMaskClick(event)">
                <div class="modal-box">
                    <h3>编辑公告 #${s}</h3>
                    <label>公告内容</label>
                    <textarea id="edit-announce-content" rows="5">${o.escapeHtml(a)}</textarea>
                    <div class="modal-actions"><button class="ms" onclick="this.closest('.modal-mask').remove()">取消</button><button class="mp" onclick="Admin.saveAnnounce(${s})">保存</button></div>
                </div>
            </div>`},i.saveAnnounce=async function(s){var t;const a=document.getElementById("edit-announce-content").value.trim();if(!a){o.showToast("内容不能为空","error");return}const e=await this.post("/api/admin/edit-announcement",{id:s,content:a});e!=null&&e.ok?(o.showToast("已更新","success"),(t=document.querySelector(".modal-mask"))==null||t.remove(),await this.loadAnnouncements()):o.showToast((e==null?void 0:e.error)||"保存失败","error")}}const M={openai:"OpenAI 兼容",gemini:"Gemini API"};function P(i){i.renderAI=async function(){const s=document.getElementById("sec-ai");s.innerHTML='<div class="loading">加载中...</div>';try{const a=await this.get("/api/admin/ai-config");if(!(a!=null&&a.ok)){s.innerHTML=this.emptyState({title:"AI 配置加载失败",desc:(a==null?void 0:a.error)||"无法读取 AI 解读配置。"});return}const e=a.config||{};s.innerHTML=`
                ${this.pageHeader({title:"AI 解读配置",description:"控制前台 AI 按钮显示、网页内流式解读、全站默认模型和用户自定义权限。",crumbs:["管理后台","AI 解读"],actions:'<button class="abtn" onclick="Admin.renderAI()">刷新</button>'})}
                <div class="system-notice"><span class="notice-dot"></span><div>后台 API 密钥不会返回到前端。API 密钥留空表示保留原密钥；勾选清除密钥才会删除。</div></div>
                <div class="card">
                    <div class="card-header">
                        <h3>功能开关</h3>
                        <span class="count">${e.enabled?"当前启用":"当前关闭"}</span>
                    </div>
                    <div class="card-body" style="padding:16px">
                        <div class="d-grid">
                            <label class="d-item" style="cursor:pointer">
                                <div class="dl">启用 AI 解读</div>
                                <div class="dv"><input type="checkbox" id="ai-enabled" ${e.enabled?"checked":""}></div>
                            </label>
                            <label class="d-item" style="cursor:pointer">
                                <div class="dl">允许用户自定义 API</div>
                                <div class="dv"><input type="checkbox" id="ai-allow-user" ${e.allowUserOverride?"checked":""}></div>
                            </label>
                            <div class="d-item"><div class="dl">后台密钥</div><div class="dv">${e.hasGlobalKey?"已配置":"未配置"}</div></div>
                            <div class="d-item"><div class="dl">最后更新</div><div class="dv">${this.fmtTime(e.updatedAt)||"-"}</div></div>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header"><h3>默认解读引擎</h3><span class="count">全站默认</span></div>
                    <div class="card-body" style="padding:16px">
                        <div class="ai-admin-grid">
                            <label>
                                <span>前台模式</span>
                                <select class="admin-select" id="ai-mode">
                                    <option value="search" ${e.mode!=="inpage"?"selected":""}>搜索跳转</option>
                                    <option value="inpage" ${e.mode==="inpage"?"selected":""}>网页内流式解读</option>
                                </select>
                            </label>
                            <label>
                                <span>协议</span>
                                <select class="admin-select" id="ai-provider">
                                    ${Object.entries(M).map(([t,n])=>`<option value="${t}" ${e.provider===t?"selected":""}>${n}</option>`).join("")}
                                </select>
                            </label>
                            <label>
                                <span>Base URL</span>
                                <input class="admin-input" id="ai-base-url" value="${o.escapeHtml(e.baseUrl||"")}" placeholder="OpenAI: https://api.openai.com/v1 / Gemini: https://generativelanguage.googleapis.com/v1beta">
                            </label>
                            <label>
                                <span>模型</span>
                                <input class="admin-input" id="ai-model" value="${o.escapeHtml(e.model||"")}" placeholder="gpt-4o-mini / deepseek-chat / gemini-1.5-flash">
                            </label>
                            <label>
                                <span>API 密钥</span>
                                <input class="admin-input" id="ai-api-key" type="password" value="" placeholder="留空保留当前密钥">
                            </label>
                            <label class="ai-admin-clear-key">
                                <span>清除当前密钥</span>
                                <input type="checkbox" id="ai-clear-key">
                            </label>
                        </div>
                        <label class="ai-admin-prompt-label">系统提示词</label>
                        <textarea class="admin-input ai-admin-prompt" id="ai-system-prompt" rows="6" placeholder="请输入 AI 解读风格和要求">${o.escapeHtml(e.systemPrompt||"")}</textarea>
                        <div class="modal-actions" style="margin-top:16px">
                            <button class="ms" onclick="Admin.renderAI()">取消</button>
                            <button class="mp" onclick="Admin.saveAIConfig()">保存配置</button>
                        </div>
                    </div>
                </div>
            `}catch(a){s.innerHTML=this.emptyState({title:"AI 配置加载失败",desc:a.message})}},i.saveAIConfig=async function(){var e,t,n,c,l,p,d,r,u;const s={enabled:((e=document.getElementById("ai-enabled"))==null?void 0:e.checked)||!1,allowUserOverride:((t=document.getElementById("ai-allow-user"))==null?void 0:t.checked)||!1,mode:((n=document.getElementById("ai-mode"))==null?void 0:n.value)||"search",provider:((c=document.getElementById("ai-provider"))==null?void 0:c.value)||"openai",baseUrl:((l=document.getElementById("ai-base-url"))==null?void 0:l.value.trim())||"",model:((p=document.getElementById("ai-model"))==null?void 0:p.value.trim())||"",apiKey:((d=document.getElementById("ai-api-key"))==null?void 0:d.value.trim())||"",clearApiKey:((r=document.getElementById("ai-clear-key"))==null?void 0:r.checked)||!1,systemPrompt:((u=document.getElementById("ai-system-prompt"))==null?void 0:u.value.trim())||""},a=await this.put("/api/admin/ai-config",{config:s});a!=null&&a.ok?(o.showToast("AI 解读配置已保存","success"),await this.renderAI()):o.showToast((a==null?void 0:a.error)||"保存失败","error")}}function U(i){i.renderLogs=async function(){const s=document.getElementById("sec-logs");if(s){s.innerHTML='<div class="loading">加载中...</div>';try{const a=this.logsPage||1,e=this.logsPageSize||20,t=this.logsActionFilter||"",n=this.logsTargetTypeFilter||"",c=this.logsOkFilter||"",l=new URLSearchParams({page:String(a),pageSize:String(e)});t&&l.set("action",t),n&&l.set("targetType",n),c&&l.set("ok",c);const p=await this.get(`/api/admin/operation-logs?${l.toString()}`);if(!(p!=null&&p.ok)){s.innerHTML=this.emptyState({title:"操作日志加载失败",desc:(p==null?void 0:p.error)||"请检查 Worker 是否已部署 operation-logs 接口。"});return}const d=p.logs||[],r=p.total||0,u=p.actions||[],g=d.length?d.map(m=>`
                    <tr>
                        <td style="font-size:12px;color:var(--admin-text-tertiary)">${i.fmtTime(m.created_at)}</td>
                        <td><strong>${o.escapeHtml(m.action)}</strong></td>
                        <td>${o.escapeHtml(m.target_type||"-")}</td>
                        <td><code>${o.escapeHtml(m.target_id||"-")}</code></td>
                        <td>${m.ok?'<span class="status-pill enabled">成功</span>':'<span class="status-pill disabled">失败</span>'}</td>
                        <td style="font-size:12px;max-width:280px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${o.escapeHtml(m.detail||"")}">${o.escapeHtml((m.detail||"").slice(0,80))}</td>
                        <td style="font-size:12px">${o.escapeHtml(m.operator||"-")}</td>
                    </tr>
                `).join(""):`<tr><td colspan="7">${this.emptyState({title:"暂无操作日志"})}</td></tr>`;s.innerHTML=`
                ${this.pageHeader({title:"操作日志",description:"查看管理员在后台执行的所有操作记录，用于审计和问题排查。",crumbs:["管理后台","操作日志"],actions:'<button class="abtn" onclick="Admin.renderLogs()">刷新</button>'})}
                <div class="toolbar">
                    <div class="toolbar-group" style="flex:1">
                        <select class="admin-select" id="logs-action-filter" onchange="Admin.setLogsFilters()">
                            <option value="">全部操作</option>
                            ${u.map(m=>`<option value="${o.escapeHtml(m)}" ${t===m?"selected":""}>${o.escapeHtml(m)}</option>`).join("")}
                        </select>
                        <select class="admin-select" id="logs-target-filter" onchange="Admin.setLogsFilters()">
                            <option value="">全部对象</option>
                            <option value="user" ${n==="user"?"selected":""}>用户</option>
                            <option value="bank" ${n==="bank"?"selected":""}>题库</option>
                            <option value="question" ${n==="question"?"selected":""}>题目</option>
                            <option value="announcement" ${n==="announcement"?"selected":""}>公告</option>
                            <option value="system" ${n==="system"?"selected":""}>系统</option>
                        </select>
                        <select class="admin-select" id="logs-ok-filter" onchange="Admin.setLogsFilters()">
                            <option value="">全部状态</option>
                            <option value="1" ${c==="1"?"selected":""}>成功</option>
                            <option value="0" ${c==="0"?"selected":""}>失败</option>
                        </select>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        <div style="display:flex;align-items:center;gap:8px">
                            <h3>操作记录</h3>
                            <span class="status-pill info">${r} 条记录</span>
                        </div>
                        <span class="count">按时间倒序</span>
                    </div>
                    <div class="table-wrap">
                        <table>
                            <thead><tr><th>时间</th><th>操作</th><th>对象类型</th><th>对象ID</th><th>结果</th><th>详情</th><th>操作人</th></tr></thead>
                            <tbody>${g}</tbody>
                        </table>
                    </div>
                </div>
                ${this.pager({page:a,pageSize:e,total:r,onPage:"Admin.setLogsPage",onPageSize:"Admin.setLogsPageSize"})}
            `}catch(a){s.innerHTML=this.emptyState({title:"操作日志加载失败",desc:a.message})}}},i.setLogsPage=function(s){this.logsPage=s,this.renderLogs()},i.setLogsPageSize=function(s){this.logsPageSize=s,this.logsPage=1,this.renderLogs()},i.setLogsFilters=function(){var s,a,e;this.logsActionFilter=((s=document.getElementById("logs-action-filter"))==null?void 0:s.value)||"",this.logsTargetTypeFilter=((a=document.getElementById("logs-target-filter"))==null?void 0:a.value)||"",this.logsOkFilter=((e=document.getElementById("logs-ok-filter"))==null?void 0:e.value)||"",this.logsPage=1,this.renderLogs()}}function z(i){const s={"1h":{label:"近 1 小时",ms:36e5},"6h":{label:"近 6 小时",ms:216e5},"24h":{label:"近 24 小时",ms:864e5},"3d":{label:"近 3 天",ms:2592e5},"7d":{label:"近 7 天",ms:6048e5},all:{label:"全部",ms:0}},a=[{value:"",label:"全部级别"},{value:"error",label:"❌ 错误"},{value:"warn",label:"⚠️ 警告"},{value:"info",label:"ℹ️ 信息"},{value:"debug",label:"🔍 调试"},{value:"log",label:"📋 日志"}],e=[{value:"",label:"全部类型"},{value:"console",label:"📋 控制台"},{value:"uncaught",label:"💥 JS 运行时错误"},{value:"unhandledrejection",label:"⚡ 未处理 Promise"},{value:"resource",label:"📦 资源加载失败"},{value:"user_report",label:"📝 用户反馈"}],t={error:"danger",warn:"warning",info:"info",debug:"",log:""},n={error:"错误",warn:"警告",info:"信息",debug:"调试",log:"日志"},c={uncaught:"💥",unhandledrejection:"⚡",resource:"📦",user_report:"📝",console:"📋"};i.renderClientLogs=async function(){const d=document.getElementById("sec-client-logs");if(d){d.innerHTML='<div class="loading">加载中...</div>';try{const r=this._clf||{},u=r.page||1,g=r.pageSize||50,m=new URLSearchParams({limit:String(g),offset:String((u-1)*g)});r.level&&m.set("level",r.level),r.type&&m.set("type",r.type),r.keyword&&m.set("keyword",r.keyword),r.userName&&m.set("userName",r.userName),r.deviceId&&m.set("filterDeviceId",r.deviceId),r.timeStart&&m.set("timeStart",r.timeStart),r.timeEnd&&m.set("timeEnd",r.timeEnd);const v=await this.get(`/api/admin/logs?${m.toString()}`);if(!(v!=null&&v.ok)){d.innerHTML=this.emptyState({title:"客户端日志加载失败",desc:(v==null?void 0:v.error)||"接口异常"});return}const $=v.logs||[],h=v.total||0,w=v.errorSummary||[],f=v.activeDevices||[],b=$.length?$.map(y=>{const x=y.level||"log",T=(y.message||"").slice(0,150),E=y.stack?`<details><summary style="cursor:pointer;font-size:11px;color:var(--admin-text-tertiary)">堆栈</summary><pre style="font-size:11px;max-height:200px;overflow:auto;white-space:pre-wrap;word-break:break-all">${o.escapeHtml(y.stack)}</pre></details>`:"",q=y.user_name?`<strong>${o.escapeHtml(y.user_name)}</strong>${y.sync_code?`<br><code style="font-size:10px;color:var(--admin-text-tertiary)">${o.escapeHtml(y.sync_code)}</code>`:""}`:'<span style="color:var(--admin-text-tertiary)">未绑定</span>';return`<tr>
                        <td style="font-size:12px;color:var(--admin-text-tertiary);white-space:nowrap">${i.fmtTime(y.created_at)}</td>
                        <td><span class="status-pill ${t[x]||""}">${n[x]||x}</span></td>
                        <td style="font-size:12px;white-space:nowrap">${c[y.type]||"📋"} ${o.escapeHtml(y.type||"console")}</td>
                        <td style="font-size:12px">${q}</td>
                        <td style="max-width:350px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:13px" title="${o.escapeHtml(y.message||"")}">${o.escapeHtml(T)}</td>
                        <td>${E}</td>
                        <td style="font-size:11px;max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${o.escapeHtml(y.page_url||"")}">${o.escapeHtml((y.page_url||"").replace(/^https?:\/\/[^/]+/,""))}</td>
                    </tr>`}).join(""):'<tr><td colspan="7" style="text-align:center;padding:32px;color:var(--admin-text-tertiary)">暂无匹配的日志</td></tr>',S=w.length?`
                <div class="card" style="margin-bottom:16px">
                    <div class="card-header"><h3>🔥 近 7 天高频错误 Top ${w.length}</h3></div>
                    <div class="table-wrap"><table>
                        <thead><tr><th>错误消息</th><th>出现次数</th></tr></thead>
                        <tbody>${w.map(y=>`<tr>
                            <td style="max-width:500px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:13px" title="${o.escapeHtml(y.message||"")}">${o.escapeHtml((y.message||"").slice(0,120))}</td>
                            <td><span class="status-pill danger">${y.cnt}</span></td>
                        </tr>`).join("")}</tbody>
                    </table></div>
                </div>`:"",k=f.length?`
                <div class="card" style="margin-bottom:16px">
                    <div class="card-header"><h3>📱 最近活跃设备</h3></div>
                    <div class="table-wrap"><table>
                        <thead><tr><th>用户</th><th>同步码</th><th>日志数</th><th>最后活跃</th></tr></thead>
                        <tbody>${f.map(y=>`<tr style="cursor:pointer" onclick="Admin.filterClientLogsByDevice(decodeURIComponent('${encodeURIComponent(y.device_id)}'))">
                            <td>${y.user_name?`<strong>${o.escapeHtml(y.user_name)}</strong>`:'<span style="color:var(--admin-text-tertiary)">未绑定</span>'}</td>
                            <td><code style="font-size:11px">${y.sync_code?o.escapeHtml(y.sync_code):"-"}</code></td>
                            <td>${y.log_count}</td>
                            <td style="font-size:12px">${i.fmtTime(y.last_active)}</td>
                        </tr>`).join("")}</tbody>
                    </table></div>
                </div>`:"",I=`
                <div class="card" style="margin-bottom:16px;padding:16px">
                    <div style="display:flex;flex-wrap:wrap;gap:10px;align-items:flex-end">
                        <!-- 时间快捷 -->
                        <div>
                            <label style="font-size:12px;color:var(--admin-text-tertiary);display:block;margin-bottom:4px">时间范围</label>
                            <div style="display:flex;gap:4px;flex-wrap:wrap">
                                ${Object.entries(s).map(([y,x])=>`<button class="abtn ${(r.timePreset||"24h")===y?"":"secondary"}" style="font-size:12px;padding:4px 10px" onclick="Admin.clfSetTimePreset('${y}')">${x.label}</button>`).join("")}
                            </div>
                        </div>
                        <!-- 时间自定义 -->
                        <div>
                            <label style="font-size:12px;color:var(--admin-text-tertiary);display:block;margin-bottom:4px">自定义时间</label>
                            <div style="display:flex;gap:4px;align-items:center">
                                <input type="datetime-local" class="admin-select" id="clf-time-start" value="${r.timeStart?p(new Date(r.timeStart+"Z").getTime()):""}" style="font-size:12px" onchange="Admin.clfApplyCustomTime()">
                                <span style="color:var(--admin-text-tertiary)">~</span>
                                <input type="datetime-local" class="admin-select" id="clf-time-end" value="${r.timeEnd?p(new Date(r.timeEnd+"Z").getTime()):""}" style="font-size:12px" onchange="Admin.clfApplyCustomTime()">
                            </div>
                        </div>
                        <!-- 级别 -->
                        <div>
                            <label style="font-size:12px;color:var(--admin-text-tertiary);display:block;margin-bottom:4px">级别</label>
                            <select class="admin-select" id="clf-level" onchange="Admin.setClientLogsFilters()">
                                ${a.map(y=>`<option value="${y.value}" ${r.level===y.value?"selected":""}>${y.label}</option>`).join("")}
                            </select>
                        </div>
                        <!-- 类型 -->
                        <div>
                            <label style="font-size:12px;color:var(--admin-text-tertiary);display:block;margin-bottom:4px">类型</label>
                            <select class="admin-select" id="clf-type" onchange="Admin.setClientLogsFilters()">
                                ${e.map(y=>`<option value="${y.value}" ${r.type===y.value?"selected":""}>${y.label}</option>`).join("")}
                            </select>
                        </div>
                        <!-- 用户名 -->
                        <div>
                            <label style="font-size:12px;color:var(--admin-text-tertiary);display:block;margin-bottom:4px">用户名</label>
                            <input class="admin-select" id="clf-username" placeholder="搜索用户名..." value="${o.escapeHtml(r.userName||"")}" style="min-width:120px;font-size:12px" onchange="Admin.setClientLogsFilters()">
                        </div>
                        <!-- 关键词 -->
                        <div>
                            <label style="font-size:12px;color:var(--admin-text-tertiary);display:block;margin-bottom:4px">关键词</label>
                            <input class="admin-select" id="clf-keyword" placeholder="搜索日志内容..." value="${o.escapeHtml(r.keyword||"")}" style="min-width:160px;font-size:12px" onchange="Admin.setClientLogsFilters()">
                        </div>
                        <!-- 操作 -->
                        <div style="display:flex;gap:6px;align-items:flex-end">
                            <button class="abtn secondary" style="font-size:12px;padding:6px 12px" onclick="Admin.clfClearFilters()">清空筛选</button>
                            <button class="abtn" style="font-size:12px;padding:6px 12px;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff" onclick="Admin.clfCopyForAI()">📋 复制给 AI</button>
                        </div>
                    </div>
                    <div style="margin-top:8px;font-size:12px;color:var(--admin-text-tertiary)">
                        ${this._clfSummaryStr(r,h)}
                    </div>
                </div>`;d.innerHTML=`
                ${this.pageHeader({title:"客户端日志",description:"查看前端自动上报的 warn/error 日志，支持筛选后一键复制给 AI 分析。",crumbs:["管理后台","客户端日志"],actions:'<button class="abtn" onclick="Admin.renderClientLogs()">刷新</button>'})}
                ${I}
                ${S}
                ${k}
                <div class="card">
                    <div class="card-header"><h3>日志列表</h3><span class="count">${h} 条 · 按时间倒序</span></div>
                    <div class="table-wrap">
                        <table>
                            <thead><tr><th>时间</th><th>级别</th><th>类型</th><th>用户</th><th>消息</th><th>堆栈</th><th>页面</th></tr></thead>
                            <tbody>${b}</tbody>
                        </table>
                    </div>
                </div>
                ${this.pager({page:u,pageSize:g,total:h,onPage:"Admin.setClientLogsPage",onPageSize:"Admin.setClientLogsPageSize"})}
            `}catch(r){d.innerHTML=this.emptyState({title:"客户端日志加载失败",desc:r.message})}}},i._clfSummaryStr=function(d,r){var g,m;const u=[`共 ${r} 条`];return d.timePreset&&d.timePreset!=="all"&&u.push(((g=s[d.timePreset])==null?void 0:g.label)||""),d.level&&u.push(`级别:${n[d.level]||d.level}`),d.type&&u.push(`类型:${((m=e.find(v=>v.value===d.type))==null?void 0:m.label)||d.type}`),d.userName&&u.push(`用户:${d.userName}`),d.keyword&&u.push(`关键词:${d.keyword}`),d.deviceId&&u.push(`设备:${d.deviceId.slice(0,8)}…`),u.join(" · ")};function l(d){if(!d)return"";const r=new Date(d);return isNaN(r.getTime())?"":r.toISOString().slice(0,19)}function p(d){const r=new Date(d),u=g=>String(g).padStart(2,"0");return`${r.getFullYear()}-${u(r.getMonth()+1)}-${u(r.getDate())}T${u(r.getHours())}:${u(r.getMinutes())}`}i.clfSetTimePreset=function(d){var u;const r=this._clf||(this._clf={});if(r.timePreset=d,d==="all")r.timeStart="",r.timeEnd="";else{const g=((u=s[d])==null?void 0:u.ms)||0;r.timeStart=g?new Date(Date.now()-g).toISOString().slice(0,19):"",r.timeEnd=""}r.page=1,this.renderClientLogs()},i.clfApplyCustomTime=function(){var g,m;const d=this._clf||(this._clf={}),r=((g=document.getElementById("clf-time-start"))==null?void 0:g.value)||"",u=((m=document.getElementById("clf-time-end"))==null?void 0:m.value)||"";d.timeStart=l(r),d.timeEnd=l(u),d.timePreset="",d.page=1,this.renderClientLogs()},i.setClientLogsFilters=function(){var r,u,g,m;const d=this._clf||(this._clf={});d.level=((r=document.getElementById("clf-level"))==null?void 0:r.value)||"",d.type=((u=document.getElementById("clf-type"))==null?void 0:u.value)||"",d.keyword=((g=document.getElementById("clf-keyword"))==null?void 0:g.value)||"",d.userName=((m=document.getElementById("clf-username"))==null?void 0:m.value)||"",d.page=1,this.renderClientLogs()},i.clfClearFilters=function(){this._clf={page:1,pageSize:50,timePreset:"24h"},this.renderClientLogs()},i.filterClientLogsByDevice=function(d){const r=this._clf||(this._clf={});r.deviceId=d,r.page=1,this.renderClientLogs()},i.setClientLogsPage=function(d){(this._clf||(this._clf={})).page=d,this.renderClientLogs()},i.setClientLogsPageSize=function(d){const r=this._clf||(this._clf={});r.pageSize=d,r.page=1,this.renderClientLogs()},i.clfCopyForAI=async function(){const d=this._clf||{},r=new URLSearchParams({limit:"200",offset:"0"});d.level&&r.set("level",d.level),d.type&&r.set("type",d.type),d.keyword&&r.set("keyword",d.keyword),d.userName&&r.set("userName",d.userName),d.deviceId&&r.set("filterDeviceId",d.deviceId),d.timeStart&&r.set("timeStart",d.timeStart),d.timeEnd&&r.set("timeEnd",d.timeEnd);try{const u=await this.get(`/api/admin/logs?${r.toString()}`);if(!(u!=null&&u.ok)){o.showToast("获取日志失败","error");return}const g=u.logs||[];if(!g.length){o.showToast("没有可复制的日志","warn");return}let m=`# 客户端日志导出
`;m+=`导出时间: ${new Date().toLocaleString("zh-CN")}
`,m+=`筛选条件: ${this._clfSummaryStr(d,u.total)}
`,m+=`日志条数: ${g.length}

`,m+=`---

`;for(const v of g){const $=i.fmtTime(v.created_at),h=(v.level||"log").toUpperCase(),w=v.type||"console",f=v.user_name?`${v.user_name}(${v.sync_code||"?"})`:"未绑定设备",b=(v.page_url||"").replace(/^https?:\/\/[^/]+/,"")||"-";m+=`[${$}] [${h}] [${w}] 用户:${f} 页面:${b}
`,m+=`消息: ${v.message||"-"}
`,v.stack&&(m+=`堆栈:
${v.stack}
`),m+=`
`}m+=`---
`,m+="请分析以上日志，找出主要错误模式和可能的原因，并给出修复建议。",await navigator.clipboard.writeText(m),o.showToast(`✅ 已复制 ${g.length} 条日志到剪贴板，可直接粘贴给 AI`,"success",3e3)}catch(u){o.showToast("复制失败: "+u.message,"error")}}}function O(i){i.renderStatus=async function(){var a,e,t,n,c,l,p;const s=document.getElementById("sec-status");if(s){s.innerHTML='<div class="loading">加载中...</div>';try{const d=await this.get("/api/admin/system-status");if(!(d!=null&&d.ok)){s.innerHTML=this.emptyState({title:"系统状态加载失败",desc:(d==null?void 0:d.error)||"请检查 Worker 是否已部署 system-status 接口。"});return}const r=d.status,g=[{label:"Worker API",ok:!0,detail:"正常响应"},{label:"D1 数据库",ok:((a=r.d1)==null?void 0:a.ok)!==!1,detail:((e=r.d1)==null?void 0:e.ok)!==!1?"连接正常":"连接异常"},{label:"操作日志表",ok:((t=r.logs)==null?void 0:t.ok)!==!1,detail:((n=r.logs)==null?void 0:n.ok)!==!1?`共 ${((c=r.logs)==null?void 0:c.count)||0} 条`:"表不存在或查询失败"},{label:"用户数",ok:!0,detail:`${r.userCount||0} 人`},{label:"题库数",ok:!0,detail:`${r.bankCount||0} 个`},{label:"公告数",ok:!0,detail:`${r.announcementCount||0} 条`}].map(v=>`
                <div class="stat-card">
                    <div class="stat-icon ${v.ok?"green":"red"}">${o.icon(v.ok?"check-circle":"alert-triangle")}</div>
                    <div class="stat-info">
                        <div class="stat-value">${o.escapeHtml(v.label)}</div>
                        <div class="stat-label">${o.escapeHtml(v.detail)}</div>
                    </div>
                </div>
            `).join(""),m=(r.tables||[]).map(v=>`
                <tr>
                    <td><code>${o.escapeHtml(v.name)}</code></td>
                    <td>${v.count??"-"}</td>
                </tr>
            `).join("");s.innerHTML=`
                ${this.pageHeader({title:"系统状态",description:"查看 Worker、D1 数据库、核心表和系统配置的运行状态。",crumbs:["管理后台","系统状态"],actions:'<button class="abtn" onclick="Admin.renderStatus()">刷新</button>'})}
                <div class="stat-grid">${g}</div>
                ${m?`
                <div class="card">
                    <div class="card-header"><h3>数据表统计</h3><span class="count">${(r.tables||[]).length} 张表</span></div>
                    <div class="table-wrap">
                        <table>
                            <thead><tr><th>表名</th><th>记录数</th></tr></thead>
                            <tbody>${m}</tbody>
                        </table>
                    </div>
                </div>`:""}
                <div class="card">
                    <div class="card-header"><h3>环境信息</h3></div>
                    <div class="card-body" style="padding:16px">
                        <div class="d-grid">
                            <div class="d-item"><div class="dl">Worker 版本</div><div class="dv">${o.escapeHtml(r.workerVersion||"-")}</div></div>
                            <div class="d-item"><div class="dl">当前时间(UTC)</div><div class="dv">${o.escapeHtml(r.serverTime||"-")}</div></div>
                            <div class="d-item"><div class="dl">API 域名</div><div class="dv">${o.escapeHtml(r.apiDomain||"-")}</div></div>
                        </div>
                    </div>
                </div>`,(p=(l=o).initIcons)==null||p.call(l)}catch(d){s.innerHTML=this.emptyState({title:"系统状态加载失败",desc:d.message})}}}}const A={users:[],password:(()=>{const i=localStorage.getItem("admin_pwd");if(!i)return sessionStorage.getItem("admin_pwd")||"";try{const{pwd:s,ts:a,remember:e}=JSON.parse(i),t=e?168*36e5:24*36e5;return Date.now()-a>t?(localStorage.removeItem("admin_pwd"),""):s}catch{return localStorage.removeItem("admin_pwd"),""}})(),sort:"time",tab:"overview",_loginVerified:!1,_routeBound:!1,logAction(i,s={},a="info"){const e=new Date().toISOString(),t=this._sanitizeLogDetail(s),n=a==="error"?console.error:a==="warn"?console.warn:console.log,c=`[Admin][${e}]`,l=this.tab?`[Tab:${this.tab}]`:"",p=this._loginVerified?"[已验证]":"[未验证]";n(`${c}${l}${p} ${i}`,t),a==="error"&&console.trace("[Admin] 错误调用栈:")},_sanitizeLogDetail(i){const s=new Set(["password","pwd","token","authorization","x-admin-password"]);try{return JSON.parse(JSON.stringify(i,(a,e)=>s.has(String(a).toLowerCase())?"***":typeof e=="string"&&e.length>500?e.slice(0,500)+"...":e))}catch{return{note:"日志详情不可序列化"}}},onMaskClick(i){const s=i.currentTarget;if(i.target!==s)return;const a=window.getSelection();a&&a.toString().length>0||s.remove()},bindTabKeyboard(){const i=document.getElementById("tabs");!i||i._kbBound||(i._kbBound=!0,i.addEventListener("keydown",s=>{const a=[...i.querySelectorAll(".tab")],e=a.findIndex(n=>n.dataset.tab===this.tab);let t=-1;s.key==="ArrowRight"||s.key==="ArrowDown"?t=(e+1)%a.length:s.key==="ArrowLeft"||s.key==="ArrowUp"?t=(e-1+a.length)%a.length:s.key==="Home"?t=0:s.key==="End"&&(t=a.length-1),t>=0&&(s.preventDefault(),this.switchTab(a[t].dataset.tab))}))},bindOperationLogger(){if(document.body.dataset.adminLogBound==="1")return;document.body.dataset.adminLogBound="1";const i=s=>!!(s.closest("#login-page")||s.closest("#admin-app")||s.closest("#modal-root"));document.addEventListener("click",s=>{var e;const a=s.target.closest("button,.tab,[onclick]");!a||!i(a)||this.logAction("后台界面点击",{tag:a.tagName,id:a.id||"",className:a.className||"",text:(a.textContent||"").trim().slice(0,80),tab:((e=a.dataset)==null?void 0:e.tab)||""})}),document.addEventListener("change",s=>{const a=s.target;if(!a||!i(a))return;const e=a.type||a.tagName;this.logAction("后台表单变更",{tag:a.tagName,id:a.id||"",name:a.name||"",type:e,value:e==="password"||e==="file"?"[hidden]":String(a.value||"").slice(0,120)})})},async init(){_.init("管理后台"),this.logAction("初始化后台",{hasPassword:!!this.password,currentHash:location.hash,localStorageKeys:Object.keys(localStorage).filter(i=>i.startsWith("admin_")).length,browserInfo:{userAgent:navigator.userAgent.slice(0,100),language:navigator.language,platform:navigator.platform,cookieEnabled:navigator.cookieEnabled},timestamp:new Date().toISOString()}),document.getElementById("btn-login").addEventListener("click",()=>this.login()),document.getElementById("admin-password").addEventListener("keydown",i=>{i.key==="Enter"&&this.login()}),this.bindOperationLogger(),this.bindTabKeyboard(),this.bindRouter(),this.password?(this.logAction("快速进入模式",{passwordLength:this.password.length,savedTab:localStorage.getItem("admin_tab")||"overview"}),console.log("[Admin] ⚡ 快速进入模式"),this.showApp(),this.loadAllInBackground()):this.logAction("需要登录",{reason:"无保存的密码"})},async loadAllInBackground(){var s,a;const i=Date.now();this.logAction("后台验证开始",{currentTab:this.tab,timestamp:new Date().toISOString()});try{const e=await this.get("/api/admin/users"),t=Date.now()-i;e!=null&&e.ok?(this.logAction("后台验证成功",{userCount:((s=e.users)==null?void 0:s.length)||0,elapsedMs:t,elapsedFormatted:t<1e3?`${t}ms`:`${(t/1e3).toFixed(2)}s`,response:{ok:e.ok,userCount:(a=e.users)==null?void 0:a.length}}),console.log("[Admin] ✅ 后台验证成功"),this.users=e.users,this._loginVerified=!0,this.handleRoute()):(this.logAction("后台验证失败",{reason:"密码已过期或无效",elapsedMs:t,response:e},"warn"),console.warn("[Admin] ⚠️ 密码已过期，需要重新登录"),this.logout())}catch(e){const t=Date.now()-i;this.logAction("后台验证异常",{error:e.message,errorName:e.name,elapsedMs:t,reason:"网络错误，保留本地数据"},"warn"),console.warn("[Admin] ⚠️ 验证失败，保留本地数据:",e.message)}},async login(){var t,n;const i=document.getElementById("admin-password").value.trim();if(!i){this.logAction("登录尝试失败",{reason:"密码为空"});return}const s=((t=document.getElementById("remember-me"))==null?void 0:t.checked)||!1;this.logAction("后台登录尝试",{remember:s,passwordLength:i.length,timestamp:new Date().toISOString()});const a=document.getElementById("login-error");a.style.display="none";const e=Date.now();try{const c=await this.getWithAuth("/api/admin/users",i);c&&c.ok?(localStorage.setItem("admin_pwd",JSON.stringify({pwd:i,ts:Date.now(),remember:s})),sessionStorage.setItem("admin_pwd",i),this.password=i,this.users=c.users,this._loginVerified=!0,this.logAction("后台登录成功",{userCount:this.users.length,elapsedMs:Date.now()-e,response:{ok:c.ok,userCount:(n=c.users)==null?void 0:n.length}}),this.showApp()):(this.logAction("后台登录失败",{error:c&&c.error||"密码错误",elapsedMs:Date.now()-e,response:c},"warn"),a.textContent=c&&c.error||"密码错误",a.style.display="block")}catch(c){this.logAction("后台登录异常",{error:c.message,errorName:c.name,elapsedMs:Date.now()-e},"error"),a.textContent="网络错误: "+c.message,a.style.display="block"}},logout(){var i;this.logAction("后台退出登录",{currentTab:this.tab,userCount:((i=this.users)==null?void 0:i.length)||0,timestamp:new Date().toISOString()}),localStorage.removeItem("admin_pwd"),sessionStorage.removeItem("admin_pwd"),this._loginVerified=!1,location.reload()},async loadAll(){var s,a;const i=Date.now();this.logAction("刷新用户数据开始",{currentTab:this.tab,currentUserCount:((s=this.users)==null?void 0:s.length)||0}),console.log("[Admin] 🔐 验证登录状态...");try{const e=await this.get("/api/admin/users"),t=Date.now()-i;if(!(e!=null&&e.ok)){this.logAction("刷新用户数据失败",{reason:"登录验证失败",elapsedMs:t,response:e},"warn"),console.warn("[Admin] ❌ 登录验证失败"),localStorage.removeItem("admin_pwd"),sessionStorage.removeItem("admin_pwd");return}this.logAction("刷新用户数据成功",{userCount:((a=e.users)==null?void 0:a.length)||0,elapsedMs:t,elapsedFormatted:t<1e3?`${t}ms`:`${(t/1e3).toFixed(2)}s`}),console.log("[Admin] ✅ 登录验证成功"),this.users=e.users,this._loginVerified=!0}catch(e){const t=Date.now()-i;this.logAction("刷新用户数据异常",{error:e.message,errorName:e.name,elapsedMs:t},"error"),console.error("[Admin] ❌ 登录验证异常:",e.message)}},showApp(){document.getElementById("login-page").style.display="none",document.getElementById("admin-app").style.display="",this.bindRouter(),this.handleRoute()},bindRouter(){this._routeBound||(this._routeBound=!0,window.addEventListener("hashchange",()=>this.handleRoute()),document.addEventListener("keydown",i=>{if(i.key==="Escape"){const s=document.querySelector(".modal-mask");if(s){const a=s.querySelector('[id$="-cancel"]');a&&a.click()}}}))},hashForTab(i){return{overview:"#/overview",users:"#/users",banks:"#/banks",activity:"#/activity",announce:"#/announce",ai:"#/ai",logs:"#/logs","client-logs":"#/client-logs",status:"#/status"}[i]||"#/overview"},navigate(i){location.hash===i?this.handleRoute():location.hash=i},activateTab(i){var a;this.tab=i,localStorage.setItem("admin_tab",i),document.querySelectorAll(".tab").forEach(e=>{const t=e.dataset.tab===i;e.classList.toggle("active",t),e.setAttribute("aria-selected",t?"true":"false"),e.setAttribute("tabindex",t?"0":"-1")}),document.querySelectorAll(".section").forEach(e=>e.classList.toggle("active",e.id==="sec-"+i));const s=document.querySelector(`.tab[data-tab="${i}"]`);s&&((a=document.activeElement)!=null&&a.closest(".tabs"))&&s.focus()},switchTab(i,{pushHash:s=!0}={}){if(this.logAction("后台切换标签页",{from:this.tab,to:i}),s){this.navigate(this.hashForTab(i));return}this.activateTab(i),this.renderTab()},async handleRoute(){var n;if(((n=document.getElementById("admin-app"))==null?void 0:n.style.display)==="none")return;const i=["overview","users","banks","activity","announce","ai","logs","client-logs","status"],s=localStorage.getItem("admin_tab"),a=i.includes(s)?s:"overview",e=decodeURIComponent((location.hash||`#/${a}`).replace(/^#\/?/,"")).split("/").filter(Boolean),t=e[0]||a;if(t==="users"&&e[1]){this.activateTab("users"),await this.showUserDetail(e[1],{pushHash:!1});return}if(t==="banks"&&e[1]&&e[2]==="questions"){this.activateTab("banks"),await this.showQuestionList(e[1],"",{pushHash:!1});return}if(t==="banks"&&e[1]){this.activateTab("banks"),await this.showBankDetail(e[1],{pushHash:!1});return}this.switchTab(i.includes(t)?t:"overview",{pushHash:!1})},async renderTab(){const i={overview:"renderOverview",users:"renderUsers",banks:"renderBanks",activity:"renderActivity",announce:"renderAnnounce",ai:"renderAI",logs:"renderLogs","client-logs":"renderClientLogs",status:"renderStatus"};i[this.tab]&&await this[i[this.tab]]()},pageHeader({title:i,description:s="",crumbs:a=["管理后台"],actions:e=""}){return`
            <div class="page-head">
                <div class="page-meta">
                    <div class="breadcrumb">${a.map(n=>`<span>${o.escapeHtml(n)}</span>`).join("")}</div>
                    <h1 class="page-title">${o.escapeHtml(i)}</h1>
                    ${s?`<div class="page-desc">${o.escapeHtml(s)}</div>`:""}
                </div>
                ${e?`<div class="page-actions">${e}</div>`:""}
            </div>`},emptyState({title:i="暂无数据",desc:s="",action:a=""}={}){return`<div class="empty-state"><strong>${o.escapeHtml(i)}</strong>${s?`<div>${o.escapeHtml(s)}</div>`:""}${a?`<div style="margin-top:12px">${a}</div>`:""}</div>`},statusPill(i,s={}){const a=i?s.enabled||"启用":s.disabled||"禁用";return`<span class="status-pill ${i?"enabled":"disabled"}">${o.escapeHtml(a)}</span>`},pager({page:i=1,pageSize:s=20,total:a=0,onPage:e,onPageSize:t,pageSizes:n=[10,20,50,100]}){const c=Math.max(1,Math.ceil(a/s)),l=Math.min(Math.max(1,i),c),p=a===0?0:(l-1)*s+1,d=Math.min(a,l*s),r=Math.max(1,l-1),u=Math.min(c,l+1);return`
            <div class="pager">
                <div class="pager-info">显示 ${p}-${d} / 共 ${a} 条</div>
                <div class="pager-actions">
                    <select class="admin-select pager-size" onchange="${t}(parseInt(this.value, 10))">
                        ${n.map(g=>`<option value="${g}" ${g===s?"selected":""}>${g} 条/页</option>`).join("")}
                    </select>
                    <button class="abtn" ${l<=1?"disabled":""} onclick="${e}(${r})">上一页</button>
                    <span class="pager-current">${l} / ${c}</span>
                    <button class="abtn" ${l>=c?"disabled":""} onclick="${e}(${u})">下一页</button>
                </div>
            </div>`},async confirmDanger({title:i="确认操作",message:s="",targetLabel:a="",requiredText:e="",confirmText:t="确认",danger:n=!0}={}){const c=`confirm-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,l=document.getElementById("modal-root");return l.innerHTML=`
            <div class="modal-mask" id="${c}-mask">
                <div class="modal-box ${n?"danger-modal":""}">
                    <h3>${o.escapeHtml(i)}</h3>
                    ${a?`<p class="confirm-meta">对象：<strong>${o.escapeHtml(a)}</strong></p>`:""}
                    ${s?`<p class="confirm-msg ${n?"danger":"default"}">${o.escapeHtml(s)}</p>`:""}
                    ${e?`
                        <label>请输入 <code>${o.escapeHtml(e)}</code> 确认</label>
                        <input class="confirm-input" id="${c}-input" autocomplete="off" placeholder="${o.escapeHtml(e)}">
                    `:""}
                    <div class="modal-actions">
                        <button class="ms" type="button" id="${c}-cancel">取消</button>
                        <button class="${n?"danger":"mp"}" type="button" id="${c}-ok" ${e?"disabled":""}>${o.escapeHtml(t)}</button>
                    </div>
                </div>
            </div>`,await new Promise(p=>{const d=document.getElementById(`${c}-mask`),r=document.getElementById(`${c}-input`),u=document.getElementById(`${c}-ok`),g=document.getElementById(`${c}-cancel`),m=v=>{d==null||d.remove(),p(v)};d==null||d.addEventListener("click",v=>{v.target===d&&m(!1)}),g==null||g.addEventListener("click",()=>m(!1)),r==null||r.addEventListener("input",()=>{u.disabled=r.value.trim()!==e}),u==null||u.addEventListener("click",()=>m(!0))})},_renderOverviewSkeleton(){return`
            ${this.pageHeader({title:"总览",description:"查看平台运行、用户增长、答题规模与题库核心状态。",crumbs:["管理后台","总览"],actions:'<button class="abtn" disabled>刷新数据</button>'})}
            
            <!-- Hero 骨架屏 -->
            <div class="overview-hero">
                <div class="hero-metric hero-metric-primary">
                    <div class="skeleton skeleton-text" style="width:100px;height:14px;margin-bottom:8px"></div>
                    <div class="skeleton skeleton-value" style="width:120px;height:48px"></div>
                    <div class="skeleton skeleton-text-sm" style="width:140px;margin-top:8px"></div>
                </div>
                <div class="hero-metric">
                    <div class="skeleton skeleton-text" style="width:80px;height:14px;margin-bottom:8px"></div>
                    <div style="display:flex;align-items:center;gap:20px">
                        <div class="skeleton skeleton-circle" style="width:80px;height:80px;border-radius:50%"></div>
                        <div>
                            <div class="skeleton skeleton-value" style="width:60px;height:32px;margin-bottom:8px"></div>
                            <div class="skeleton skeleton-text-sm" style="width:100px"></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- 今日数据骨架屏 -->
            <div class="overview-grid">
                <div class="today-stats">
                    ${Array(4).fill(`
                        <div class="today-stat-item">
                            <div class="skeleton skeleton-circle"></div>
                            <div class="today-stat-info">
                                <div class="skeleton skeleton-value" style="width:60px;height:24px;margin-bottom:6px"></div>
                                <div class="skeleton skeleton-text-sm" style="width:80px"></div>
                            </div>
                        </div>
                    `).join("")}
                </div>
                <div class="card">
                    <div class="card-header">
                        <div class="skeleton skeleton-text" style="width:120px;height:16px"></div>
                        <div class="skeleton skeleton-text-sm" style="width:60px"></div>
                    </div>
                    <div class="trend-list">
                        ${Array(7).fill(`
                            <div class="trend-list-item">
                                <div class="trend-list-date">
                                    <div class="skeleton" style="width:32px;height:20px;margin:0 auto 4px"></div>
                                    <div class="skeleton" style="width:24px;height:10px;margin:0 auto"></div>
                                </div>
                                <div class="trend-list-bar-track">
                                    <div class="skeleton skeleton-bar"></div>
                                </div>
                                <div class="trend-list-count">
                                    <div class="skeleton" style="width:40px;height:16px;margin-left:auto"></div>
                                </div>
                            </div>
                        `).join("")}
                    </div>
                </div>
            </div>
            
            <!-- 指标卡片骨架屏 -->
            <div class="stat-grid">
                ${Array(4).fill(`
                    <div class="stat-card">
                        <div class="skeleton skeleton-circle"></div>
                        <div class="stat-info">
                            <div class="skeleton skeleton-value" style="margin-bottom:6px"></div>
                            <div class="skeleton skeleton-text-sm" style="width:60px"></div>
                        </div>
                    </div>
                `).join("")}
            </div>
        `},async renderOverview(){var s,a;const i=document.getElementById("sec-overview");i.innerHTML=this._renderOverviewSkeleton();try{const e=await this.get("/api/admin/overview");if(!(e!=null&&e.ok)){i.innerHTML=`
                    ${this.pageHeader({title:"总览",description:"查看平台运行、用户增长、答题规模与题库核心状态。",crumbs:["管理后台","总览"],actions:'<button class="abtn" onclick="Admin.renderOverview()">重试</button>'})}
                    <div class="empty-state">
                        <strong>加载失败</strong>
                        <div class="error-desc">${(e==null?void 0:e.error)||"无法获取数据，请检查网络连接"}</div>
                        <button class="abtn primary error-retry" onclick="Admin.renderOverview()">重新加载</button>
                    </div>
                `;return}const t=e.overview,n=this.users.reduce((d,r)=>d+r.total_answered,0),c=this.users.reduce((d,r)=>d+r.total_duration,0),l=n>0?Math.round(this.users.reduce((d,r)=>d+r.total_correct,0)/n*100):0,p=Math.max(...t.weekTrend.map(d=>d.cnt),1);i.innerHTML=`
                ${this.pageHeader({title:"总览",description:"查看平台运行、用户增长、答题规模与题库核心状态。",crumbs:["管理后台","总览"],actions:'<button class="abtn" onclick="Admin.renderOverview()">刷新数据</button>'})}
                
                <!-- 系统通知 -->
                <div class="system-notice">
                    <span class="notice-dot"></span>
                    <div>数据实时来自云端 Worker/D1 API。题库启用或禁用后，前台列表会通过无缓存请求立即获取最新状态。</div>
                </div>
                
                <!-- Hero 指标区域 -->
                <div class="overview-hero" role="region" aria-label="核心数据概览">
                    <div class="hero-metric hero-metric-primary">
                        <div class="hero-label">总答题数</div>
                        <div class="hero-value" aria-label="${this.fmtN(n)} 题">${this.fmtN(n)}</div>
                        <div class="hero-subtitle">${this.users.length} 位用户参与</div>
                    </div>
                    <div class="hero-metric">
                        <div class="hero-label">平均正确率</div>
                        <div class="flex-center-gap">
                            <div class="ring-progress" style="--progress:${l}" role="img" aria-label="正确率 ${l}%">
                                <span class="ring-progress-value">${l}%</span>
                            </div>
                            <div>
                                <div class="hero-stat-value">${l}%</div>
                                <div class="hero-stat-sub">正确率</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- 今日数据 + 趋势图 -->
                <div class="overview-grid">
                    <div class="today-stats" role="list" aria-label="今日运营数据">
                        <div class="today-stat-item" role="listitem" aria-label="今日注册 ${t.todayReg} 人">
                            <div class="today-stat-icon" aria-hidden="true">${o.icon("user-plus")}</div>
                            <div class="today-stat-info">
                                <div class="today-stat-value">${t.todayReg}</div>
                                <div class="today-stat-label">今日注册</div>
                            </div>
                        </div>
                        <div class="today-stat-item" role="listitem" aria-label="今日活跃 ${t.todayActive} 人">
                            <div class="today-stat-icon green" aria-hidden="true">${o.icon("activity")}</div>
                            <div class="today-stat-info">
                                <div class="today-stat-value">${t.todayActive}</div>
                                <div class="today-stat-label">今日活跃</div>
                            </div>
                        </div>
                        <div class="today-stat-item" role="listitem" aria-label="题库总数 ${t.bankCount} 个">
                            <div class="today-stat-icon orange" aria-hidden="true">${o.icon("book-open")}</div>
                            <div class="today-stat-info">
                                <div class="today-stat-value">${t.bankCount}</div>
                                <div class="today-stat-label">题库总数</div>
                            </div>
                        </div>
                        <div class="today-stat-item" role="listitem" aria-label="封禁用户 ${t.bannedCount} 人">
                            <div class="today-stat-icon red" aria-hidden="true">${o.icon("shield-off")}</div>
                            <div class="today-stat-info">
                                <div class="today-stat-value">${t.bannedCount}</div>
                                <div class="today-stat-label">封禁用户</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-header">
                            <h3>近 7 天注册趋势</h3>
                            <span class="count">按天统计</span>
                        </div>
                        <div class="trend-list" role="list" aria-label="近7天注册趋势数据">
                            ${t.weekTrend.length>0?t.weekTrend.map((d,r)=>`
                                <div class="trend-list-item" role="listitem" style="animation-delay:${r*60}ms" aria-label="${this.fmtDate(d.day)} 注册 ${d.cnt} 人">
                                    <div class="trend-list-date">
                                        <span class="trend-list-day">${(this.fmtDate(d.day)||"").slice(8)}</span>
                                        <span class="trend-list-month">${(this.fmtDate(d.day)||"").slice(5,7)}月</span>
                                    </div>
                                    <div class="trend-list-bar-track" role="img" aria-label="${d.cnt} 人">
                                        <div class="trend-list-bar" style="width:${Math.max(d.cnt/p*100,2)}%"></div>
                                    </div>
                                    <div class="trend-list-count">
                                        <span class="trend-list-value">${d.cnt}</span>
                                        <span class="trend-list-unit">人</span>
                                    </div>
                                </div>
                            `).join(""):`
                                <div class="trend-list-empty">
                                    <span>暂无趋势数据</span>
                                </div>
                            `}
                        </div>
                    </div>
                </div>
                
                <!-- 底部指标卡片 -->
                <div class="stat-grid" role="list" aria-label="平台核心指标">
                    <div class="stat-card" role="listitem" aria-label="注册用户 ${this.users.length} 人">
                        <div class="stat-icon" aria-hidden="true">${o.icon("users")}</div>
                        <div class="stat-info">
                            <div class="stat-value">${this.users.length}</div>
                            <div class="stat-label">注册用户</div>
                        </div>
                    </div>
                    <div class="stat-card" role="listitem" aria-label="总答题数 ${this.fmtN(n)} 题">
                        <div class="stat-icon green" aria-hidden="true">${o.icon("check-circle")}</div>
                        <div class="stat-info">
                            <div class="stat-value">${this.fmtN(n)}</div>
                            <div class="stat-label">总答题数</div>
                        </div>
                    </div>
                    <div class="stat-card" role="listitem" aria-label="平均正确率 ${l}%">
                        <div class="stat-icon orange" aria-hidden="true">${o.icon("target")}</div>
                        <div class="stat-info">
                            <div class="stat-value">${l}%</div>
                            <div class="stat-label">平均正确率</div>
                        </div>
                    </div>
                    <div class="stat-card" role="listitem" aria-label="总学习时长 ${this.fmtDur(c)}">
                        <div class="stat-icon" aria-hidden="true">${o.icon("clock")}</div>
                        <div class="stat-info">
                            <div class="stat-value">${this.fmtDur(c)}</div>
                            <div class="stat-label">总学习时长</div>
                        </div>
                    </div>
                </div>
            `,(a=(s=o).initIcons)==null||a.call(s),this._animateOverviewEntry()}catch(e){i.innerHTML=`
                ${this.pageHeader({title:"总览",description:"查看平台运行、用户增长、答题规模与题库核心状态。",crumbs:["管理后台","总览"],actions:'<button class="abtn" onclick="Admin.renderOverview()">重试</button>'})}
                <div class="empty-state">
                    <strong>加载失败</strong>
                    <div class="error-desc">${e.message}</div>
                    <button class="abtn primary error-retry" onclick="Admin.renderOverview()">重新加载</button>
                </div>
            `}},_animateOverviewEntry(){document.querySelectorAll("#sec-overview .overview-hero, #sec-overview .overview-grid, #sec-overview .stat-grid").forEach((s,a)=>{s.style.opacity="0",s.style.transform="translateY(16px)",s.style.transition="opacity 0.5s ease, transform 0.5s ease",s.style.transitionDelay=`${a*100}ms`,requestAnimationFrame(()=>{requestAnimationFrame(()=>{s.style.opacity="1",s.style.transform="translateY(0)"})})})},async renderActivity(){const i=document.getElementById("sec-activity");i.innerHTML='<div class="loading">加载中...</div>';try{const s=await this.get("/api/admin/activity");if(!(s!=null&&s.ok)){i.innerHTML='<div class="empty-state">加载失败</div>';return}i.innerHTML=`
                ${this.pageHeader({title:"活跃记录",description:"查看最近用户学习行为，用于判断题库活跃度与同步状态。",crumbs:["管理后台","活跃记录"],actions:'<button class="abtn" onclick="Admin.renderActivity()">刷新</button>'})}
                ${s.activity.length===0?this.emptyState({title:"暂无活跃记录",desc:"用户完成答题并同步后会显示在这里。"}):`
                <div class="card">
                    <div class="card-header"><h3>最近活跃</h3><span class="count">最近 50 条</span></div>
                    <div class="table-wrap">
                        <table>
                            <thead><tr><th>用户</th><th>题库</th><th>答题</th><th>正确</th><th>学习时长</th><th>更新时间</th></tr></thead>
                            <tbody>${s.activity.map(a=>`
                                <tr>
                                    <td><strong>${o.escapeHtml(a.initials)}</strong></td>
                                    <td>${o.escapeHtml(a.bank_name||"-")}</td>
                                    <td>${a.answered}</td>
                                    <td>${a.correct}</td>
                                    <td>${this.fmtDur(a.duration)}</td>
                                    <td>${this.fmtTime(a.updated_at)}</td>
                                </tr>
                            `).join("")}</tbody>
                        </table>
                    </div>
                </div>`}`}catch(s){i.innerHTML=`<div class="empty-state">加载失败: ${s.message}</div>`}},async requestAdmin(i,s,a={},e={}){var d;const t=Date.now(),n=`${i}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,7)}`,c=new URL(s,B.BASE_URL);i==="GET"&&c.searchParams.set("_ts",Date.now().toString());const l=c.toString(),p=e.authInBody?{deviceId:B.getDeviceId(),password:this.password,...a}:a;this.logAction("后台接口请求开始",{requestId:n,method:i,path:s,fullUrl:l,body:p,bodySize:JSON.stringify(p).length,headers:{"Content-Type":"application/json",...e.headers||{}},timestamp:new Date().toISOString(),currentTab:this.tab});try{const r={method:i,cache:"no-store",headers:{"Content-Type":"application/json",...e.headers||{}}};i!=="GET"&&(r.body=JSON.stringify(p));const u=await fetch(l,r),g=await u.text();let m=null;if(g)try{m=JSON.parse(g)}catch{m={ok:!1,error:"非 JSON 响应",raw:g.slice(0,200)}}const v=Date.now()-t,$=u.ok?m:{ok:!1,error:(m==null?void 0:m.error)||`HTTP ${u.status}`},h={requestId:n,method:i,path:s,fullUrl:l,status:u.status,statusText:u.statusText,elapsedMs:v,elapsedFormatted:v<1e3?`${v}ms`:`${(v/1e3).toFixed(2)}s`,response:$,responseSize:g.length,responseOk:u.ok,timestamp:new Date().toISOString()};return v>1e3&&this.logAction("⚠️ 慢请求警告",{requestId:n,method:i,path:s,elapsedMs:v,threshold:"1000ms"},"warn"),this.logAction(u.ok?"后台接口请求成功":"后台接口请求失败",h,u.ok?"info":"warn"),$}catch(r){const u=Date.now()-t,g={ok:!1,error:r.message};return this.logAction("后台接口请求异常",{requestId:n,method:i,path:s,fullUrl:l,elapsedMs:u,error:r.message,errorName:r.name,errorStack:(d=r.stack)==null?void 0:d.split(`
`).slice(0,3).join(`
`),timestamp:new Date().toISOString()},"error"),g}},async post(i,s){return await this.requestAdmin("POST",i,s,{authInBody:!0})},async put(i,s){return await this.requestAdmin("PUT",i,s,{authInBody:!0})},async delete(i,s={}){return await this.requestAdmin("DELETE",i,s,{authInBody:!0})},async get(i){return this.getWithAuth(i,this.password)},async getWithAuth(i,s){return await this.requestAdmin("GET",i,{},{headers:{"X-Admin-Password":s,"X-Admin-Device-Id":B.getDeviceId()}})},fmtN(i){return i>=1e3?(i/1e3).toFixed(1)+"k":i},fmtDur(i){return!i||i<60?(i||0)+"秒":i<3600?Math.floor(i/60)+"分":(i/3600).toFixed(1)+"时"},fmtTime(i){if(!i)return"";try{const s=new Date(i);return isNaN(s.getTime())?i:new Date(s.getTime()+8*36e5).toISOString().replace("T"," ").slice(0,16)}catch{return i}},fmtDate(i){if(!i)return"";try{const s=new Date(i);return isNaN(s.getTime())?i:new Date(s.getTime()+8*36e5).toISOString().slice(0,10)}catch{return i}}};L(A);C(A);D(A);j(A);P(A);U(A);z(A);O(A);window.Admin=A;A.init();
