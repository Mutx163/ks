import{A as v,S as g,U as a,P as f}from"./debug-CmSjtLR0.js";import"./leaderboard-BJtmEyQg.js";import"./vendor-prism-C-5ZGMld.js";import"./vendor-lucide-CAa9N5Zm.js";import"./vendor-katex-BOikYIRU.js";import"./vendor-marked-vFQ20M_R.js";import{B}from"./bankLoader-BvyOcO3i.js";import{A as k,a as S,T as b}from"./aiExplain-_C9SDsmG.js";import"./insights-BRjpCFJQ.js";const _={_getBaseUrl(){return window.__API_BASE__||localStorage.getItem("ks_api_base")||(window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1"?"":"http://199.47.242.244:32639")},config:{enabled:!0,maxBufferSize:50,flushInterval:15e3,rateLimit:100,warnOnly:!0},_buffer:[],_flushTimer:null,_originalConsole:null,_initialized:!1,_rateCount:0,_rateResetTime:0,_deviceId:null,_pageUrl:"",init(){if(!this._initialized){this._initialized=!0;try{const t=localStorage.getItem("quiz_settings");t&&JSON.parse(t).logCollection===!1&&(this.config.enabled=!1)}catch{}if(this._pageUrl=window.location.href,this._deviceId=this._getDeviceId(),this._rateResetTime=Date.now(),this._rateCount=0,setInterval(()=>{this._rateCount=0,this._rateResetTime=Date.now()},36e5),this._interceptConsole(),this._captureErrors(),window._earlyLogs&&window._earlyLogs.length>0){for(const t of window._earlyLogs)this._addToBuffer(t);window._earlyLogs=[]}this._captureUnload(),this._startAutoFlush(),console.log("[LogCollector] ✅ 日志收集已初始化, 启用:",this.config.enabled)}},setEnabled(t){this.config.enabled=t,t?console.log("[LogCollector] ✅ 日志收集已启用"):(console.log("[LogCollector] ⏸️ 日志收集已禁用"),this._buffer=[])},_getDeviceId(){let t=localStorage.getItem("ks_device_id");return t||(typeof crypto<"u"&&crypto.randomUUID?t=crypto.randomUUID():t="xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,e=>{const s=Math.random()*16|0;return(e==="x"?s:s&3|8).toString(16)}),localStorage.setItem("ks_device_id",t),t)},_interceptConsole(){if(typeof console>"u")return;const t=this;this._originalConsole={log:console.log,warn:console.warn,error:console.error,info:console.info,debug:console.debug},console.log=function(...e){t._originalConsole.log.apply(console,e),t._capture("log",e)},console.warn=function(...e){t._originalConsole.warn.apply(console,e),t._capture("warn",e)},console.error=function(...e){t._originalConsole.error.apply(console,e),t._capture("error",e)},console.info=function(...e){t._originalConsole.info.apply(console,e),t._capture("info",e)},console.debug=function(...e){t._originalConsole.debug.apply(console,e),t._capture("debug",e)}},_captureErrors(){const t=this;window.onerror=function(e,s,n,i,o){const c=o&&o.stack?o.stack:"";t._addToBuffer({level:"error",type:"uncaught",message:String(e),source:s||"",line:n||0,col:i||0,stack:c.slice(0,1e3),pageUrl:t._pageUrl,ts:new Date().toISOString()})},window.addEventListener("unhandledrejection",function(e){let s,n="";e.reason instanceof Error?(s=e.reason.message,n=e.reason.stack||""):s=String(e.reason),t._addToBuffer({level:"error",type:"unhandledrejection",message:s.slice(0,500),stack:n.slice(0,1e3),pageUrl:t._pageUrl,ts:new Date().toISOString()})}),window.addEventListener("error",function(e){if(e.target&&(e.target instanceof HTMLImageElement||e.target instanceof HTMLScriptElement||e.target instanceof HTMLLinkElement||e.target instanceof HTMLIFrameElement)){const s=e.target;t._addToBuffer({level:"error",type:"resource",message:"资源加载失败: "+(s.tagName||"unknown"),source:s.src||s.href||"",pageUrl:t._pageUrl,ts:new Date().toISOString()})}},!0)},_captureUnload(){const t=this,e=()=>{if(t._buffer.length>0&&t.config.enabled){const s=t._buffer.splice(0),n=t._getBaseUrl?t._getBaseUrl():window.__API_BASE__||localStorage.getItem("ks_api_base")||(window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1"?"":"http://199.47.242.244:32639");navigator.sendBeacon(`${n}/api/logs`,JSON.stringify({logs:s,deviceId:t._deviceId}))}};window.addEventListener("beforeunload",e),window.addEventListener("pagehide",e)},_capture(t,e){if(!this.config.enabled||this.config.warnOnly&&(t==="log"||t==="info"||t==="debug")||this._isOwnLog(e))return;const s=this._formatArgs(e);let n="";if(t==="error"){for(const i of e)if(i instanceof Error&&i.stack){n=i.stack.slice(0,1e3);break}}this._addToBuffer({level:t,type:"console",message:s.slice(0,500),stack:n,pageUrl:this._pageUrl,ts:new Date().toISOString()})},_isOwnLog(t){return t.length===0?!1:String(t[0]).startsWith("[LogCollector]")},_formatArgs(t){try{return t.map(e=>{if(e===null)return"null";if(e===void 0)return"undefined";if(e instanceof Error)return e.message;if(typeof e=="object")try{return JSON.stringify(e)}catch{return String(e)}return String(e)}).join(" ")}catch{return"无法序列化日志参数"}},_addToBuffer(t){this.config.enabled&&(this._buffer.push(t),this._buffer.length>this.config.maxBufferSize&&this._buffer.shift(),this._buffer.length>=10&&this.flush())},_startAutoFlush(){const t=this;this._flushTimer=setInterval(()=>{t.flush()},this.config.flushInterval)},async flush(){if(this._buffer.length===0||!this.config.enabled)return;if(this._rateCount>=this.config.rateLimit){this._buffer=[];return}const t=this._buffer.splice(0),e=this.config.rateLimit-this._rateCount,s=t.slice(0,Math.min(t.length,e));this._rateCount+=s.length;try{const n=JSON.stringify({logs:s,deviceId:this._deviceId});await fetch(`${this._getBaseUrl()}/api/logs`,{method:"POST",headers:{"Content-Type":"application/json"},body:n,keepalive:!0})}catch{this._buffer=[...s,...this._buffer].slice(0,this.config.maxBufferSize)}},getBuffer(){return[...this._buffer]},async report(t,e,s=""){if(!this.config.enabled)return;const n={level:"error",type:"user_report",reportType:t,message:String(e).slice(0,1e3),extra:String(s).slice(0,2e3),pageUrl:this._pageUrl,ua:navigator.userAgent||"",ts:new Date().toISOString()};try{await fetch(`${this._getBaseUrl()}/api/logs`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({logs:[n],deviceId:this._deviceId})})}catch{}}};document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>_.init()):_.init();window.LogCollector=_;const x={state:{banks:[],stats:null,lightningMode:!1,selectedTypes:{},customStatsLoaded:!1},async init(){f.init("首页"),window._pageStartTime=window._pageStartTime||Date.now(),k.init().catch(o=>console.warn("[App] AI 解读配置加载失败:",o.message)),a.initNetworkMonitor(),f.mark("开始加载题库");let t=!1;try{await Promise.race([B.loadAllBanks(),new Promise((o,c)=>setTimeout(()=>c(new Error("timeout")),3e4))]),f.mark("题库加载完成")}catch(o){f.mark("题库加载失败"),t=!0,console.warn("[App] 题库加载超时或失败:",o.message)}f.mark("开始云同步"),v.autoSync().then(o=>{o&&(this.loadData(),this.render())}).catch(o=>{console.warn("[App] 云同步失败:",o.message)}),f.mark("云同步已启动"),f.mark("加载本地数据"),this.loadData();const e=document.getElementById("loading-skeleton"),s=document.getElementById("section-banks"),n=()=>{e&&e.classList.add("hidden"),s&&(s.style.display="")},i=Date.now()-window._pageStartTime;i<500?setTimeout(n,500-i):n(),f.mark("开始渲染"),this.render(),this.bindEvents(),f.mark("渲染完成"),v.isRegistered()||setTimeout(()=>{v.showRegisterModal().then(o=>{o&&(this.loadData(),this.render())})},1500),f.mark("加载公告"),this.loadAnnouncement(),t&&this.state.banks.length===0&&this.showBanksLoadError(),f.done({bankCount:this.state.banks.length,isRegistered:v.isRegistered()})},loadData(){const e=g.getBanks().filter(n=>n.enabled!==!1);this.state.banks=e,this.state.stats=g.getGlobalStats(),window.localBanksCache=e,this.state.bankSort=localStorage.getItem("quiz_bank_sort")||"recent";const s=document.getElementById("bank-sort");s&&(s.value=this.state.bankSort)},showBanksLoadError(){var e,s;const t=document.getElementById("bank-grid");t&&(t.innerHTML=`
            <div class="empty-state">
                <div class="empty-icon">
                    <i data-lucide="wifi-off"></i>
                </div>
                <div class="empty-title">网络连接失败</div>
                <div class="empty-desc">无法加载题库，请检查网络后重试</div>
                <button class="btn btn-primary" onclick="location.reload()">
                    <i data-lucide="refresh-cw"></i> 重新加载
                </button>
            </div>
        `,(s=(e=a).initIcons)==null||s.call(e),a.showNetworkError("题库加载失败，请检查网络连接",()=>{location.reload()}))},render(){this.renderSmartBanner(),this.renderWrongBook(),this.renderStatsOverview(),this.renderBankGrid(),this.renderCustomStats()},async renderCustomStats(){const t=document.getElementById("stat-total-active"),e=document.getElementById("stat-today-active"),s=document.getElementById("recent-users-container");if(!t||!e||!s)return;this.state.customStatsLoaded||(s.innerHTML=`
                <div class="stats-loading">
                    <div class="stats-loading-spinner"></div>
                    <span>加载中...</span>
                </div>
            `);const n=(i,o)=>{let c=null;const l=800,r=parseInt(i.textContent.replace(/,/g,""))||0;if(r===o){i.textContent=a.formatNumber(o);return}const d=u=>{c||(c=u);const m=Math.min((u-c)/l,1),p=Math.floor(m*(o-r)+r);i.textContent=a.formatNumber(p),m<1&&window.requestAnimationFrame(d)};window.requestAnimationFrame(d)};try{console.log("[Stats Widget] 开始拉取系统活跃及刷题人数数据...");const i=await v.getLeaderboard("answered",50,!0);if(!i||!i.ok){console.warn("[Stats Widget] 数据拉取失败，返回格式不符合预期:",i),this.state.customStatsLoaded||(s.innerHTML='<div style="color:var(--text-tertiary); font-size:var(--font-size-xs); text-align:center; padding:var(--space-2) 0;">获取数据失败</div>');return}let o=i.statsData;if(o)console.log("[Stats Widget] 数据拉取成功！使用云端精确统计数据:",o);else{const d=i.leaderboard||[],u=new Date().toISOString().slice(0,10),m=d.filter(h=>h.lastActive&&h.lastActive.startsWith(u)).length,p=d.filter(h=>h.lastActive).sort((h,y)=>new Date(y.lastActive)-new Date(h.lastActive)).slice(0,5).map(h=>({initials:h.initials||"??",lastActive:h.lastActive}));o={totalActiveCount:d.length,todayActiveCount:m,recentActiveUsers:p},console.info("[Stats Widget] 云端暂未提供统计指标，已自动启用前端数据源降级计算:",o)}const{totalActiveCount:c,todayActiveCount:l,recentActiveUsers:r}=o;n(t,c),n(e,l),!r||r.length===0?s.innerHTML='<div style="color:var(--text-tertiary); font-size:var(--font-size-xs); text-align:center; padding:var(--space-2) 0;">暂无活跃记录</div>':s.innerHTML=r.map(d=>{const u=a.escapeHtml(d.initials||"??").toUpperCase(),m=a.formatRelativeTime(d.lastActive);return`
                        <div class="recent-user-item">
                            <div class="recent-user-info">
                                <div class="recent-user-avatar">${u}</div>
                                <span class="recent-user-name">${u}</span>
                            </div>
                            <span class="recent-user-time">${m}</span>
                        </div>
                    `}).join(""),this.state.customStatsLoaded=!0}catch(i){console.error("[Stats Widget] 请求网络失败或发生代码内部崩溃:",i),this.state.customStatsLoaded||(s.innerHTML='<div style="color:var(--text-tertiary); font-size:var(--font-size-xs); text-align:center; padding:var(--space-2) 0;">服务连接失败</div>')}},renderWrongBook(){const t=document.getElementById("wrong-book");if(!t)return;const e=g.getGlobalWrongStats();if(e.totalWrong===0){t.style.display="none";return}t.innerHTML=`
            <div class="wrong-book card-fade-in">
                <div class="wrong-book-header">
                    <span class="wrong-book-icon">${a.icon("x-circle")}</span>
                    <span class="wrong-book-title title-gradient">错题本</span>
                    <span class="wrong-book-count">${e.totalWrong} 题</span>
                </div>
                <div class="wrong-book-body">
                    ${e.details.map(s=>`
                        <div class="wrong-book-bank">
                            <span class="wrong-book-bank-name">${a.escapeHtml(s.bankName)}</span>
                            <span class="wrong-book-bank-count">${s.count} 题</span>
                        </div>
                    `).join("")}
                </div>
                <div class="wrong-book-actions">
                    <button class="btn btn-secondary btn-sm" onclick="App.clearAllWrong()">${a.icon("trash-2")} 清空错题本</button>
                    <button class="btn btn-primary btn-sm" onclick="App.startWrongPractice()">${a.icon("repeat")} 错题重做</button>
                </div>
            </div>
        `,t.style.display="",a.initIcons()},clearAllWrong(){a.showModal({title:`${a.icon("alert-triangle")} 清空错题本`,content:"<p>确定清空全部错题本？此操作不可恢复。</p>",buttons:[{label:"确定清空",class:"btn-danger",onClick:t=>{t.remove();const e=g.getGlobalWrongStats().totalWrong;g.clearAllWrong(),b.clearWrongBook(e),a.showToast("错题本已清空","success"),this.loadData(),this.render()}},{label:"取消",class:"btn-secondary",onClick:t=>t.remove()}],size:"sm"})},startWrongPractice(){const t=g.getGlobalWrongStats();if(t.totalWrong===0)return;const e=t.details[0];this.startQuiz(e.bankId,"wrong")},renderSmartBanner(){},async loadAnnouncement(){var i;const t=document.getElementById("smart-banner");if(!t)return;const e="ks_cached_announce";let s=!1;const n=(()=>{try{return localStorage.getItem(e)}catch{return null}})();n&&(this._renderAnnounceWrap(t,n),s=!0);try{const o=await v.request("/api/announce");if(o!=null&&o.ok&&((i=o.announce)!=null&&i.content)){const c=a.escapeHtml(o.announce.content.replace(/\n/g," "));try{localStorage.setItem(e,c)}catch(l){console.warn("[公告] 缓存公告失败:",l.message)}this._renderAnnounceWrap(t,c);return}else{try{localStorage.removeItem(e)}catch(c){console.warn("[公告] 清除公告缓存失败:",c.message)}s||(t.style.display="none");return}}catch(o){console.warn("[公告] 请求失败:",o.message)}s||(t.style.display="none")},_renderAnnounceWrap(t,e){t.innerHTML=`
            <div class="announce-banner">
                <div class="announce-badge">公告</div>
                <div class="announce-scroll-wrap" id="announce-scroll-wrap">
                    <div class="announce-scroll-text" id="announce-scroll-text">${e}</div>
                </div>
            </div>
        `,t.style.display="",requestAnimationFrame(()=>{const s=document.getElementById("announce-scroll-wrap"),n=document.getElementById("announce-scroll-text");s&&n&&n.scrollWidth>s.clientWidth&&s.classList.add("overflow")})},scrollToBankGrid(){const t=document.getElementById("bank-grid");t&&t.scrollIntoView({behavior:"smooth",block:"start"})},renderStatsOverview(){const t=this.state.stats,e=document.getElementById("tab-overview");if(!e)return;const s=t.accuracy||0,n=2*Math.PI*34,i=n-s/100*n,o=c=>{if(c<60)return`${c}秒`;if(c<3600)return`${Math.floor(c/60)}分钟`;const l=Math.floor(c/3600),r=Math.floor(c%3600/60);return r>0?`${l}小时${r}分钟`:`${l}小时`};e.innerHTML=`
            <div class="stats-grid">
                <div class="stat-card stat-card-compact">
                    <div class="stat-label">题库数量</div>
                    <div class="stat-value primary">${t.bankCount}</div>
                </div>
                <div class="stat-card stat-card-compact">
                    <div class="stat-label">总题目数</div>
                    <div class="stat-value">${a.formatNumber(t.totalQuestions)}</div>
                </div>
                <div class="stat-card stat-card-compact">
                    <div class="stat-label">已答题数</div>
                    <div class="stat-value success">${a.formatNumber(t.totalAnswered)}</div>
                </div>
                <div class="stat-card stat-card-compact">
                    <div class="stat-label">学习时长</div>
                    <div class="stat-value">${o(t.totalDuration||0)}</div>
                </div>
                <div class="stat-card stat-card-accuracy">
                    <div class="stat-label">正确率</div>
                    <div class="stat-ring">
                        <div class="stat-ring-chart">
                            <svg class="stat-ring-svg" width="80" height="80" viewBox="0 0 80 80">
                                <circle class="stat-ring-bg" cx="40" cy="40" r="34"/>
                                <circle class="stat-ring-fill" cx="40" cy="40" r="34" 
                                        stroke-dasharray="${n}" 
                                        stroke-dashoffset="${i}"/>
                            </svg>
                            <div class="stat-ring-center">${s}%</div>
                        </div>
                        <div class="stat-ring-labels">
                            <div class="stat-ring-label">${a.icon("check-circle","text-success")} 正确 <span>${a.formatNumber(t.totalCorrect)}</span></div>
                            <div class="stat-ring-label">${a.icon("x-circle","text-danger")} 错误 <span>${a.formatNumber(t.totalWrong)}</span></div>
                        </div>
                    </div>
                </div>
            </div>
        `,a.initIcons()},getBankTypes(t){if(!t||!t.questions)return[];const e=new Set;return t.questions.forEach(s=>{s.type&&e.add(s.type)}),["all",...e].filter(Boolean)},getTypeLabel(t){return{all:"全部题型",single:"单选",multiple:"多选",judge:"判断",fill:"填空",code:"编程",essay:"简答"}[t]||t},_isModeAllowed(t,e){return!t||!Array.isArray(t)||t.length===0?!0:t.includes(e)},_renderModeButtons(t,e,s,n,i){const o=[];return this._isModeAllowed(e,"all")&&o.push(`<button class="btn btn-primary btn-sm" onclick="App.startQuiz('${t}', 'all')">${a.icon("list")} 顺序刷题</button>`),this._isModeAllowed(e,"random")&&o.push(`<button class="btn btn-secondary btn-sm" onclick="App.startQuiz('${t}', 'random')">${a.icon("shuffle")} 随机</button>`),this._isModeAllowed(e,"shuffle_options")&&o.push(`<button class="btn btn-secondary btn-sm" onclick="App.startQuiz('${t}', 'shuffle_options')">${a.icon("refresh-cw")} 选项乱序</button>`),this._isModeAllowed(e,"wrong")&&o.push(`<button class="btn btn-secondary btn-sm" onclick="App.startQuiz('${t}', 'wrong')" ${s===0?"disabled":""}>${a.icon("alert-circle")} 错题${s>0?"("+s+")":""}</button>`),this._isModeAllowed(e,"review")&&o.push(`<button class="btn btn-secondary btn-sm" onclick="App.startQuiz('${t}', 'review')">${a.icon("book-open")} 背题</button>`),this._isModeAllowed(e,"spaced")&&n>0&&o.push(`<button class="btn btn-accent btn-sm" onclick="App.startQuiz('${t}', 'spaced')">${a.icon("brain")} 复习(${n})</button>`),this._isModeAllowed(e,"bookmark")&&i>0&&o.push(`<button class="btn btn-secondary btn-sm" onclick="App.startQuiz('${t}', 'bookmark')">${a.icon("star")} 收藏(${i})</button>`),this._isModeAllowed(e,"exam")&&o.push(`<button class="btn btn-secondary btn-sm" onclick="App.startExam('${t}')">${a.icon("file-text")} 考试</button>`),o.length===0&&o.push('<span style="font-size:12px;color:var(--text-tertiary)">暂无可用模式</span>'),o.join(`
`)},sortBanks(t){this.state.bankSort=t,localStorage.setItem("quiz_bank_sort",t),this.renderBankGrid()},getSortedBanks(){const t=[...this.state.banks];switch(this.state.bankSort||localStorage.getItem("quiz_bank_sort")||"recent"){case"recent":{const s=g.getRecentBanks();if(s.length===0)return t;const n=new Set(s),i=t.filter(c=>n.has(c.id)),o=t.filter(c=>!n.has(c.id));return i.sort((c,l)=>s.indexOf(c.id)-s.indexOf(l.id)),[...i,...o]}case"name":return t.sort((s,n)=>(s.name||"").localeCompare(n.name||""));case"count":return t.sort((s,n)=>{var i,o;return(((i=n.questions)==null?void 0:i.length)||0)-(((o=s.questions)==null?void 0:o.length)||0)});case"progress":{const s=new Map(t.map(n=>[n.id,g.getBankStats(n.id).progress||0]));return t.sort((n,i)=>s.get(i.id)-s.get(n.id))}default:return t}},renderBankGrid(){const t=document.getElementById("bank-grid"),e=this.getSortedBanks();if(e.length===0){t.innerHTML=`
                <div class="bank-empty">
                    <div class="bank-empty-icon">${a.icon("book-open","icon-xl")}</div>
                    <div class="bank-empty-title">加载题库中...</div>
                    <div class="bank-empty-desc">请稍候，题库正在加载</div>
                </div>
            `;return}const s=document.getElementById("bank-count");s&&(s.textContent=e.length+" 个题库"),t.innerHTML=e.map(n=>{const i=g.getBankStats(n.id),o=g.getWrongQuestions(n.id).length,c=g.getDueQuestions(n.id).length,l=g.getBookmarkCount(n.id),r=n.questions||[],d=this.getBankTypes(n),u=n.id.includes("c-language")?"c-lang":"default",m=n.id.includes("c-language")?"C":"Q";return`
                <div class="bank-card card-fade-in" data-id="${n.id}">
                    <div class="bank-card-header">
                        <div class="bank-card-icon ${u}">${m}</div>
                        <div class="bank-card-info">
                            <div class="bank-card-title">${a.escapeHtml(n.name)}</div>
                            <div class="bank-card-desc">${a.escapeHtml(n.description||"")}</div>
                        </div>
                    </div>

                    <div class="bank-card-meta">
                        ${(n.categories||[]).slice(0,3).map(p=>`<span class="tag">${a.escapeHtml(p)}</span>`).join("")}
                        ${c>0?`<span class="tag tag-warning">${a.icon("brain")} ${c} 待复习</span>`:""}
                        <span class="tag">${d.filter(p=>p!=="all").map(p=>this.getTypeLabel(p)).join(" · ")}</span>
                    </div>

                    <div class="bank-card-progress">
                        <div class="bank-card-progress-header">
                            <span>完成进度</span>
                            <span>${i.progress}%</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-bar-fill ${i.progress===100?"success":i.progress>0?"warning":""}" 
                                 style="width: ${i.progress}%"></div>
                        </div>
                    </div>

                    <div class="bank-card-stats">
                        <div class="bank-card-stat">
                            共 <span class="bank-card-stat-num">${r.length}</span> 题
                        </div>
                        <div class="bank-card-stat">
                            已答 <span class="bank-card-stat-num">${i.answered}</span>
                        </div>
                        <div class="bank-card-stat">
                            正确 <span class="bank-card-stat-num">${i.correct}</span>
                        </div>
                    </div>

                    <!-- 题型筛选行（选择题型后，刷题按钮自动使用所选题型） -->
                    <div class="bank-card-types">
                        ${d.map(p=>`<button class="bank-type-btn ${(this.state.selectedTypes[n.id]||"all")===p?"active":""}" onclick="App.selectType('${n.id}', '${p}')">
                                ${p==="all"?a.icon("layers")+" 全部":this.getTypeLabel(p)}
                            </button>`).join("")}
                    </div>

                    <!-- 刷题模式按钮网格 -->
                    <div class="bank-card-modes">
                        ${this._renderModeButtons(n.id,n.allowed_modes,o,c,l)}
                    </div>

                    <div class="bank-card-footer">
                        <button class="btn btn-ghost btn-sm" onclick="App.resetProgress('${n.id}')" title="重置进度">
                            <span>${a.icon("rotate-ccw")} 重置</span>
                        </button>
                        <button class="btn btn-ghost btn-sm" onclick="App.exportBank('${n.id}')" title="导出题库">
                            <span>${a.icon("download")} 导出</span>
                        </button>
                    </div>
                </div>
            `}).join(""),a.initIcons()},searchQuestions(){const t=document.getElementById("search-input"),e=t?t.value.trim():"";if(!e)return;const s=[],n=this.state.banks;for(const l of n){if(!l.questions)continue;const r=l.questions.filter(d=>[d.question,d.explanation,d.category,...d.options||[],d.answer].join(" ").toLowerCase().includes(e.toLowerCase()));r.length>0&&s.push({bank:l,matched:r,count:r.length})}if(s.length===0){a.showToast("未找到包含「"+e+"」的题目","info",3e3);return}const i={keyword:e,banks:s.map(l=>({bankId:l.bank.id,questionIds:l.matched.map(r=>r.id),count:l.count}))};sessionStorage.setItem("quiz_search_results",JSON.stringify(i));const o=s[0].bank,c=s.reduce((l,r)=>l+r.count,0);b.searchQuestions(e,c),a.showToast("找到 "+c+" 道匹配题目","success",2e3),setTimeout(()=>{window.location.href="quiz.html?bank="+o.id+"&mode=review&q="+encodeURIComponent(e)},300)},clearSearch(){const t=document.getElementById("search-input");t&&(t.value="");const e=document.getElementById("search-clear");e&&(e.style.display="none"),sessionStorage.removeItem("quiz_search_results")},selectType(t,e){this.state.selectedTypes[t]=e,b.selectType(t,e),this.renderBankGrid()},startQuiz(t,e){g.recordBankUsage(t);const s=this.state.selectedTypes[t]||"all",n=s!=="all"?`&type=${s}`:"";window.location.href=`quiz.html?bank=${t}&mode=${e}${n}`},startExam(t){var o;const e=g.getBank(t);if(!e)return;const s=((o=e.questions)==null?void 0:o.length)||0,n=Math.min(s,20),i=`
            <p style="margin-bottom: var(--space-3); color: var(--text-secondary);">题库：${a.escapeHtml(e.name)}（${s}题）</p>
            <label>抽取题数（最多 ${s} 题，0 表示全部）</label>
            <input type="number" id="exam-count" value="${n}" min="0" max="${s}">
            <label>考试限时（分钟，0表示不限时）</label>
            <input type="number" id="exam-time" value="60" min="0" max="300">
            <label>及格线（百分比）</label>
            <input type="number" id="exam-pass" value="60" min="0" max="100">
        `;a.showModal({title:"📝 模拟考试设置",content:i,buttons:[{label:"开始考试",class:"btn-primary",onClick:c=>{const l=parseInt(c.querySelector("#exam-count").value)||0,r=parseInt(c.querySelector("#exam-time").value)||0,d=parseInt(c.querySelector("#exam-pass").value)||60,u=l>0?`&count=${l}`:"",m=r>0?`&time=${r*60}`:"";window.location.href=`quiz.html?bank=${t}&mode=exam${u}${m}&pass=${d}`}},{label:"取消",class:"btn-secondary",onClick:c=>c.remove()}],size:"sm"})},startSmartReview(){const t=this.state.banks;for(const e of t)if(g.getDueQuestions(e.id).length>0){this.startQuiz(e.id,"spaced");return}a.showToast("没有需要复习的题目","info")},resetProgress(t){const e=g.getBank(t);e&&a.showModal({title:`${a.icon("alert-triangle")} 重置进度`,content:`<p>确定要重置「${a.escapeHtml(e.name)}」的所有进度吗？</p>`,buttons:[{label:"确定重置",class:"btn-danger",onClick:s=>{s.remove(),g.resetBankProgress(t),b.resetProgress(t,e.name),a.showToast("进度已重置","success"),this.loadData(),this.render()}},{label:"取消",class:"btn-secondary",onClick:s=>s.remove()}],size:"sm"})},exportBank(t){const e=g.getBank(t);e&&(b.exportBank(t,e.name),a.downloadJSON(e,`${e.name}.json`),a.showToast("题库已导出","success"))},async importBank(){var t;try{const e=await a.pickFile(".json");if(!e)return;const s=await a.readJSONFile(e),n=a.validateBank(s);if(!n.valid){a.showToast("题库格式错误："+n.errors[0],"error",5e3);return}if(g.bankExists(s.id)&&!await new Promise(o=>{a.showModal({title:`${a.icon("alert-triangle")} 覆盖题库`,content:`<p>题库「${a.escapeHtml(s.name)}」已存在，是否覆盖？</p>`,buttons:[{label:"确定覆盖",class:"btn-danger",onClick:c=>{c.remove(),o(!0)}},{label:"取消",class:"btn-secondary",onClick:c=>{c.remove(),o(!1)}}],size:"sm",onClose:()=>o(!1)})}))return;g.setBank(s),b.importBank(s.name,((t=s.questions)==null?void 0:t.length)||0),a.showToast(`题库 "${s.name}" 导入成功！`,"success"),this.loadData(),this.render()}catch(e){a.showToast("导入失败："+e.message,"error",5e3)}},cycleTheme(t){const e=document.documentElement.getAttribute("data-theme")||"auto",s=["auto","light","dark"],n=(s.indexOf(e)+1)%s.length,i=s[n];i==="auto"?document.documentElement.removeAttribute("data-theme"):document.documentElement.setAttribute("data-theme",i),g.updateSettings({theme:i}),a.updateBrowserThemeColor();const o=r=>{r&&(r.classList.add("theme-spin"),r.addEventListener("animationend",()=>{r.classList.remove("theme-spin")},{once:!0}))};t?o(t):document.querySelectorAll(".action-theme-toggle, #btn-theme").forEach(o);const c={auto:"跟随系统",light:"浅色模式",dark:"深色模式"},l={auto:"monitor",light:"sun",dark:"moon"};a.showToast(`${a.icon(l[i]||"monitor")} 主题：${c[i]}`,"success",1500)},showThemePicker(){const t=document.documentElement.getAttribute("data-theme")||"auto",e=document.documentElement.getAttribute("data-color")||"parchment",s=[{value:"auto",icon:"monitor",label:"跟随系统"},{value:"light",icon:"sun",label:"浅色模式"},{value:"dark",icon:"moon",label:"深色模式"}],i=`
            <div class="theme-picker-section">
                <span class="theme-picker-label">色彩风格</span>
                <div class="theme-picker-grid-2">
                    ${[{value:"parchment",label:"暖色羊皮纸",primary:"#155e9c",bg:"#f1e9d2",fg:"#4a3e2a"},{value:"white",label:"白色简洁",primary:"#2563eb",bg:"#ffffff",fg:"#0f172a"}].map(r=>`
                        <div class="theme-picker-card ${r.value===e?"active":""}" data-type="color" data-value="${r.value}">
                            <div class="check-badge">✓</div>
                            <div class="color-preview-dots">
                                <span class="color-dot" style="background-color: ${r.primary};" title="主色"></span>
                                <span class="color-dot" style="background-color: ${r.bg};" title="背景色"></span>
                                <span class="color-dot" style="background-color: ${r.fg};" title="文本色"></span>
                            </div>
                            <input type="radio" name="colorScheme" value="${r.value}" ${r.value===e?"checked":""}>
                            <span style="font-size: 12px; color: var(--text-secondary); font-weight: 500;">${r.label}</span>
                        </div>
                    `).join("")}
                </div>
            </div>
            <div class="theme-picker-section" style="border-top: 1px solid var(--border); padding-top: var(--space-3); margin-top: var(--space-3);">
                <span class="theme-picker-label">亮度模式</span>
                <div class="theme-picker-grid">
                    ${s.map(r=>`
                        <div class="theme-picker-card ${r.value===t?"active":""}" data-type="theme" data-value="${r.value}">
                            <div class="check-badge">✓</div>
                            ${a.icon(r.icon,"theme-picker-icon")}
                            <input type="radio" name="theme" value="${r.value}" ${r.value===t?"checked":""}>
                            <span style="font-size: 11px; white-space: nowrap; color: var(--text-secondary);">${r.label}</span>
                        </div>
                    `).join("")}
                </div>
            </div>
        `;let o=!1;const c=(r,d)=>{r==="auto"?document.documentElement.removeAttribute("data-theme"):document.documentElement.setAttribute("data-theme",r),d==="parchment"?document.documentElement.removeAttribute("data-color"):document.documentElement.setAttribute("data-color",d),a.updateBrowserThemeColor()},l=a.showModal({title:`${a.icon("palette")} 主题设置`,content:i,buttons:[{label:"确定",class:"btn-primary",onClick:r=>{o=!0;const d=r.querySelector('.theme-picker-card[data-type="theme"].active'),u=r.querySelector('.theme-picker-card[data-type="color"].active'),m=d?d.dataset.value:"auto",p=u?u.dataset.value:"parchment";g.updateSettings({theme:m,colorScheme:p}),c(m,p),a.showToast("主题已更新","success"),r.remove()}},{label:"取消",class:"btn-secondary",onClick:r=>{c(t,e),r.remove()}}],size:"sm",onClose:()=>{o||c(t,e)}});l&&l.querySelectorAll(".theme-picker-card").forEach(r=>{r.addEventListener("click",()=>{const d=r.dataset.type;l.querySelectorAll(`.theme-picker-card[data-type="${d}"]`).forEach(w=>{w.classList.remove("active");const $=w.querySelector('input[type="radio"]');$&&($.checked=!1)}),r.classList.add("active");const u=r.querySelector('input[type="radio"]');u&&(u.checked=!0);const m=l.querySelector('.theme-picker-card[data-type="theme"].active'),p=l.querySelector('.theme-picker-card[data-type="color"].active'),h=m?m.dataset.value:"auto",y=p?p.dataset.value:"parchment";c(h,y)})})},async showSettings(){var d;await k.init();const t=g.getSettings(),e=t.fontSize||16,s=t.answerMode||"normal",n=t.swipeNavigation!==!1,i=S.normalizeSettings(t),c=!!localStorage.getItem("admin_pwd")||localStorage.getItem("ks_is_admin")==="1",l=`
            <div class="settings-container">
                <!-- 基础个性化 -->
                <div class="settings-group">
                    <div class="settings-group-header">
                        ${a.icon("user","settings-group-icon")}
                        <span>基础个性化</span>
                    </div>
                    <div class="settings-group-body">
                        <div class="settings-item">
                            <div class="settings-item-info">
                                <span class="settings-item-title">字体大小</span>
                                <span class="settings-item-desc">调整刷题与解析内容的字体显示大小</span>
                            </div>
                            <div class="settings-item-control">
                                <select id="setting-font-size" class="settings-select">
                                    <option value="14" ${e===14?"selected":""}>14px - 较小</option>
                                    <option value="16" ${e===16?"selected":""}>16px - 标准</option>
                                    <option value="18" ${e===18?"selected":""}>18px - 较大</option>
                                    <option value="20" ${e===20?"selected":""}>20px - 大</option>
                                    <option value="24" ${e===24?"selected":""}>24px - 超大</option>
                                </select>
                            </div>
                        </div>
                        <div class="settings-item">
                            <div class="settings-item-info">
                                <span class="settings-item-title">左右滑动切换</span>
                                <span class="settings-item-desc">在刷题页左右滑动屏幕来切换题目</span>
                            </div>
                            <div class="settings-item-control">
                                <label class="toggle-label">
                                    <input type="checkbox" id="setting-swipe" ${n?"checked":""}>
                                    <span class="toggle-slider"></span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 答题偏好 -->
                <div class="settings-group">
                    <div class="settings-group-header">
                        ${a.icon("check-square","settings-group-icon")}
                        <span>答题偏好</span>
                    </div>
                    <div class="settings-group-body">
                        <div class="settings-item vertical">
                            <div class="settings-item-info">
                                <span class="settings-item-title">答题判定模式</span>
                                <span class="settings-item-desc">控制点击选项后的验证逻辑与自动跳转方式</span>
                            </div>
                            <div class="settings-item-control">
                                <select id="setting-answer-mode" class="settings-select">
                                    <option value="normal" ${s==="normal"?"selected":""}>普通模式 - 手动提交手动跳题</option>
                                    <option value="autoNext" ${s==="autoNext"?"selected":""}>自动跳题 - 手动提交答对自动跳</option>
                                    <option value="lightning" ${s==="lightning"?"selected":""}>闪电模式 - 点击即判答对自动跳</option>
                                    <option value="instant" ${s==="instant"?"selected":""}>即时判断 - 点击即判不自动跳</option>
                                </select>
                            </div>
                        </div>
                        <div class="settings-item">
                            <div class="settings-item-info">
                                <span class="settings-item-title">日志收集</span>
                                <span class="settings-item-desc">自动收集客户端运行错误以帮助改进产品稳定性</span>
                            </div>
                            <div class="settings-item-control">
                                <label class="toggle-label">
                                    <input type="checkbox" id="setting-log-collection" ${t.logCollection!==!1?"checked":""}>
                                    <span class="toggle-slider"></span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- AI 智能助理 -->
                <div class="settings-group">
                    <div class="settings-group-header">
                        ${a.icon("cpu","settings-group-icon")}
                        <span>AI 智能助理</span>
                    </div>
                    <div class="settings-group-body">
                        ${S.renderSettingsFields(i)}
                        ${k.renderSettingsFields()}
                    </div>
                </div>

                <!-- 管理入口 -->
                ${c?`
                <div style="margin-top: var(--space-2);">
                    <button class="btn-admin-entrance" onclick="window.open('admin.html', '_blank'); this.closest('.modal-overlay').remove();">
                        👑 进入管理后台
                    </button>
                </div>
                `:""}
            </div>
        `;a.showModal({title:`${a.icon("settings")} 设置`,content:l,buttons:[{label:"保存",class:"btn-primary",onClick:u=>{const m=parseInt(u.querySelector("#setting-font-size").value),p=u.querySelector("#setting-answer-mode").value,h=S.readSettingsForm(u);if(h.error){a.showToast(h.error,"error");return}m>=12&&m<=24&&(g.updateSettings({fontSize:m}),a.applyFontSize(m));const y=u.querySelector("#setting-swipe").checked,w=u.querySelector("#setting-log-collection").checked;_.setEnabled(w),g.updateSettings({answerMode:p,swipeNavigation:y,logCollection:w,...h}),k.saveSettingsFromModal(u),v.pushSettings(g.getSettings()),a.showToast("设置已保存","success"),u.remove()}},{label:"取消",class:"btn-secondary",onClick:u=>u.remove()}],size:"lg"});const r=(d=document.getElementById("setting-ai-engine"))==null?void 0:d.closest(".modal-overlay");S.bindSettingsUI(r),k.bindSettingsUI(r)},showShortcuts(){a.showToast("快捷键：Enter 提交 · A-D 选答案 · Alt+←→ 切换 · 1/0 判断","info",5e3),localStorage.setItem("quiz_shortcuts_shown","1")},bindEvents(){document.addEventListener("pointerup",n=>{const i=n.target.closest("button, .btn, .bank-card, .bank-type-btn");i&&i.blur()});const t=document.getElementById("btn-import");t&&t.addEventListener("click",()=>this.importBank());const e=document.getElementById("search-input");e&&e.addEventListener("input",()=>{const n=document.getElementById("search-clear");n&&(n.style.display=e.value?"":"none")}),document.addEventListener("click",n=>{if(n.target.closest(".action-theme-toggle")||n.target.closest("#btn-theme")){n.preventDefault(),this.showThemePicker();return}if(n.target.closest(".action-settings-toggle")||n.target.closest("#btn-settings")){n.preventDefault(),this.showSettings();return}if(n.target.closest(".action-history-toggle")||n.target.closest("#btn-history")){n.preventDefault(),window.location.hash="#/trend",setTimeout(()=>{const d=document.getElementById("recent-history");d&&d.scrollIntoView({behavior:"smooth"})},150);return}if(n.target.closest(".action-sync-toggle")||n.target.closest("#btn-sync")){n.preventDefault(),v.isRegistered()?v.showAccountPanel():v.showRegisterModal().then(d=>{d&&(this.loadData(),this.render())});return}if(n.target.closest(".action-shortcuts-toggle")||n.target.closest("#btn-shortcuts")){n.preventDefault(),this.showShortcuts();return}});const s=g.getSettings();s.fontSize&&a.applyFontSize(s.fontSize),s.theme&&s.theme!=="auto"&&document.documentElement.setAttribute("data-theme",s.theme),s.colorScheme&&s.colorScheme!=="parchment"&&document.documentElement.setAttribute("data-color",s.colorScheme),localStorage.getItem("quiz_shortcuts_shown")||setTimeout(()=>{a.showToast(`${a.icon("lightbulb")} 按 Enter 提交 · Alt+←→ 切换 · A-D 选答案`,"info",4e3),localStorage.setItem("quiz_shortcuts_shown","1")},2e3),!localStorage.getItem("quiz_welcome_shown")&&this.state.banks.length>0&&(localStorage.setItem("quiz_welcome_shown","1"),setTimeout(()=>{a.showToast("👋 点击题库卡片上的「开始刷题」按钮即可学习","info",5e3)},4e3))}};document.addEventListener("DOMContentLoaded",()=>{x.init()});window.App=x;
