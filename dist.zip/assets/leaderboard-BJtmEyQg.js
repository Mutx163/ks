import{U as b,A as i,P as r}from"./debug-CmSjtLR0.js";const c={currentSort:"answered",async init(){if(r.init("排行榜"),r.mark("开始同步"),await i.autoSync(),r.mark("同步完成"),!i.isRegistered()){r.done({registered:!1}),document.getElementById("lb-list").innerHTML=`
                <div class="lb-empty">
                    <div class="lb-empty-icon">🏆</div>
                    <div class="lb-empty-title">注册后即可参与排行</div>
                    <p style="margin-bottom:var(--space-4);color:var(--text-secondary);">与全站同学一起比拼学习数据</p>
                    <button class="btn btn-primary" onclick="LB.promptRegister()">立即注册加入</button>
                </div>
            `;return}r.mark("加载排行榜"),await this.loadLeaderboard(),r.mark("排行榜加载完成"),r.done({registered:!0})},async promptRegister(){await i.showRegisterModal()&&location.reload()},async switchTab(a){this.currentSort=a,document.querySelectorAll(".lb-tab").forEach(t=>{t.classList.toggle("active",t.dataset.sort===a)}),await this.loadLeaderboard()},async loadLeaderboard(){const a=document.getElementById("lb-list");a.innerHTML=`
            <div class="lb-loading">
                <div class="lb-loading-spinner"></div>
                <div>加载中...</div>
            </div>
        `;const t=await i.getLeaderboard(this.currentSort,50);if(!t||!t.ok){a.innerHTML=`
                <div class="lb-empty">
                    <div class="lb-empty-icon">📡</div>
                    <div class="lb-empty-title">加载失败</div>
                    <p style="color:var(--text-secondary);">请检查网络后重试</p>
                    <button class="btn btn-secondary" style="margin-top:var(--space-3);" onclick="LB.loadLeaderboard()">重新加载</button>
                </div>
            `;return}this.renderCurrentUser(t.currentUser);const e=t.leaderboard||[];if(e.length===0){a.innerHTML=`
                <div class="lb-empty">
                    <div class="lb-empty-icon">📭</div>
                    <div class="lb-empty-title">暂无数据</div>
                    <p style="color:var(--text-secondary);">成为第一个上榜的人吧！</p>
                </div>
            `;return}const l={answered:"按总答题数排名",accuracy:"按正确率排名（答题数≥10）",duration:"按累计学习时长排名"};document.getElementById("lb-desc").textContent=l[this.currentSort]||"";const n=i.getSyncCode();this.renderList(e,n)},renderCurrentUser(a){const t=document.getElementById("lb-me");if(!a||!t){t&&(t.style.display="none");return}const e=a.rank<=3?["🥇","🥈","🥉"][a.rank-1]:`#${a.rank}`;t.style.display="flex",t.innerHTML=`
            <div class="lb-me-rank">${e}</div>
            <div class="lb-me-info">
                <div class="lb-me-name">
                    ${b.escapeHtml(a.initials)}
                    <span class="lb-me-badge">我的排名</span>
                </div>
                <div class="lb-me-stats">
                    <span class="lb-me-stat">📊 ${a.answered} 题</span>
                    <span class="lb-me-stat">🎯 ${a.accuracy}% 正确率</span>
                    <span class="lb-me-stat">⏱ ${this.formatDuration(a.duration)}</span>
                </div>
            </div>
        `},renderList(a,t){const e=document.getElementById("lb-list");if(a.length===0){e.innerHTML="";return}const l=this.getRawValue(a[0]);e.innerHTML=a.map((n,v)=>{var u,m;const o=n.syncCode===t,s=n.rank,p=this.getRawValue(n),y=l>0?Math.round(p/l*100):0;let d="";s<=3?d=`top-${s}`:s<=10&&(d=`rank-${s}`);const h=s<=3?["🥇","🥈","🥉"][s-1]:"";return`
                <div class="lb-row ${s<=3?`top-${s}`:""} ${o?"is-me":""}" style="animation: rowSlideIn 0.3s ease both; animation-delay: ${Math.min(v*.03,.5)}s;">
                    <div class="lb-rank ${d}">
                        ${h||`<span class="lb-rank-num">${s}</span>`}
                    </div>
                    <div class="lb-avatar">${((m=(u=n.initials)==null?void 0:u.charAt(0))==null?void 0:m.toUpperCase())||"?"}</div>
                    <div class="lb-name">
                        ${b.escapeHtml(n.initials)}
                        ${o?'<span class="lb-name-tag">← 我</span>':""}
                    </div>
                    <div class="lb-value-wrap">
                        <div class="lb-value">${this.formatValue(n)}</div>
                        <div class="lb-sub">${this.formatSub(n)}</div>
                    </div>
                    <div class="lb-row-bar" style="width:${y}%;"></div>
                </div>
            `}).join("")},getRawValue(a){switch(this.currentSort){case"answered":return a.answered||0;case"accuracy":return a.accuracy||0;case"duration":return a.duration||0;default:return 0}},formatValue(a){switch(this.currentSort){case"answered":return(a.answered||0)+" 题";case"accuracy":return(a.accuracy||0)+"%";case"duration":return this.formatDuration(a.duration);default:return""}},formatSub(a){switch(this.currentSort){case"answered":return`正确率 ${a.accuracy||0}%`;case"accuracy":return`${a.answered||0} 题`;case"duration":return`${a.answered||0} 题`;default:return""}},formatDuration(a){if(!a||a<60)return(a||0)+"秒";if(a<3600)return Math.floor(a/60)+"分钟";const t=Math.floor(a/3600),e=Math.floor(a%3600/60);return e>0?`${t}时${e}分`:`${t}小时`}};window.LB=c;(window.location.pathname.includes("leaderboard.html")||window.location.hash==="#/leaderboard")&&(document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>c.init()):c.init());
