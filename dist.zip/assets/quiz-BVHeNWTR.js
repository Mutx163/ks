import{U as l,S as h,A as E,P as _}from"./debug-CmSjtLR0.js";import"./vendor-prism-C-5ZGMld.js";import"./vendor-lucide-CAa9N5Zm.js";import"./vendor-katex-BOikYIRU.js";import"./vendor-marked-vFQ20M_R.js";import{B as F}from"./bankLoader-BvyOcO3i.js";import{A as I,T as A,a as M}from"./aiExplain-_C9SDsmG.js";const H=300,R=100,B=300,q=250,N=300,j=70,e={bankId:null,bank:null,questions:[],currentIndex:0,mode:"all",answers:{},submitted:{},showExplanation:{},isFinished:!1,startTime:null,questionStartTime:null,questionTimes:{},examTimeLimit:0,examPassRate:60,examTimeRemaining:0,examTimer:null,answerMode:"normal",filterType:"all",isReviewMode:!1,_reviewDurationSaved:0,isNavigating:!1,optionOrderCache:{},_statsDirty:!1,_statsTimer:null,_lastPushAnswered:0,_lastPushCorrect:0,_lastPushDuration:0,_resultStats:null,_finishEscHandler:null,_beforeUnloadHandler:null,autoSaveInterval:null,timerInterval:null};let Q=null;function D(t,s="info",n=1e3){l.showToast(t,s),setTimeout(()=>window.location.href="index.html",n)}const S={state:e,setQuiz(t){Q=t},async init(){var i,a;_.init("刷题页");const t=new URLSearchParams(window.location.search);e.bankId=t.get("bank"),e.mode=t.get("mode")||"all",e.filterType=t.get("type")||"all",e.examTimeLimit=parseInt(t.get("time"))||0,e.examPassRate=parseInt(t.get("pass"))||60,e.examCount=parseInt(t.get("count"))||0,t.get("q")&&(e.searchKeyword=t.get("q")||"");const s=h.getSettings();e.answerMode=s.answerMode||"normal";const n=I.init().catch(r=>{console.warn("[Quiz] AI 解读配置加载失败:",r.message)});if(s.fontSize&&l.applyFontSize(s.fontSize),!e.bankId){console.error("[Quiz] 缺少题库参数"),l.showToast("缺少题库参数","error"),setTimeout(()=>window.location.href="index.html",1e3);return}if(_.mark("开始加载题库"),e.bank=h.getBank(e.bankId),(!e.bank||!Array.isArray(e.bank.questions))&&await this.loadBankFromJson(),!e.bank||!Array.isArray(e.bank.questions)){console.error("[Quiz] ❌ 题库加载失败"),this.showOverlayError("题库加载失败","即将返回首页…"),setTimeout(()=>window.location.href="index.html",1500);return}if(e.bank.enabled===!1){console.warn("[Quiz] 🚫 题库已被管理员禁用:",e.bankId),this.showOverlayError("该题库已被管理员禁用","即将返回首页…"),setTimeout(()=>window.location.href="index.html",1500);return}if(_.mark("题库加载完成"),_.mark("准备题目"),this.prepareQuestions(),_.mark("题目准备完成"),e.mode==="review"&&e.questions.forEach(r=>{e.submitted[r.id]=!0,e.showExplanation[r.id]=!0,e.answers[r.id]=r.answer}),e.mode==="wrong"&&e.questions.length===0){D("没有错题，真棒！","success");return}if(e.mode==="spaced"&&e.questions.length===0){D("没有需要复习的题目");return}if(e.mode==="bookmark"&&e.questions.length===0){D("没有收藏的题目");return}if(!E.isRegistered()){D("请先在首页注册后再刷题","error",1500);return}try{await E.pullCloudData()}catch(r){console.warn("[Quiz] 拉取云端数据失败:",r.message)}_.mark("恢复会话"),this.restoreSession(),e.startTime=Date.now(),e.questionStartTime=Date.now(),e.mode==="exam"&&Q.startExamTimer(),await n,_.mark("开始渲染"),Q.render(),this.showBankWelcome(),Q.bindEvents(),_.mark("渲染完成"),e.autoSaveInterval=setInterval(()=>Q.saveSession(),3e4),e.timerInterval=setInterval(()=>Q.updateTimerDisplay(),1e3),A.startQuiz(e.bankId,((i=e.bank)==null?void 0:i.name)||"",e.mode,e.questions.length),e._beforeUnloadHandler=()=>Q._flushStatsSync(),window.addEventListener("beforeunload",e._beforeUnloadHandler),_.done({bankId:e.bankId,bankName:(a=e.bank)==null?void 0:a.name,mode:e.mode,questionCount:e.questions.length})},restoreSession(){var s;if(e.mode!=="exam"&&e.mode!=="wrong"&&e.mode!=="spaced"&&e.mode!=="bookmark"&&e.mode!=="review"){const n=h.getBankProgress(e.bankId);if(n&&n.questions)for(const[i,a]of Object.entries(n.questions))a&&a.userAnswer!==void 0&&(e.answers[i]=a.userAnswer,e.submitted[i]=!0,e.showExplanation[i]=!0)}const t=h.getSession(e.bankId,e.mode);if(!t){(e.mode==="exam"||e.mode==="random"||e.mode==="shuffle_options")&&(e.savedOrderIds=e.questions.map(n=>n.id));return}if(e.currentIndex=t.currentIndex||0,e.currentIndex>=e.questions.length&&(e.currentIndex=0),e.mode!=="review"&&(e.answers={...e.answers,...t.answers||{}},e.submitted={...e.submitted,...t.submitted||{}},e.showExplanation={...e.showExplanation,...t.showExplanation||{}}),e.questionTimes=t.questionTimes||{},e.optionOrderCache=t.optionOrderCache||{},e.savedOrderIds=t.questionOrderIds||null,e.savedOrderIds&&(e.mode==="exam"||e.mode==="random"||e.mode==="shuffle_options"))if(e.mode==="exam"){const n=((s=e.bank)==null?void 0:s.questions)||[],i=new Map(n.map(r=>[r.id,r])),a=e.savedOrderIds.map(r=>i.get(r)).filter(Boolean);a.length>0&&(e.questions=a)}else{const n=new Map(e.savedOrderIds.map((i,a)=>[i,a]));e.questions.sort((i,a)=>{const r=n.get(i.id),o=n.get(a.id);return r!==void 0&&o!==void 0?r-o:0})}e.mode==="exam"&&t.examTimeRemaining>0&&(e.examTimeRemaining=t.examTimeRemaining),e._lastPushAnswered=t.lastPushAnswered||0,e._lastPushCorrect=t.lastPushCorrect||0,e._lastPushDuration=t.lastPushDuration||0},saveSession(t=!1){if(e.isFinished)return Promise.resolve();const s=e.mode==="random"||e.mode==="shuffle_options"||e.mode==="exam"?e.questions.map(i=>i.id):void 0,n=e.mode==="exam"?{examTimeRemaining:e.examTimeRemaining}:{};return h.saveSession(e.bankId,e.mode,{currentIndex:e.currentIndex,filterType:e.filterType||"all",answerMode:e.answerMode,answers:e.answers,submitted:e.submitted,showExplanation:e.showExplanation,questionTimes:e.questionTimes,optionOrderCache:e.optionOrderCache,questionOrderIds:s,lastPushAnswered:e._lastPushAnswered,lastPushCorrect:e._lastPushCorrect,lastPushDuration:e._lastPushDuration,...n}),E.pushProgress(h.getProgress(),t).then(i=>(this._saveReviewDuration(),i))},_saveReviewDuration(){if(!e.isReviewMode||!e.startTime)return;const t=Math.round((Date.now()-e.startTime)/1e3),s=e._reviewDurationSaved||0;t>s&&(h.addDuration(t-s),e._reviewDurationSaved=t)},async loadBankFromJson(){const t=document.getElementById("quiz-loading-sub");t&&(t.textContent="正在从云端获取题库数据…");const s=await F.loadBankById(e.bankId);s&&(e.bank=s,this._bankFromCloud=!0)},showBankWelcome(){const t=document.getElementById("quiz-loading-overlay");if(!t)return;const s=document.getElementById("quiz-loading-card"),n=document.getElementById("quiz-loading-title"),i=document.getElementById("quiz-loading-sub"),a=e.bank,r=e.questions.length,o={all:"全部题目",wrong:"错题重练",review:"背题模式",exam:"考试模式",random:"随机练习",bookmark:"收藏题目",spaced:"间隔复习",shuffle_options:"选项乱序"};s.classList.add("welcome"),n.textContent=a.name,i.textContent=`${r} 道题目 · ${o[e.mode]||"练习模式"}`,i.classList.add("bank-info");const d=this._bankFromCloud?800:300;setTimeout(()=>{t.classList.add("fade-out"),setTimeout(()=>t.remove(),450)},d)},showOverlayError(t,s){if(!document.getElementById("quiz-loading-overlay"))return;const i=document.getElementById("quiz-loading-card"),a=document.getElementById("quiz-loading-title"),r=document.getElementById("quiz-loading-sub");i.classList.add("error"),a.textContent=t,r.textContent=s},prepareQuestions(){if(e.searchKeyword){const s=e.searchKeyword.toLowerCase(),i=[...e.bank.questions||[]].filter(a=>[a.question,a.explanation,a.category,...a.options||[],a.answer].join(" ").toLowerCase().includes(s));i.length===0&&l.showToast(`未找到匹配题目：「${e.searchKeyword}」`,"info",3e3),e.questions=i,e.isReviewMode=!0;return}let t=[...e.bank.questions||[]];switch(e.filterType&&e.filterType!=="all"&&(t=t.filter(s=>s.type===e.filterType)),e.mode){case"wrong":{const s=h.getWrongQuestions(e.bankId);t=t.filter(n=>s.includes(n.id));break}case"random":case"shuffle_options":t=l.shuffleArray(t);break;case"review":e.isReviewMode=!0;break;case"spaced":{t=h.getDueQuestions(e.bankId);break}case"bookmark":{const s=h.getBankBookmarks(e.bankId);t=t.filter(n=>s.includes(n.id));break}case"exam":e.examCount>0&&e.examCount<t.length&&(t=l.shuffleArray(t).slice(0,e.examCount));break}e.questions=t},recordQuestionTime(){const t=e.questions[e.currentIndex];if(!t||!e.questionStartTime)return;const s=Math.round((Date.now()-e.questionStartTime)/1e3);e.questionTimes[t.id]||(e.questionTimes[t.id]=0),e.questionTimes[t.id]+=s,e.questionStartTime=Date.now()},getQuestionTimeDisplay(){const t=e.questions[e.currentIndex];if(!t)return"";const s=e.questionTimes[t.id]||0,n=e.questionStartTime?Math.round((Date.now()-e.questionStartTime)/1e3):0,i=s+n;if(i<60)return`${i}秒`;const a=Math.floor(i/60),r=i%60;return`${a}分${r}秒`},startExamTimer(){(!e.examTimeRemaining||e.examTimeRemaining<=0)&&(e.examTimeRemaining=e.examTimeLimit),e.examTimer=setInterval(()=>{e.examTimeRemaining--,this.updateExamTimerDisplay(),e.examTimeRemaining<=0&&(clearInterval(e.examTimer),e.examTimer=null,l.showToast("考试时间到！","error"),Q.showFinishModal(!0))},1e3)},updateExamTimerDisplay(){const t=document.getElementById("exam-timer");if(!t)return;const s=e.examTimeRemaining,n=Math.floor(s/60),i=s%60;t.textContent=`${String(n).padStart(2,"0")}:${String(i).padStart(2,"0")}`,s<=300&&t.classList.add("danger")},updateTimerDisplay(){const t=document.getElementById("question-timer");t&&(t.textContent=this.getQuestionTimeDisplay())},getDisplayOptions(t){const s=t.options||[],n=s.map((i,a)=>{const r=typeof i=="string"?i:i.text||"",o=typeof i=="object"&&i.img||"";return{displayLetter:String.fromCharCode(65+a),originalLetter:String.fromCharCode(65+a),text:r,img:o}});if(e.mode!=="shuffle_options"&&e.mode!=="exam")return n;if(!e.optionOrderCache[t.id]){const i=s.map((a,r)=>r);e.optionOrderCache[t.id]=l.shuffleArray(i)}return e.optionOrderCache[t.id].map((i,a)=>{const r=s[i],o=typeof r=="string"?r:r.text||"",d=typeof r=="object"&&r.img||"";return{displayLetter:String.fromCharCode(65+a),originalLetter:String.fromCharCode(65+i),text:o,img:d}})}};let v=null;const k={setQuiz(t){v=t},render(){this.renderHeader(),this.renderQuestion(),this.renderFooter(),this.renderSidebarGrid()},renderSidebarGrid(){const t=document.getElementById("sidebar-grid");if(!t)return;const s=e.questions,n=document.getElementById("sidebar-count");n&&(n.textContent=s.length+" 题"),t.innerHTML=s.map((a,r)=>{let o="sidebar-grid-item";return r===e.currentIndex?o+=" current":e.submitted[a.id]&&(o+=v.checkAnswer(a)?" correct":" wrong"),`<div class="${o}" data-index="${r}">${r+1}</div>`}).join(""),t.querySelectorAll(".sidebar-grid-item").forEach(a=>{a.addEventListener("click",()=>{const r=parseInt(a.dataset.index);isNaN(r)||v.goToQuestion(r)})});const i=t.querySelector(".sidebar-grid-item.current");i&&i.scrollIntoView({block:"nearest",behavior:"smooth"})},renderHeader(){document.getElementById("quiz-title").textContent=e.bank.name;const t=document.getElementById("exam-timer");t&&(t.style.display=e.mode==="exam"?"":"none"),this.updateProgress()},updateProgress(){const t=e.currentIndex+1,s=e.questions.length,n=document.getElementById("quiz-progress-fill");n&&(n.style.width=Math.round(t/s*100)+"%");const i=document.getElementById("quiz-progress-text");i&&(i.textContent=`${t} / ${s}`)},toggleNav(){const t=document.getElementById("nav-panel"),s=document.getElementById("nav-overlay");if(t.classList.toggle("show"),s.classList.toggle("show"),t.classList.contains("show")){this.renderQuestionNav();const n=t.querySelector(".question-nav-item.current");n&&n.scrollIntoView({block:"center",behavior:"smooth"})}},renderQuestionNav(){const t=document.getElementById("question-nav-grid"),s=e.questions;t.innerHTML=s.map((n,i)=>{let a="question-nav-item";return i===e.currentIndex?a+=" current":e.submitted[n.id]&&(a+=v.checkAnswer(n)?" correct":" wrong"),`<div class="${a}" data-index="${i}">${i+1}</div>`}).join(""),t.querySelectorAll(".question-nav-item").forEach(n=>{n.addEventListener("click",()=>{const i=parseInt(n.dataset.index);v.goToQuestion(i),document.getElementById("nav-panel").classList.remove("show"),document.getElementById("nav-overlay").classList.remove("show")})})},renderQuestion(){const t=e.questions[e.currentIndex];if(!t){console.warn("[Quiz] 没有题目可渲染",{currentIndex:e.currentIndex,questionsLength:e.questions.length});return}const s=document.getElementById("question-container"),n=e.isReviewMode,i=n||e.submitted[t.id],a=n?t.answer:e.answers[t.id],r=n?!0:i?v.checkAnswer(t):null,o=n||e.showExplanation[t.id],d=i&&I.isEnabled();let c=`
            <div class="question-card" data-question-id="${l.escapeHtml(t.id)}">
                <div class="question-header">
                    <div class="question-meta">
                        <span class="question-number">第 ${e.currentIndex+1} 题</span>
                        <span class="question-type ${t.type}">${l.getTypeName(t.type)}</span>
                        <span class="question-timer" id="question-timer">${v.getQuestionTimeDisplay()}</span>
                        ${t.difficulty?`
                            <div class="question-difficulty" aria-label="难度 ${t.difficulty}/5">
                                ${Array.from({length:5},(m,u)=>`<div class="question-difficulty-dot ${u<t.difficulty?"active":""}"></div>`).join("")}
                            </div>
                        `:""}
                    </div>
                    <div class="question-actions">
                        ${t.category?`<span class="question-category">${l.escapeHtml(t.category)}</span>`:""}
                        ${d?`<button class="btn-ai" onclick="Quiz.openAIAnalysis(${t.id})" title="AI解析" aria-label="AI解析">${l.icon("sparkles")} AI</button>`:""}
                        ${n?"":`<button class="btn-bookmark ${h.isBookmarked(e.bankId,t.id)?"active":""}" onclick="Quiz.toggleBookmark(${t.id})" title="收藏" aria-label="收藏此题">${h.isBookmarked(e.bankId,t.id)?l.icon("star","filled"):l.icon("star")}</button>`}
                    </div>
                </div>

                <div class="question-body">
                    <div class="question-text">
                        ${l.parseMarkdown(t.question)}
                    </div>

                    ${t.img||t.image?`<div class="img-loading-wrap"><div class="img-loading-icon"></div><img class="question-image" src="${l.escapeHtml(t.img||t.image)}" alt="题目图片" loading="lazy" onload="this.parentElement.classList.add('img-loaded')" onerror="this.parentElement.classList.add('img-loaded')"></div>`:""}

                    ${this.renderOptions(t,i,a)}

                    ${i&&o?this.renderExplanation(t,r):""}
                </div>
            </div>
        `;s.innerHTML=c,l.renderMath(s),l.highlightCode(s),l.initIcons(),v.bindOptionEvents(t)},renderOptions(t,s,n){switch(t.type){case"single":return this.renderSingleOptions(t,s,n);case"multiple":return this.renderMultipleOptions(t,s,n);case"judge":return this.renderJudgeOptions(t,s,n);case"fill":return this.renderFillInput(t,s,n);case"code":return this.renderCodeInput(t,s,n);case"essay":case"简答题":return this.renderEssayInput(t,s,n);default:return""}},renderSingleOptions(t,s,n){return`
            <div class="options-list" role="radiogroup" aria-label="选项">
                ${v.getDisplayOptions(t).map(a=>{const r=a.displayLetter,o=a.originalLetter,d=o===t.answer,c=o===n;let m="option-item",u=`<div class="option-marker">${r}</div>`;return s?d?(m+=" correct disabled",u=`<div class="option-marker">${l.icon("check")}</div>`):c&&!d?(m+=" wrong disabled",u=`<div class="option-marker">${l.icon("x")}</div>`):m+=" disabled":c&&(m+=" selected"),`
                        <div class="${m}" data-answer="${o}" role="radio" aria-checked="${c}" tabindex="0">
                            ${u}
                            <div class="option-content">
                                ${l.parseMarkdown(a.text.replace(/^[A-Z]\.\s*/,""))}
                                ${a.img?`<div class="img-loading-wrap"><div class="img-loading-icon"></div><img src="${l.escapeHtml(a.img)}" class="option-image" loading="lazy" alt="选项图片" onload="this.parentElement.classList.add('img-loaded')" onerror="this.parentElement.classList.add('img-loaded')"></div>`:""}
                            </div>
                        </div>
                    `}).join("")}
            </div>
        `},renderMultipleOptions(t,s,n){const i=v.getDisplayOptions(t),a=n||[],r=t.answer||[];return`
            <div class="options-list" role="group" aria-label="选项">
                ${i.map(o=>{const d=o.displayLetter,c=o.originalLetter;let m="option-item",u=`<div class="option-marker">${d}</div>`;if(s){const w=r.includes(c),p=a.includes(c);w?(m+=" correct disabled",u=`<div class="option-marker">${l.icon("check")}</div>`):p?(m+=" wrong disabled",u=`<div class="option-marker">${l.icon("x")}</div>`):m+=" disabled"}else a.includes(c)&&(m+=" selected");return`
                        <div class="${m}" data-answer="${c}" role="checkbox" aria-checked="${a.includes(c)}" tabindex="0">
                            ${u}
                            <div class="option-content">
                                ${l.parseMarkdown(o.text.replace(/^[A-Z]\.\s*/,""))}
                                ${o.img?`<div class="img-loading-wrap"><div class="img-loading-icon"></div><img src="${l.escapeHtml(o.img)}" class="option-image" loading="lazy" alt="选项图片" onload="this.parentElement.classList.add('img-loaded')" onerror="this.parentElement.classList.add('img-loaded')"></div>`:""}
                            </div>
                        </div>
                    `}).join("")}
            </div>
            ${s?"":'<div style="margin-top:12px;font-size:13px;color:var(--text-secondary)">💡 多选题，可选择多个选项</div>'}
        `},renderJudgeOptions(t,s,n){return`
            <div class="judge-options" role="radiogroup" aria-label="判断选项">
                <div class="judge-option ${s&&t.answer===!0?"correct":""} ${s&&n===!0&&t.answer!==!0?"wrong":""} ${!s&&n===!0?"selected":""} ${s?"disabled":""}" data-answer="true" role="radio" aria-checked="${n===!0}" tabindex="0">
                    <span class="judge-option-icon"></span>
                    <span>正确</span>
                </div>
                <div class="judge-option ${s&&t.answer===!1?"correct":""} ${s&&n===!1&&t.answer!==!1?"wrong":""} ${!s&&n===!1?"selected":""} ${s?"disabled":""}" data-answer="false" role="radio" aria-checked="${n===!1}" tabindex="0">
                    <span class="judge-option-icon"></span>
                    <span>错误</span>
                </div>
            </div>
        `},renderFillInput(t,s,n){const i=n||[];return`
            <div class="fill-inputs">
                ${(t.answer||[]).map((r,o)=>{let d="fill-input";if(s){const c=v.checkFillAnswer(i[o],r);d+=c?" correct":" wrong"}return`
                        <div class="fill-input-group">
                            <span class="fill-input-label">空${o+1}</span>
                            <input type="text" class="${d}" 
                                   data-index="${o}" 
                                   value="${i[o]||""}" 
                                   ${s?"readonly":""}
                                   placeholder="请输入答案"
                                   aria-label="填空 ${o+1}">
                        </div>
                    `}).join("")}
            </div>
            ${s?"":'<div style="margin-top:12px;font-size:13px;color:var(--text-secondary)">💡 填空题，输入后按 Enter 跳到下一空</div>'}
        `},renderCodeInput(t,s,n){const i=(n==null?void 0:n.text)||n||"";return`
            <div style="margin-top:var(--space-4)">
                <div class="code-editor" id="code-editor" 
                     ${s?'contenteditable="false"':'contenteditable="true"'}
                     role="textbox" aria-multiline="true" aria-label="代码编辑器"
                     data-placeholder="请输入代码...">${l.escapeHtml(i)}</div>
            </div>
            ${s?"":'<div style="margin-top:12px;font-size:13px;color:var(--text-secondary)">💡 编程题，请编写代码</div>'}
        `},renderEssayInput(t,s,n){const i=((n==null?void 0:n.text)||"").trim(),a=n==null?void 0:n.selfCorrect;return e.isReviewMode?"":s&&a!==void 0?i?`
                <div style="margin-top:var(--space-4);padding:12px;background:var(--bg-hover);border-radius:var(--radius-sm)">
                    <strong>你的回答：</strong><br>${l.escapeHtml(i)}
                </div>
            `:"":s?`
                <div style="margin-top:var(--space-4)">
                    <div style="margin-bottom:12px">
                        <button class="btn btn-success btn-sm" onclick="Quiz.selfMarkEssay(${t.id}, true)">${l.icon("check-circle")} 我答对了</button>
                        <button class="btn btn-danger btn-sm" style="margin-left:8px" onclick="Quiz.selfMarkEssay(${t.id}, false)">${l.icon("x-circle")} 我答错了</button>
                    </div>
                </div>
            `:`
            <div style="margin-top:var(--space-4);text-align:center">
                <button class="btn btn-primary" style="padding:10px 32px;font-size:15px" onclick="Quiz.submitEssay(${t.id})">
                    📖 一键查看答案
                </button>
                <div style="margin-top:6px;font-size:12px;color:var(--text-tertiary)">点击按钮查看参考答案与解析</div>
            </div>
        `},renderExplanation(t,s){var w;const n=e.isReviewMode,a=!(t.type==="essay"||t.type==="简答题")||((w=e.answers[t.id])==null?void 0:w.selfCorrect)!==void 0,r=!n&&a,o=typeof v<"u"&&typeof v.getDisplayOptions=="function"?v.getDisplayOptions(t):[];let d;switch(t.type){case"single":{const p=o.find(b=>b.originalLetter===t.answer);d=p?`<span class="answer-badge">${p.displayLetter}</span>`:`<span class="answer-badge">${l.escapeHtml(t.answer)}</span>`;break}case"multiple":{const p=Array.isArray(t.answer)?t.answer:(t.answer||"").split(/,\s*/),b=o.filter(y=>p.includes(y.originalLetter));d=b.length>0?b.map(y=>`<span class="answer-badge">${y.displayLetter}</span>`).join(""):p.map(y=>`<span class="answer-badge">${l.escapeHtml(y)}</span>`).join("");break}case"judge":{let p;t.answer===!0||t.answer==="true"||t.answer==="对"||t.answer==="正确"||t.answer==="A"?p="正确":t.answer===!1||t.answer==="false"||t.answer==="错"||t.answer==="错误"||t.answer==="B"?p="错误":p=t.answer,d=`<span class="answer-badge text">${l.escapeHtml(p)}</span>`;break}case"fill":{let p=[];Array.isArray(t.answer)?p=t.answer:typeof t.answer=="string"&&(p=t.answer.split(/\||,\s*/)),d=p.length>0?p.map((b,y)=>`
                        <div class="fill-answer-item">
                            <span class="fill-answer-index">(空 ${y+1})：</span>
                            <strong class="fill-answer-text">${l.escapeHtml(b)}</strong>
                        </div>
                    `).join(""):`<span class="answer-badge text">${l.escapeHtml(t.answer||"暂无答案")}</span>`;break}case"essay":case"简答题":{d=`
                    <div class="essay-answer-content">
                        ${l.parseMarkdown(t.answer||"请参考解析")}
                    </div>
                    ${t.answerImg?`<div class="essay-answer-image-wrapper"><img src="${l.escapeHtml(t.answerImg)}" alt="答案图片"></div>`:""}
                `;break}case"code":{d=`
                    <pre class="code-answer-wrapper"><code class="language-${t.codeLanguage||"c"}">${l.escapeHtml(t.answer||"")}</code></pre>
                `;break}default:d=l.escapeHtml(t.answer||"暂无答案")}const c=`
            <div class="correct-answer-card">
                <div class="correct-answer-header">
                    <span class="correct-answer-icon">${l.icon("key-round")}</span>
                    <span>正确答案</span>
                </div>
                <div class="correct-answer-content">
                    ${d}
                </div>
            </div>
        `,m=t.memoryAid?`
            <div class="memory-aid">
                <span class="memory-aid-icon">${l.icon("brain")}</span>
                <span class="memory-aid-text">${l.escapeHtml(t.memoryAid)}</span>
            </div>
            `:"",u=t.code?`
            <div class="code-reference-wrapper">
                <strong>参考代码：</strong>
                <pre><code class="language-${t.codeLanguage||"c"}">${l.escapeHtml(t.code)}</code></pre>
            </div>
            `:"";return`
            ${r?`
            <div class="result-banner ${s?"correct":"wrong"}">
                <span class="result-banner-icon">${s?"🎉":"😔"}</span>
                <span class="result-banner-text">${s?"回答正确！":"回答错误"}</span>
            </div>
            `:""}

            ${["single","multiple","judge"].includes(t.type)?"":c}

            <div class="explanation">
                <div class="explanation-header">
                    <span class="explanation-icon">${l.icon("lightbulb")}</span>
                    <span>答案解析</span>
                </div>
                <div class="explanation-content">
                    ${l.parseMarkdown(t.explanation||"暂无解析")}
                </div>
                ${m}
                ${u}
            </div>
        `},renderFooter(){const t=document.getElementById("btn-submit"),s=document.getElementById("footer-hint"),n=document.querySelector(".quiz-footer-actions"),i=e.questions[e.currentIndex],a=e.answerMode==="lightning",r=e.answerMode==="instant",o=a||r,d=o&&(i==null?void 0:i.type)==="multiple",c=i&&e.submitted[i.id],m=i&&v.hasAnswer(i),u=b=>{t&&(t.style.display=b?"none":""),n&&n.classList.toggle("submit-hidden",b)},w=b=>{s&&(s.textContent=b)};if(!i||e.isFinished){u(!0),w("");return}e.isReviewMode?(u(!0),w("📖 背题模式 - 直接查看答案和解析")):c?(u(!0),w(v.getSubmittedHint(i))):o&&!d&&i.type!=="fill"&&i.type!=="code"&&i.type!=="essay"?(u(!0),w(a?"闪电模式 - 点击选项直接判对错，答对自动跳题":"即时判断 - 点击选项直接判对错，不自动跳题")):(u(!1),t&&(t.disabled=!m,t.title=m?"":"请先作答"),w(d?a?"闪电模式 · 多选题请选择完整答案后提交，答对自动跳题":"即时判断 · 多选题请选择完整答案后提交，不自动跳题":"按 Enter 提交 · A-D 选答案 · Alt+←→ 切换"));const p=document.querySelector(".quiz-footer-actions .btn-secondary:nth-child(2)");p&&(e.currentIndex>=e.questions.length-1?(p.textContent="完成",p.onclick=()=>v.finish()):(p.textContent="下一题",p.onclick=()=>v.nextQuestion()))},getSubmittedHint(t){const s=e.answers[t.id];return(t.type==="essay"||t.type==="简答题")&&(s==null?void 0:s.selfCorrect)===void 0?"已显示参考答案，请完成自评":v.checkAnswer(t)?"回答正确，可进入下一题":"回答错误，查看解析后继续"},showFinishModal(t=!1){var b,y;const s=e.questions.length,n=Object.keys(e.submitted).length,i=s-n;let a=0;Object.keys(e.submitted).forEach(T=>{const C=e.questions.find(z=>z.id==T);C&&v.checkAnswer(C)&&a++});const o=i>0,d=t?"clock":o?"alert-circle":"check-circle-2",c=t||o?"warning":"success",m=n-a,u=`
            <div class="finish-modal-overlay show" id="finish-modal">
                <div class="finish-modal" role="dialog" aria-modal="true" aria-label="答题完成确认">
                    <div class="finish-modal-icon-wrap ${c}">
                        <i data-lucide="${d}"></i>
                    </div>
                    <h3 class="finish-modal-title">${t?"考试时间到":o?"还有题目未完成":"全部答完！"}</h3>
                    <p class="finish-modal-desc">${t?"时间已耗尽，请确认结束考试":o?`还有 ${i} 题未答，确定要结束吗？`:"确认后查看答题结果"}</p>
                    <div class="finish-modal-stats">
                        <div class="finish-modal-stat">
                            <div class="finish-modal-stat-value">${n}</div>
                            <div class="finish-modal-stat-label">已答</div>
                        </div>
                        <div class="finish-modal-stat">
                            <div class="finish-modal-stat-value success">${a}</div>
                            <div class="finish-modal-stat-label">正确</div>
                        </div>
                        <div class="finish-modal-stat">
                            <div class="finish-modal-stat-value ${m>0?"danger":""}">${m}</div>
                            <div class="finish-modal-stat-label">错误</div>
                        </div>
                        <div class="finish-modal-stat">
                            <div class="finish-modal-stat-value">${i}</div>
                            <div class="finish-modal-stat-label">未答</div>
                        </div>
                    </div>
                    <div class="finish-modal-actions">
                        ${!t&&o?'<button class="btn btn-primary" onclick="Quiz.closeFinishModal()"><i data-lucide="book-open"></i> 继续答题</button>':""}
                        <button class="btn ${o?"btn-warning":"btn-primary"}" onclick="Quiz.confirmFinish()"><i data-lucide="check-circle-2"></i> 确认结束</button>
                    </div>
                    ${t?"":`
                    <div class="finish-modal-secondary">
                        <button class="btn btn-outline btn-sm" onclick="Quiz.saveAndQuit()"><i data-lucide="save"></i> 保存退出</button>
                    </div>`}
                </div>
            </div>
        `,w=document.createElement("div");w.innerHTML=u,document.body.appendChild(w),(y=(b=l).initIcons)==null||y.call(b);const p=document.getElementById("finish-modal");p.addEventListener("click",T=>{T.target===p&&v.closeFinishModal()}),e._finishEscHandler=T=>{T.key==="Escape"&&v.closeFinishModal()},document.addEventListener("keydown",e._finishEscHandler)},closeFinishModal(){var t;e._finishEscHandler&&(document.removeEventListener("keydown",e._finishEscHandler),e._finishEscHandler=null),(t=document.getElementById("finish-modal"))==null||t.remove()},confirmFinish(){this.closeFinishModal(),e.examTimer&&(clearInterval(e.examTimer),e.examTimer=null),e.autoSaveInterval&&clearInterval(e.autoSaveInterval),v.recordQuestionTime(),h.clearSession(e.bankId,e.mode),e.isFinished=!0,v._saveAndTrackStats();const t=document.querySelector(".quiz-footer");t&&(t.style.display="none"),this.showResultModal()},showResultModal(){var T,C;const{duration:t,correctCount:s,wrongCount:n,submittedCount:i}=e._resultStats||{},a=Math.floor((t||0)/60),r=(t||0)%60,o=i>0?Math.round(s/i*100):0,d=e.mode==="exam",c=d?o>=e.examPassRate:null,m=d&&!c?"warning":"success",u=d&&!c?"frown":"party-popper",w=d?c?"考试通过！":"未通过考试":"答题完成！",p=d?`及格线 ${e.examPassRate}%，正确率 ${o}%`:`${e.bank.name}`,b=`
            <div class="finish-modal-overlay show" id="finish-modal">
                <div class="finish-modal" role="dialog" aria-modal="true" aria-label="答题结果">
                    <div class="finish-modal-icon-wrap ${m}">
                        <i data-lucide="${u}"></i>
                    </div>
                    <h3 class="finish-modal-title">${w}</h3>
                    <p class="finish-modal-desc">${l.escapeHtml(p)}</p>
                    <div class="finish-modal-stats">
                        <div class="finish-modal-stat">
                            <div class="finish-modal-stat-value success">${s}</div>
                            <div class="finish-modal-stat-label">答对</div>
                        </div>
                        <div class="finish-modal-stat">
                            <div class="finish-modal-stat-value danger">${n}</div>
                            <div class="finish-modal-stat-label">答错</div>
                        </div>
                        <div class="finish-modal-stat">
                            <div class="finish-modal-stat-value">${o}%</div>
                            <div class="finish-modal-stat-label">正确率</div>
                        </div>
                        <div class="finish-modal-stat">
                            <div class="finish-modal-stat-value">${a>0?a+"分":""}${r}秒</div>
                            <div class="finish-modal-stat-label">用时</div>
                        </div>
                    </div>
                    <div class="finish-modal-actions">
                        <button class="btn btn-primary" onclick="Quiz.goHome()"><i data-lucide="home"></i> 返回首页</button>
                    </div>
                    <div class="finish-modal-secondary">
                        <button class="btn btn-outline btn-sm" onclick="Quiz.startReview()"><i data-lucide="file-text"></i> 查看解析</button>
                        <button class="btn btn-outline btn-sm" onclick="Quiz.restart()"><i data-lucide="rotate-ccw"></i> 重新开始</button>
                    </div>
                </div>
            </div>
        `,y=document.createElement("div");y.innerHTML=b,document.body.appendChild(y),(C=(T=l).initIcons)==null||C.call(T)},updateSelectedOptionState(t){const s=v.getQuestionCard();s&&s.querySelectorAll(".option-item, .judge-option").forEach(n=>{const i=n.dataset.answer===String(t);n.classList.toggle("selected",i),n.setAttribute("aria-checked",String(i))})},updateMultipleOptionState(t){const s=v.getQuestionCard();s&&s.querySelectorAll(".option-item").forEach(n=>{const i=t.includes(n.dataset.answer);n.classList.toggle("selected",i),n.setAttribute("aria-checked",String(i))})}};let g=null;const $={setQuiz(t){g=t},_shouldAutoAdvance(t){return["lightning","instant"].includes(e.answerMode)&&e.submitted[t]},_isAutoSubmit(){return["lightning","instant"].includes(e.answerMode)},getQuestionCard(){return document.querySelector("#question-container .question-card")},bindOptionEvents(t){if(e.isReviewMode||e.submitted[t.id])return;const n=this.getQuestionCard();if(n){if(t.type==="single"&&n.querySelectorAll(".option-item").forEach(i=>{i.addEventListener("click",()=>{const a=i.dataset.answer;this.selectAnswer(t.id,a)})}),t.type==="multiple"&&n.querySelectorAll(".option-item").forEach(i=>{i.addEventListener("click",()=>{const a=i.dataset.answer;this.toggleAnswer(t.id,a)})}),t.type==="judge"&&n.querySelectorAll(".judge-option").forEach(i=>{i.addEventListener("click",()=>{const a=i.dataset.answer==="true";this.selectAnswer(t.id,a)})}),t.type==="fill"){n.querySelectorAll(".fill-input").forEach(a=>{a.addEventListener("input",l.debounce(()=>{this.updateFillAnswer(t.id)},H)),a.addEventListener("keydown",r=>{if(r.key==="Enter"){r.preventDefault();const o=[...n.querySelectorAll(".fill-input")],d=o.indexOf(a);d<o.length-1?o[d+1].focus():this.submitCurrent()}})});const i=n.querySelector(".fill-input");i&&setTimeout(()=>i.focus(),R)}if(t.type==="code"){const i=n.querySelector("#code-editor");if(i){const a=()=>i.innerText||"",r=()=>{e.answers[t.id]=a(),g.renderFooter()};i.addEventListener("input",r),i.addEventListener("paste",()=>{setTimeout(()=>{i.textContent=a(),r()},10)})}}}},selectAnswer(t,s){if(this._shouldAutoAdvance(t)){g.nextQuestion();return}if(e.answers[t]=s,this._isAutoSubmit()){this.submitCurrent();return}g.saveSession(),g.updateSelectedOptionState(s),g.renderFooter()},toggleAnswer(t,s){if(this._shouldAutoAdvance(t)){g.nextQuestion();return}e.answers[t]||(e.answers[t]=[]);const n=e.answers[t],i=n.indexOf(s);i>=0?n.splice(i,1):(n.push(s),n.sort()),g.saveSession(),g.updateMultipleOptionState(n),g.renderFooter()},updateFillAnswer(t){const s=this.getQuestionCard(),n=s?s.querySelectorAll(".fill-input"):[],i=[];n.forEach(a=>{i.push(a.value.trim())}),e.answers[t]=i,g.saveSession(),g.renderFooter()},submitEssay(t){e.questions.find(n=>n.id===t)&&(g.recordQuestionTime(),e.answers[t]={text:""},e.submitted[t]=!0,e.showExplanation[t]=!0,g.saveSession(),g.renderQuestion(),g.renderFooter(),window.scrollTo({top:0,behavior:"smooth"}))},selfMarkEssay(t,s){if(!e.questions.find(r=>r.id===t))return;const a={text:(e.answers[t]||{}).text||"",selfCorrect:s};e.answers[t]=a,e.submitted[t]=!0,e.showExplanation[t]=!0,h.updateQuestionProgress(e.bankId,t,s,a),g.saveSession(),g.renderQuestion(),g.renderFooter()},submitCurrent(){var r;const t=e.questions[e.currentIndex];if(!t)return;if(e.submitted[t.id]){g.nextQuestion();return}if(!this.hasAnswer(t)){e.answerMode!=="lightning"&&l.showToast("请先作答","info");return}g.recordQuestionTime(),e.submitted[t.id]=!0,e.showExplanation[t.id]=!0;const s=this.checkAnswer(t);h.updateQuestionProgress(e.bankId,t.id,s,e.answers[t.id]),g.saveSession(),A.submitAnswer(e.bankId,t.type,s,t.difficulty);const n=e.questionTimes[t.id]||0;A.questionTime(e.bankId,((r=e.bank)==null?void 0:r.name)||"",t.id,t.category,t.type,t.difficulty,n,s),g._markStatsDirty(),g.renderQuestion(),g.renderFooter();const i=e.answerMode==="lightning",a=e.answerMode==="autoNext";if(i&&s){const o=this.getQuestionCard();o&&(o.classList.add("correct-flash"),setTimeout(()=>o.classList.remove("correct-flash"),B)),setTimeout(()=>g.nextQuestion(),B);return}if(a&&s){setTimeout(()=>g.nextQuestion(),500);return}window.scrollTo({top:0,behavior:"smooth"})},hasAnswer(t){const s=e.answers[t.id];switch(t.type){case"single":case"judge":return s!=null;case"multiple":return Array.isArray(s)&&s.length>0;case"fill":return Array.isArray(s)&&s.some(n=>n.trim()!=="");case"code":return s&&(typeof s=="string"?s.trim()!=="":!0);case"essay":case"简答题":return s&&s.selfCorrect!==void 0;default:return!1}},checkAnswer(t){const s=e.answers[t.id];switch(t.type){case"single":return s===t.answer;case"multiple":{const n=new Set(s||[]),i=new Set(t.answer||[]);return n.size===i.size&&[...n].every(a=>i.has(a))}case"judge":return s===t.answer;case"fill":return(t.answer||[]).every((n,i)=>this.checkFillAnswer(s==null?void 0:s[i],n));case"code":return!0;case"essay":case"简答题":{const n=e.answers[t.id];return n&&n.selfCorrect===!0}default:return!1}},checkFillAnswer(t,s){return!t||!s?!1:t.trim().toLowerCase()===s.trim().toLowerCase()},_cleanMarkdown(t){return t.replace(/```(\w*)\n/g,"").replace(/```/g,"").replace(/`([^`]+)`/g,"$1").replace(/\$([^$]+)\$/g,"$1").replace(/[#*_~[\]]/g,"").replace(/\s+/g," ").trim()},_buildSearchKeyword(t){let s=this._cleanMarkdown(t.question);const n=g.getDisplayOptions(t);return n&&n.length>0&&(s+=" "+n.map(i=>`${i.displayLetter}.${i.text}`).join(" ")),s.length>300&&(s=s.substring(0,300)),t.code&&(s+=" "+t.code.substring(0,200)),s},_buildSearchUrl(t){const s=h.getSettings(),n=M.buildSearchUrl(s,t);return console.log("[AI] ✅ 使用搜索引擎:",{aiEngine:M.normalizeSettings(s).aiEngine,keyword:t,url:n}),n},async openAIAnalysis(t){const s=e.questions.find(d=>d.id===t);if(!s)return;if(await I.init(),!I.isEnabled()){l.showToast("管理员已关闭 AI 解读功能","error");return}const n=e.isReviewMode||e.submitted[s.id],i=e.isReviewMode?s.answer:e.answers[s.id],a=e.isReviewMode?!0:n?this.checkAnswer(s):null;if(I.isInPageMode()){await I.openExplanation({question:s,bank:e.bank,userAnswer:i,isCorrect:a,displayOptions:g.getDisplayOptions(s)});return}const r=this._buildSearchKeyword(s),o=this._buildSearchUrl(r);window.open(o,"_blank")},toggleBookmark(t){const s=h.toggleBookmark(e.bankId,t);l.showToast(s?"已收藏":"已取消收藏","success",1500),g.renderQuestion(),E.pushBookmarks(h.getBookmarks())}};let f=null;const x={setQuiz(t){f=t},_navigateTo(t){e.isNavigating||t<0||t>=e.questions.length||(e.isNavigating=!0,f.recordQuestionTime(),e.currentIndex=t,e.questionStartTime=Date.now(),f.saveSession(),this._markStatsDirty(),f.render(),window.scrollTo({top:0,behavior:"smooth"}),setTimeout(()=>{e.isNavigating=!1},q))},nextQuestion(){this._navigateTo(e.currentIndex+1)},prevQuestion(){this._navigateTo(e.currentIndex-1)},goToQuestion(t){this._navigateTo(t)},finish(){f.showFinishModal()},async saveAndQuit(){f.closeFinishModal(),l.showToast("正在同步进度...","info",2e3);try{await this._flushStatsNow(),await f.saveSession(!0),l.showToast("进度已安全同步","success")}catch(t){console.warn("[Quiz] 退出同步异常:",t)}setTimeout(()=>window.location.href="index.html",N)},_calculateStats(){const t=Math.round((Date.now()-e.startTime)/1e3),s=Object.keys(e.submitted),n=s.filter(o=>{const d=e.questions.find(c=>c.id==o);return d&&f.checkAnswer(d)}).length,i=s.length>0?Math.round(n/s.length*100):0,a=e.mode==="exam",r=s.map(o=>{const d=e.questions.find(c=>c.id==o);return{id:o,category:d==null?void 0:d.category,type:d==null?void 0:d.type,difficulty:d==null?void 0:d.difficulty,timeSpent:e.questionTimes[o]||0,isCorrect:d?f.checkAnswer(d):!1}});return{duration:t,submittedIds:s,correctCount:n,wrongCount:s.length-n,accuracy:i,isExam:a,heatmapData:r,total:e.questions.length}},_saveAndTrackStats(){const t=this._calculateStats(),{duration:s,submittedIds:n,correctCount:i,accuracy:a,isExam:r,heatmapData:o,total:d}=t;f._saveReviewDuration(),h.addHistory({bankId:e.bankId,bankName:e.bank.name,mode:e.mode,total:d,correct:i,duration:s}),r?A.finishExam(e.bankId,d,i,a,s,!1):A.finishQuiz(e.bankId,e.bank.name,e.mode,d,i,n.length-i,a,s),A.questionHeatmap(e.bankId,e.bank.name,o),e._statsTimer&&(clearTimeout(e._statsTimer),e._statsTimer=null),e._statsDirty=!1;const c=n.length-(e._lastPushAnswered||0),m=i-(e._lastPushCorrect||0),u=s-(e._lastPushDuration||0);(c>0||m>0||u>0)&&(e._lastPushAnswered=n.length,e._lastPushCorrect=i,e._lastPushDuration=s,E.pushStats({bankId:e.bankId,bankName:e.bank.name,answered:c,correct:m,duration:u})),e._resultStats=t},renderResult(){var P,O;const t=this._calculateStats(),{duration:s,submittedIds:n,correctCount:i,accuracy:a,isExam:r,heatmapData:o,total:d}=t,c=Math.floor(s/60),m=s%60,u=r?a>=e.examPassRate:null,w=r&&!u?"frown":"party-popper",p=r&&!u?"result-icon-danger":"result-icon-success",b=r?u?"考试通过！":"未通过考试":"答题完成！";f._saveReviewDuration(),h.addHistory({bankId:e.bankId,bankName:e.bank.name,mode:e.mode,total:d,correct:i,duration:s}),r?A.finishExam(e.bankId,d,i,a,s,!1):A.finishQuiz(e.bankId,e.bank.name,e.mode,d,i,n.length-i,a,s),A.questionHeatmap(e.bankId,e.bank.name,o),e._statsTimer&&(clearTimeout(e._statsTimer),e._statsTimer=null),e._statsDirty=!1;const y=n.length-(e._lastPushAnswered||0),T=i-(e._lastPushCorrect||0),C=s-(e._lastPushDuration||0);(y>0||T>0||C>0)&&(e._lastPushAnswered=n.length,e._lastPushCorrect=i,e._lastPushDuration=s,E.pushStats({bankId:e.bankId,bankName:e.bank.name,answered:y,correct:T,duration:C}));const z=document.getElementById("question-container");z.innerHTML=`
            <div class="result-page">
                <div class="result-icon ${p}">
                    <i data-lucide="${w}"></i>
                </div>
                <div class="result-title">${b}</div>
                <div class="result-subtitle">${l.escapeHtml(e.bank.name)}</div>
                ${r?`<div class="result-exam-info">及格线 ${e.examPassRate}%，正确率 ${a}%</div>`:""}
                <div class="result-stats">
                    <div class="result-stat">
                        <div class="result-stat-value success">${i}</div>
                        <div class="result-stat-label">答对</div>
                    </div>
                    <div class="result-stat">
                        <div class="result-stat-value danger">${n.length-i}</div>
                        <div class="result-stat-label">答错</div>
                    </div>
                    <div class="result-stat">
                        <div class="result-stat-value ${r&&!u?"danger":""}">${a}%</div>
                        <div class="result-stat-label">正确率</div>
                    </div>
                    <div class="result-stat">
                        <div class="result-stat-value">${c>0?c+"分":""}${m}秒</div>
                        <div class="result-stat-label">用时</div>
                    </div>
                </div>
                <div class="result-actions">
                    <button class="btn btn-secondary btn-lg" onclick="Quiz.startReview()">
                        <i data-lucide="file-text"></i> 查看解析
                    </button>
                    <button class="btn btn-secondary btn-lg" onclick="Quiz.restart()">
                        <i data-lucide="rotate-ccw"></i> 重新开始
                    </button>
                    <button class="btn btn-primary btn-lg" onclick="Quiz.goHome()">
                        <i data-lucide="home"></i> 返回首页
                    </button>
                </div>
            </div>
        `,(O=(P=l).initIcons)==null||O.call(P),document.querySelector(".quiz-footer").style.display="none"},restart(){var t;(t=document.getElementById("finish-modal"))==null||t.remove(),h.clearSession(e.bankId,e.mode),(e.mode==="all"||e.mode==="random"||e.mode==="shuffle_options")&&(h.resetBankProgress(e.bankId),E.pushProgress(h.getProgress(),!0).catch(s=>{console.warn("[Quiz] 重置进度同步失败:",s)})),e.currentIndex=0,e.answers={},e.submitted={},e.showExplanation={},e.questionTimes={},e.optionOrderCache={},e.isFinished=!1,e.startTime=Date.now(),e.examTimeRemaining=0,(e.mode==="exam"||e.mode==="random"||e.mode==="shuffle_options"||e.mode==="wrong")&&f.prepareQuestions(),e.mode==="exam"&&f.startExamTimer(),e.mode==="review"&&e.questions.forEach(s=>{e.submitted[s.id]=!0,e.showExplanation[s.id]=!0,e.answers[s.id]=s.answer}),document.querySelector(".quiz-footer").style.display="",f.render(),window.scrollTo({top:0,behavior:"smooth"})},startReview(){document.getElementById("question-container")&&(e.isReviewMode=!0,e.currentIndex=0,e.isFinished=!1,Object.keys(e.submitted).forEach(s=>{e.showExplanation[s]=!0}),document.querySelector(".quiz-footer").style.display="",f.render(),window.scrollTo({top:0,behavior:"smooth"}))},async goHome(){if(!e.isFinished){l.showToast("正在同步并退出...","info",1500);try{await this._flushStatsNow(),await f.saveSession(!0)}catch(t){console.warn("[Quiz] 退出同步异常:",t)}}window.location.href="index.html"},_markStatsDirty(){e._statsDirty=!0,!e._statsTimer&&(e._statsTimer=setTimeout(()=>{this._flushStatsNow()},5e3))},_flushStatsNow(){var m;if(e._statsTimer&&(clearTimeout(e._statsTimer),e._statsTimer=null),!e._statsDirty)return Promise.resolve(null);e._statsDirty=!1;const t=Object.keys(e.submitted);if(t.length===0)return Promise.resolve(null);const s=t.filter(u=>{const w=e.questions.find(p=>p.id==u);return w&&f.checkAnswer(w)}).length,n=e.startTime?Math.round((Date.now()-e.startTime)/1e3):0,i=t.length-(e._lastPushAnswered||0),a=s-(e._lastPushCorrect||0),r=n-(e._lastPushDuration||0);if(i<=0&&a<=0&&r<=0)return Promise.resolve(null);const o=t.length,d=s,c=n;return E.pushStats({bankId:e.bankId,bankName:((m=e.bank)==null?void 0:m.name)||"",answered:i,correct:a,duration:r}).then(u=>(u?(e._lastPushAnswered=o,e._lastPushCorrect=d,e._lastPushDuration=c):e._statsDirty=!0,u)).catch(u=>(console.warn("[QuizNav] pushStats 错误:",u),e._statsDirty=!0,null))},_flushStatsSync(){var o,d;if(!e._statsDirty)return;const t=Object.keys(e.submitted);if(t.length===0)return;const s=t.filter(c=>{const m=e.questions.find(u=>u.id==c);return m&&f.checkAnswer(m)}).length,n=e.startTime?Math.round((Date.now()-e.startTime)/1e3):0,i=t.length-(e._lastPushAnswered||0),a=s-(e._lastPushCorrect||0),r=n-(e._lastPushDuration||0);if(i<=0&&a<=0&&r<=0){e._statsDirty=!1;return}if(e._lastPushAnswered=t.length,e._lastPushCorrect=s,e._lastPushDuration=n,e._statsDirty=!1,e._statsTimer&&(clearTimeout(e._statsTimer),e._statsTimer=null),navigator.sendBeacon&&E.isRegistered()){const c=JSON.stringify({deviceId:E.getDeviceId(),bankId:e.bankId,bankName:((o=e.bank)==null?void 0:o.name)||"",answered:i,correct:a,duration:r});try{navigator.sendBeacon(E.BASE_URL+"/api/sync",c);return}catch(m){console.warn("[Quiz] sendBeacon 失败:",m.message)}}E.pushStats({bankId:e.bankId,bankName:((d=e.bank)==null?void 0:d.name)||"",answered:i,correct:a,duration:r})},async showSettings(){var d;await I.init();const t=h.getSettings(),s=t.fontSize||16,n=t.answerMode||"normal",i=t.swipeNavigation!==!1,a=M.normalizeSettings(t),r=`
            <div class="settings-container">
                <!-- 基础个性化 -->
                <div class="settings-group">
                    <div class="settings-group-header">
                        ${l.icon("user","settings-group-icon")}
                        <span>基础个性化</span>
                    </div>
                    <div class="settings-group-body">
                        <div class="settings-item">
                            <div class="settings-item-info">
                                <span class="settings-item-title">字体大小</span>
                                <span class="settings-item-desc">调整刷题与解析内容的字体显示大小</span>
                            </div>
                            <div class="settings-item-control">
                                <select id="setting-font-size" class="settings-select">
                                    <option value="14" ${s===14?"selected":""}>14px - 较小</option>
                                    <option value="16" ${s===16?"selected":""}>16px - 标准</option>
                                    <option value="18" ${s===18?"selected":""}>18px - 较大</option>
                                    <option value="20" ${s===20?"selected":""}>20px - 大</option>
                                    <option value="24" ${s===24?"selected":""}>24px - 超大</option>
                                </select>
                            </div>
                        </div>
                        <div class="settings-item">
                            <div class="settings-item-info">
                                <span class="settings-item-title">左右滑动切换</span>
                                <span class="settings-item-desc">在刷题页左右滑动屏幕来切换题目</span>
                            </div>
                            <div class="settings-item-control">
                                <label class="toggle-label">
                                    <input type="checkbox" id="setting-swipe" ${i?"checked":""}>
                                    <span class="toggle-slider"></span>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 答题偏好 -->
                <div class="settings-group">
                    <div class="settings-group-header">
                        ${l.icon("check-square","settings-group-icon")}
                        <span>答题偏好</span>
                    </div>
                    <div class="settings-group-body">
                        <div class="settings-item vertical">
                            <div class="settings-item-info">
                                <span class="settings-item-title">答题判定模式</span>
                                <span class="settings-item-desc">控制点击选项后的验证逻辑与自动跳转方式</span>
                            </div>
                            <div class="settings-item-control">
                                <select id="setting-answer-mode" class="settings-select">
                                    <option value="normal" ${n==="normal"?"selected":""}>普通模式 - 手动提交手动跳题</option>
                                    <option value="autoNext" ${n==="autoNext"?"selected":""}>自动跳题 - 手动提交答对自动跳</option>
                                    <option value="lightning" ${n==="lightning"?"selected":""}>闪电模式 - 点击即判答对自动跳</option>
                                    <option value="instant" ${n==="instant"?"selected":""}>即时判断 - 点击即判不自动跳</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- AI 智能助理 -->
                <div class="settings-group">
                    <div class="settings-group-header">
                        ${l.icon("cpu","settings-group-icon")}
                        <span>AI 智能助理</span>
                    </div>
                    <div class="settings-group-body">
                        ${M.renderSettingsFields(a)}
                        ${I.renderSettingsFields()}
                    </div>
                </div>
            </div>
        `;l.showModal({title:`${l.icon("settings")} 设置`,content:r,buttons:[{label:"保存",class:"btn-primary",onClick:c=>{const m=parseInt(c.querySelector("#setting-font-size").value),u=c.querySelector("#setting-answer-mode").value,w=M.readSettingsForm(c);if(w.error){l.showToast(w.error,"error");return}m>=12&&m<=24&&(h.updateSettings({fontSize:m}),l.applyFontSize(m));const p=c.querySelector("#setting-swipe").checked;h.updateSettings({answerMode:u,swipeNavigation:p,...w}),I.saveSettingsFromModal(c),e.answerMode=u,E.pushSettings(h.getSettings()),l.showToast("设置已保存","success"),c.remove()}},{label:"取消",class:"btn-secondary",onClick:c=>c.remove()}],size:"lg"});const o=(d=document.getElementById("setting-ai-engine"))==null?void 0:d.closest(".modal-overlay");M.bindSettingsUI(o),I.bindSettingsUI(o)},bindEvents(){document.addEventListener("pointerup",n=>{const i=n.target.closest("button, .btn, .option-item, .judge-option");i&&i.blur()}),window.addEventListener("beforeunload",()=>f.saveSession()),document.addEventListener("visibilitychange",()=>{document.visibilityState==="hidden"&&f.saveSession()});let t=0,s=0;document.addEventListener("touchstart",n=>{t=n.changedTouches[0].clientX,s=n.changedTouches[0].clientY},{passive:!0}),document.addEventListener("touchend",n=>{if(document.getElementById("finish-modal"))return;const i=document.getElementById("nav-panel");if(i&&i.classList.contains("show"))return;const r=n.target.closest('pre, code, .code-block, .code-wrapper, .explanation-content, [style*="overflow-x"]');if(r&&r.scrollWidth>r.clientWidth||h.getSettings().swipeNavigation===!1)return;const d=n.changedTouches[0].clientX-t,c=n.changedTouches[0].clientY-s;Math.abs(c)>Math.abs(d)||Math.abs(d)<j||(d<0?this.nextQuestion():this.prevQuestion())},{passive:!0}),document.addEventListener("keydown",n=>{if(document.getElementById("finish-modal"))return;const i=document.activeElement;if(i&&(i.tagName==="INPUT"||i.tagName==="TEXTAREA"||i.tagName==="SELECT"))return;if(n.key==="Enter"&&!n.ctrlKey&&!n.shiftKey){const r=e.questions[e.currentIndex];r&&!e.submitted[r.id]?f.submitCurrent():this.nextQuestion()}n.key==="ArrowLeft"&&(n.preventDefault(),this.prevQuestion()),n.key==="ArrowRight"&&(n.preventDefault(),this.nextQuestion());const a=e.questions[e.currentIndex];if(a&&!e.submitted[a.id]){if(a.type==="single"||a.type==="multiple"){const r=n.key.toUpperCase(),d={1:"A",2:"B",3:"C",4:"D",5:"E",6:"F"}[n.key]||r;["A","B","C","D","E","F"].includes(d)&&(a.type==="single"?f.selectAnswer(a.id,d):f.toggleAnswer(a.id,d))}a.type==="judge"&&((n.key==="1"||n.key==="t"||n.key==="T")&&f.selectAnswer(a.id,!0),(n.key==="0"||n.key==="f"||n.key==="F")&&f.selectAnswer(a.id,!1))}})}},L={get state(){return S.state},init(){return S.init()},restoreSession(){return S.restoreSession()},saveSession(t=!1){return S.saveSession(t)},loadBankFromJson(){return S.loadBankFromJson()},prepareQuestions(){return S.prepareQuestions()},recordQuestionTime(){return S.recordQuestionTime()},getQuestionTimeDisplay(){return S.getQuestionTimeDisplay()},startExamTimer(){return S.startExamTimer()},updateExamTimerDisplay(){return S.updateExamTimerDisplay()},updateTimerDisplay(){return S.updateTimerDisplay()},getDisplayOptions(t){return S.getDisplayOptions(t)},_saveReviewDuration(){return S._saveReviewDuration()},render(){return k.render()},renderHeader(){return k.renderHeader()},renderQuestion(){return k.renderQuestion()},renderFooter(){return k.renderFooter()},renderSidebarGrid(){return k.renderSidebarGrid()},renderQuestionNav(){return k.renderQuestionNav()},toggleNav(){return k.toggleNav()},updateProgress(){return k.updateProgress()},showFinishModal(t){return k.showFinishModal(t)},closeFinishModal(){return k.closeFinishModal()},confirmFinish(){return k.confirmFinish()},showResultModal(){return k.showResultModal()},getSubmittedHint(t){return k.getSubmittedHint(t)},updateSelectedOptionState(t){return k.updateSelectedOptionState(t)},updateMultipleOptionState(t){return k.updateMultipleOptionState(t)},getQuestionCard(){return $.getQuestionCard()},bindOptionEvents(t){return $.bindOptionEvents(t)},selectAnswer(t,s){return $.selectAnswer(t,s)},toggleAnswer(t,s){return $.toggleAnswer(t,s)},updateFillAnswer(t){return $.updateFillAnswer(t)},submitEssay(t){return $.submitEssay(t)},selfMarkEssay(t,s){return $.selfMarkEssay(t,s)},submitCurrent(){return $.submitCurrent()},hasAnswer(t){return $.hasAnswer(t)},checkAnswer(t){return $.checkAnswer(t)},checkFillAnswer(t,s){return $.checkFillAnswer(t,s)},toggleBookmark(t){return $.toggleBookmark(t)},openAIAnalysis(t){return $.openAIAnalysis(t)},nextQuestion(){return x.nextQuestion()},prevQuestion(){return x.prevQuestion()},goToQuestion(t){return x.goToQuestion(t)},finish(){return x.finish()},saveAndQuit(){return x.saveAndQuit()},restart(){return x.restart()},startReview(){return x.startReview()},goHome(){return x.goHome()},showSettings(){return x.showSettings()},bindEvents(){return x.bindEvents()},_saveAndTrackStats(){return x._saveAndTrackStats()},_markStatsDirty(){return x._markStatsDirty()},_flushStatsNow(){return x._flushStatsNow()},_flushStatsSync(){return x._flushStatsSync()},renderResult(){return x.renderResult()}};S.setQuiz(L);k.setQuiz(L);$.setQuiz(L);x.setQuiz(L);document.addEventListener("DOMContentLoaded",()=>{L.init()});window.Quiz=L;
